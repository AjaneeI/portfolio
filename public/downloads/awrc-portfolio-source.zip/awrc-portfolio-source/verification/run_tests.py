"""Portable test-only temp-directory relocation; product/test sources unchanged."""
from pathlib import Path
import json
import os
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = Path(tempfile.mkdtemp(prefix='awrc-verification-')).resolve()
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
original = tempfile.TemporaryDirectory
with original(prefix='awrc-test-root-') as temp_root:
    class PhysicalTemporaryDirectory(original):
        def __init__(self, *args, **kwargs):
            if kwargs.get('dir') == '/private/tmp':
                kwargs['dir'] = str(Path(temp_root).resolve())
            super().__init__(*args, **kwargs)
    tempfile.TemporaryDirectory = PhysicalTemporaryDirectory
    try:
        suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'))
        with (OUTPUT / 'tests.log').open('w') as stream:
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
        summary = dict(tests_run=result.testsRun, failures=len(result.failures),
                       errors=len(result.errors), skipped=len(result.skipped),
                       successful=result.wasSuccessful(), output_directory=str(OUTPUT))
        (OUTPUT / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary, indent=2))
    finally:
        tempfile.TemporaryDirectory = original
raise SystemExit(0 if result.wasSuccessful() else 1)
