# Third-party design assets

Complete unchanged notices are included in `licenses/`:

- Radix Colors, commit `dbdb85470547c7d34b9001f48fddb08ded335979`: selected color tokens; full MIT notice in `licenses/radix-colors.txt`.
- Lucide, commit `20aef31db93fe4d9f398dbb15b120d99c48eef95`: SVG geometry; full upstream ISC and Feather-derived MIT notices in `licenses/lucide.txt`.
- Inter, official `rsms/inter` commit `353b61b9f4430d5f420d56605a6e7993e0941470`: unchanged `awrc/static/InterVariable.woff2`; full SIL Open Font License 1.1 in `licenses/inter-OFL.txt`. Font SHA256: `693b77d4f32ee9b8bfc995589b5fad5e99adf2832738661f5402f9978429a8e3`.

The original `licenses/source-manifest.json` retains upstream source pins, including inspected shadcn and Tremor references. No code or assets from those two inspected projects are bundled. No upstream endorsement is implied. These asset licenses do not license the whole application.
