# AI Workflow Reliability Console (AWRC)

**Local evidence inspection application — source snapshot, October 28, 2026.**

AWRC is a local evidence console for inspecting what an agent workflow claims happened. It preserves raw source bytes, separates imported claims from verified facts, compares compatible records, and exports inspectable JSON and Markdown. A green-looking imported result does not become authenticated proof.

## Run locally

Use an existing Python 3.12+ installation. No Python package installation, model, credentials or network service is needed. Extract to a physical local directory and run from this archive's root:

```sh
mkdir -p demo-state
python3 -m awrc --db demo-state/evidence.sqlite import fixtures/success.json
python3 -m awrc --db demo-state/evidence.sqlite import examples/success-illustrative-failed-check.json
python3 -m awrc --db demo-state/evidence.sqlite import examples/success-illustrative-scope.json
python3 -m awrc --db demo-state/evidence.sqlite serve --port 0
```

Open the loopback URL printed by the server. Import the remaining synthetic fixtures to inspect denial, pending approval and incomplete evidence. The local server requires permission to bind a loopback socket.

The preserved ARMS example contains a separately reviewed historical synthetic repair. To inspect it as data and import its transport:

```sh
python3 -m awrc.arms_adapter fixtures/arms-native > demo-state/native-inspection.json
python3 -m awrc --db demo-state/evidence.sqlite import demo-state/native-inspection.json
```

Imported reviewer identity remains unauthenticated. The original evidence strings and source-era limitations are preserved, including historical text predating the current UI import path.

## Reproduce the illustrative comparisons

The two `examples/` inputs are the exact fixture variants displayed in the portfolio captures. The failed-check variant changes one task check from passed to failed, changes `task_success` to false, and changes the supporting artifact text and its matching SHA256. The different-scope variant changes only `scope_revision`. These are imported data revisions; no workflow was executed to create them.

After the three imports above, these commands reproduce the compatible comparison, the explicit scope refusal, and the JSON export:

```sh
awrc_baseline_digest=e336397a100c25acfd6b7891cbb5d861d3bc2b36ce9a0fb3f1f83b1742c10fbd
awrc_failed_check_digest=ac659d03bacb5bf673cd3a7a6c6a9f72da9a5d177a88e963ad896fe2c31164fd
awrc_other_scope_digest=0e010332db12ac3f2418049e7c47a1c1b841817c3454e437b2d9e17bfc2f1998
python3 -m awrc --db demo-state/evidence.sqlite compare "$awrc_baseline_digest" "$awrc_failed_check_digest"
python3 -m awrc --db demo-state/evidence.sqlite compare "$awrc_baseline_digest" "$awrc_other_scope_digest"
python3 -m awrc --db demo-state/evidence.sqlite export-comparison "$awrc_baseline_digest" "$awrc_failed_check_digest" --format json > demo-state/comparison.json
```

The first comparison is compatible and exposes the changed task check. The second is refused with `Different scope_revision`. Both retain `independently_verified: false`. The exact captured export is included as [verification/awrc-comparison-example.json](verification/awrc-comparison-example.json); a fresh CLI check reproduced its bytes with the imports in this order and a new empty database. The bounded check receipt is [verification/illustrative-comparison-check.json](verification/illustrative-comparison-check.json).

## Verification

```sh
python3 verification/run_tests.py
node --test tests/test_client.mjs tests/test_comparison_view.mjs tests/test_envelope_view.mjs
```

The Python helper only relocates the tests' explicit macOS temporary-directory path into a fresh physical directory. It runs the unchanged full suite, including actual loopback HTTP tests, and writes fresh results outside historical receipts. Restricted environments may refuse socket creation; that is not a passing test result. On the original macOS environment, `python3 -m unittest discover -s tests -v` is also the documented native path.

The October 28 builder run passed **87 Python methods**, including **14 HTTP methods** and **44 historical conformance vectors**. A separate agent review ran **seven focused methods and 40 additional parser probes**. The latest consumer correction preserves nanosecond ordering across all supported one-to-nine-digit timestamp fractions and timezone offsets. This establishes internal ordering consistency, not when events really occurred.

See `verification/awrc-verification.json`, `PROVENANCE.json`, and `PUBLICATION-MANIFEST.json` for exact source identities, included receipts and file hashes. Full-suite results were inspected by the separate reviewer, not independently rerun. No new browser acceptance run is claimed.

## Scope

This is a local data-only work sample. It does not run ARMS, authenticate imported reviewers, authorize actions, publish pull requests, or establish general EV interoperability. The archive contains application code, tests, finite synthetic fixtures and necessary notices. It is a curated source export: product code and included original evidence are byte-identical to the pinned source. The illustrative capture inputs are separately identified derivatives, with no changes to the original fixtures. The public documentation and portable test helper describe this exported layout.

See `NOTICE.md` for project-license status and `THIRD_PARTY_NOTICES.md` for retained asset notices.
