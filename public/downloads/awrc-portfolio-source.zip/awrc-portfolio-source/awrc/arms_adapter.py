"""Bounded read-only native ARMS inspection; never executes imported content."""
import base64
import copy
import hashlib
import json
import math
import os
import re
import sys
from . import arms_profile as profile
from .validation import read_bundle_file

ARTIFACTS = dict(baseline_checks="baseline-checks.json", candidate_checks="candidate-checks.json",
                 patch="repair.patch", journal="journal.json", source_hashes="source-hashes.json")
FILES = ("evidence.json", "reviewed-evidence.json", "review-receipt.json", *ARTIFACTS.values())
MAX_TOTAL_BYTES = 2 * 1024 * 1024

# Data-only oracle reconstructed from pinned source/arms/fixture.py:20-22,42-67.
# This does not import its AST interpreter, execute candidates, or rerun ARMS.
FIXTURE_ID = "retry-backoff-v1"
VERIFIER_VERSION = "arms-restricted-python/0.1"
SUITE_DIGEST = "71a512ba74fcbcdcd81a84fba949305cbe18de6cde304966b22b2347d2d76459"
EXPECTED_CASES = {
    f"retry-a{attempt}-{label}": base_delay * (2 ** attempt)
    for attempt in (0, 1, 2, 3, 4, 5)
    for label, base_delay in (("zero", 0), ("half", 0.5), ("two", 2))
}


def require(condition):
    if not condition:
        raise ValueError("Invalid ARMS offline profile")


def load(raw):
    def pairs(items):
        obj = {}
        for key, value in items:
            require(key not in obj)
            obj[key] = value
        return obj
    def constant(_):
        raise ValueError("Invalid numeric constant")
    try:
        obj = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
        profile.canonical_bytes(obj)
        return obj
    except (RecursionError, OverflowError, UnicodeError) as exc:
        raise ValueError("Invalid JSON") from exc


def fields(obj, names):
    require(type(obj) is dict and set(obj) == set(names.split()))


def checks(raw, config, expected_pass):
    obj = load(raw)
    fields(obj, "checks passed suite_digest verifier_version")
    require(config["suite_digest"] == SUITE_DIGEST and config["verifier_version"] == VERIFIER_VERSION)
    require(obj["suite_digest"] == config["suite_digest"] and obj["verifier_version"] == config["verifier_version"])
    require(type(obj["checks"]) is list and 1 <= len(obj["checks"]) <= 256)
    ids = set()
    for case in obj["checks"]:
        fields(case, "id actual expected passed")
        name = case["id"]
        require(type(name) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", name))
        require(name not in ids)
        ids.add(name)
        for key in ("actual", "expected"):
            require(type(case[key]) in (int, float))
            try:
                require(math.isfinite(case[key]))
            except OverflowError as exc:
                raise ValueError("Invalid number") from exc
        require(type(case["passed"]) is bool and case["passed"] == (case["actual"] == case["expected"]))
    require({case["id"]: case["expected"] for case in obj["checks"]} == EXPECTED_CASES)
    passed = sum(case["passed"] for case in obj["checks"])
    require(type(obj["passed"]) is bool and obj["passed"] == (passed == len(ids)))
    require(obj["passed"] == expected_pass)
    return {**obj, "passed_count": passed, "failed_count": len(ids)-passed, "total_count": len(ids),
            "exit_code": 0 if expected_pass else 1,
            "interpretation": "candidate checks passed" if expected_pass else "expected regression failure"}


def inspect_run(directory):
    """Read only eight fixed basenames in an explicit operator-supplied directory."""
    raw = {}
    total = 0
    for name in FILES:
        raw[name] = read_bundle_file(os.path.join(os.fspath(directory), name))
        total += len(raw[name])
        require(total <= MAX_TOTAL_BYTES)
    return inspect_files(raw)


def inspect_files(raw):
    """Inspect exactly eight bounded byte strings without filesystem access."""
    require(type(raw) is dict and set(raw) == set(FILES))
    require(all(type(data) is bytes and len(data) <= 1_048_576 for data in raw.values()))
    require(sum(map(len, raw.values())) <= MAX_TOTAL_BYTES)
    original = profile.loads_evidence(raw["evidence.json"])
    reviewed = profile.loads_evidence(raw["reviewed-evidence.json"])
    require(original["task"]["fixture_id"] == FIXTURE_ID)
    require(original["provenance"]["adapter"] == "native-json")
    require(original["provenance"]["review_state"] == "pending")
    require(original["outcome"] == dict(execution="completed", verification="verified", task_success=False,
                                         reason_code="awaiting_independent_review"))
    require(original["source"]["head_sha"] is not None and original["source"]["tree_sha"] is not None)
    receipt_raw = raw["review-receipt.json"]
    require(len(receipt_raw) <= 8192)
    receipt = load(receipt_raw)
    fields(receipt, "run_id head_sha evidence_sha256 reviewer decision blocking_findings notes")
    require(receipt["run_id"] == original["run_id"] and receipt["head_sha"] == original["source"]["head_sha"])
    require(receipt["evidence_sha256"] == profile.digest(original))
    reviewer = receipt["reviewer"]
    require(type(reviewer) is str and 1 <= len(reviewer) <= 128)
    require(reviewer.strip().casefold() != original["provenance"]["builder"].strip().casefold())
    require(receipt["decision"] in ("approved", "changes_requested"))
    require(type(receipt["blocking_findings"]) is int and receipt["blocking_findings"] >= 0)
    require(receipt["decision"] != "approved" or receipt["blocking_findings"] == 0)
    require(type(receipt["notes"]) is str and len(receipt["notes"]) <= 4096)
    receipt_digest = hashlib.sha256(receipt_raw).hexdigest()
    require(receipt_digest == profile.digest(receipt))
    expected = copy.deepcopy(original)
    expected["provenance"].update(reviewer=reviewer, reviewed_head=receipt["head_sha"],
                                  review_state=receipt["decision"], review_receipt_sha256=receipt_digest)
    approved = receipt["decision"] == "approved"
    expected["outcome"].update(task_success=approved,
                               reason_code="reviewed_synthetic_fix" if approved else "review_changes_requested")
    require(reviewed == expected)
    artifacts = {key: raw[name] for key, name in ARTIFACTS.items()}
    for envelope in (original, reviewed):
        profile.verify_artifacts(envelope, artifacts)
        require(envelope["commands"] == [dict(id="baseline_checks", exit_code=1, artifact_id="baseline_checks"),
                                          dict(id="candidate_checks", exit_code=0, artifact_id="candidate_checks")])
    baseline = checks(artifacts["baseline_checks"], original["configuration"], False)
    candidate = checks(artifacts["candidate_checks"], original["configuration"], True)
    require({x["id"]: x["expected"] for x in baseline["checks"]} ==
            {x["id"]: x["expected"] for x in candidate["checks"]})
    return dict(schema_version="awrc.arms-inspection.v0.1", read_only=True, independently_verified=False,
                review_provenance="imported unauthenticated attestation", authority=None, publication_permission=None,
                original=original, reviewed=reviewed, receipt=receipt, original_canonical_sha256=profile.digest(original),
                files={name: dict(sha256=hashlib.sha256(data).hexdigest(), size_bytes=len(data),
                                 base64=base64.b64encode(data).decode("ascii")) for name, data in raw.items()},
                baseline=baseline, candidate=candidate,
                measurements=dict(source_reported_runner_duration_seconds=original["metrics"]["duration_seconds"],
                                  human_minutes=None, cost_amount=None, cost_currency=None),
                limitations=["Byte consistency is not authorship or independent verification.",
                             "Historical offline native fixture only; no rerun, UI import, or final EV conformance.",
                             "Runner duration is source-reported, not model or human duration."] + original["limitations"])


def main():
    try:
        require(len(sys.argv) == 2)
        report = inspect_run(sys.argv[1])
        output = json.dumps(report, allow_nan=False, sort_keys=True)
    except (ValueError, OSError, TypeError, RecursionError, OverflowError):
        print("Unsupported or invalid ARMS offline bundle", file=sys.stderr)
        return 1
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
