"""Derived trust labels and inert operator reports; never verifies source claims."""
import json


def assess(bundle):
    if bundle["schema_version"] == "ev.v0.1":
        return {"independently_verified": False, "evidence_status": "unverified",
                "notice": "Display projection only, not fixture validation. Case evidence and artifact content are unavailable; "
                          "source claims and review are unauthenticated. Policy and authority are not supplied."}
    if bundle["schema_version"] == "awrc.arms-inspection.v0.1":
        return {"independently_verified": False, "evidence_status": "source_reported",
                "notice": "Imported native claims are untrusted; review is unauthenticated. Policy and authority are not supplied."}
    commands = bundle["commands"]
    supported = bool(commands) and all(command["exit_code"] == 0 and command["artifact_ids"] for command in commands)
    return {"independently_verified": False,
            "evidence_status": "source_reported" if supported else "unverified",
            "notice": "Imported claims are untrusted. JSON integrity is not authenticity."}


def _escape(text):
    # Entity-encode Markdown/HTML punctuation, including ':' to disable bare URL
    # autolinking. Newlines become inert entities so they cannot introduce blocks.
    special = set('&<>"\'\\`*_{}[]()#+-.!|:~\n\r\t')
    return "".join(f"&#{ord(char)};" if char in special or ord(char) < 32 or ord(char) == 127 else char for char in str(text))


def report(record, format):
    """Render the exact inspection record as JSON, or safely escaped Markdown."""
    if format == "json":
        return json.dumps(record, ensure_ascii=True, allow_nan=False, sort_keys=True, indent=2) + "\n"
    if format != "markdown":
        raise ValueError("Unsupported report format")
    bundle = record["bundle"]
    lines = ["# AWRC evidence record", "", f"Raw SHA256: {_escape(record['raw_sha256'])}",
             f"Revision: {record['revision']}", "", "## Effective assessment", "",
             "independently_verified: false", f"Evidence status: {_escape(record['assessment']['evidence_status'])}",
             "Imported claims are untrusted. JSON integrity is not authenticity.", "",
             "Timing: unknown" if bundle["timing"] is None else "Timing: source reported",
             "Cost: unknown" if bundle["cost"]["kind"] == "unknown" else "Cost: source reported",
             "", "## Display projection (untrusted; not fixture validation)" if "source_evidence" in record
             else "## Validated source data (untrusted)", ""]
    # Each complete scalar is escaped, including artifact text. No uploaded content
    # enters a code fence or an HTML attribute, whose delimiters it could break.
    def walk(value, path):
        if isinstance(value, dict):
            for key in sorted(value):
                walk(value[key], path + [key])
        elif isinstance(value, list):
            if not value:
                lines.append(f"- {_escape('.'.join(path))}: empty list")
            for index, item in enumerate(value):
                walk(item, path + [str(index)])
        else:
            rendered = "unknown" if value is None else json.dumps(value, ensure_ascii=True)
            lines.append(f"- {_escape('.'.join(path))}: {_escape(rendered)}")
    walk(bundle, [])
    if "source_inspection" in record:
        lines.extend(["", "## Complete native source inspection (untrusted)", ""])
        walk(record["source_inspection"], ["source_inspection"])
    if "source_evidence" in record:
        lines.extend(["", "## Complete raw EV source envelope (untrusted)", ""])
        walk(record["source_evidence"], ["source_evidence"])
        lines.extend(["", "## Exact source bytes (integrity only)", ""])
        walk(record["source_bytes"], ["source_bytes"])
        lines.extend(["", "Case evidence and artifact content unavailable. Review is unauthenticated; "
                      "policy, authority and publication permission are not supplied."])
    return "\n".join(lines) + "\n"


def comparison_report(store, a, b, format):
    """Export the store's sole comparison calculation and both revalidated records."""
    if format not in ("json", "markdown"):
        raise ValueError("Unsupported report format")
    value = {
        "schema_version": "awrc.comparison-report.v0.1",
        "independently_verified": False,
        "comparison": store.compare(a, b),
        "records": {"a": store.get(a), "b": store.get(b)},
        "limitations": [
            "Imported claims are untrusted; review is unauthenticated. JSON integrity is not authenticity.",
            "Unknowns remain unknown. No composite score, automatic improvement, timing or cost inference is calculated.",
            "Native comparisons use candidate cases only; each original baseline remains in its source inspection.",
            "Imported report revisions are not new workflow runs. No workflow or original evaluation is executed.",
            "Reports retain imported evidence and are not a secret detector.",
        ],
    }
    if format == "json":
        return json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True, indent=2) + "\n"
    lines = ["# AWRC comparison evidence report", "", "independently_verified: false", "",
             "Complete canonical comparison and revalidated records (untrusted).",
             "Null values are shown as unknown; no missing evidence is inferred.", ""]

    def walk(item, path):
        if isinstance(item, dict) and item:
            for key in sorted(item):
                walk(item[key], path + [key])
        elif isinstance(item, list) and item:
            for index, child in enumerate(item):
                walk(child, path + [str(index)])
        else:
            rendered = "unknown" if item is None else json.dumps(item, ensure_ascii=True, allow_nan=False)
            lines.append(f"- {_escape('.'.join(path))}: {_escape(rendered)}")

    walk(value, [])
    return "\n".join(lines) + "\n"
