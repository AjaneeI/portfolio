"""Data-only EV envelope intake; projection is not fixture validation or proof."""
import base64
import hashlib

from .arms_profile import loads_evidence

FORMAT = 'ev.v0.1'


def ingest_envelope(raw):
    """Validate exact source bytes with the unchanged producer-compatible parser."""
    source = loads_evidence(raw)
    return {
        'format': FORMAT,
        'source_evidence': source,
        'source_bytes': {
            'base64': base64.b64encode(raw).decode('ascii'),
            'sha256': hashlib.sha256(raw).hexdigest(),
            'size_bytes': len(raw),
        },
        'bundle': present(source),
    }


def present(source):
    """Display source claims without manufacturing case or artifact support."""
    task = source['task']
    outcome = source['outcome']
    return dict(
        schema_version=FORMAT, workflow_id='arms-native-envelope', run_id=source['run_id'],
        task_id=task['task_id'], scope_revision=task['scope_revision'],
        source={**source['source'], 'repository': task['repository'], 'synthetic': None},
        configuration={**source['configuration'], 'fixture_id': task['fixture_id']},
        outcome=dict(execution_status=outcome['execution'], task_success=outcome['task_success'],
                     claimed_verification=outcome['verification'], reason_code=outcome['reason_code'],
                     policy_outcome=None),
        commands=[dict(id=command['id'], exit_code=command['exit_code'], artifact_ids=[])
                  for command in source['commands']],
        checks=[], artifacts=[], timing=source['timestamps'], cost={'kind': 'unknown'},
    )
