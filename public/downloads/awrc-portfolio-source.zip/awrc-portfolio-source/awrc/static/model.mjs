// Pure client view state; no alteration of evidence, trust or stored selections.
export function outcomeKey(bundle) {
  if (bundle.outcome.task_success === true) return 'success';
  if (bundle.outcome.task_success === false) return 'not_completed';
  return bundle.outcome.execution_status === 'pending' ? 'pending' : 'unknown';
}
export function filterRecords(records, {query = '', outcome = '', policy = '', evidence = ''} = {}) {
  const needle = query.trim().toLocaleLowerCase();
  return records.filter(record => {
    const bundle = record.bundle;
    const matchesText = !needle || [bundle.workflow_id, bundle.run_id, bundle.task_id]
      .some(text => text.toLocaleLowerCase().includes(needle));
    return matchesText && (!outcome || outcomeKey(bundle) === outcome) &&
      (!policy || (bundle.outcome.policy_outcome ?? 'unknown') === policy) &&
      (!evidence || record.assessment.evidence_status === evidence);
  });
}
export function visibleActive(visible, active) {
  return visible.some(record => record.raw_sha256 === active) ? active : undefined;
}
export function toggleSelection(selected, digest) {
  const next = new Set(selected);
  if (next.has(digest)) next.delete(digest);
  else if (next.size < 2) next.add(digest);
  return next;
}
export function selectionInfo(selected, visible) {
  const visibleDigests = new Set(visible.map(record => record.raw_sha256));
  return {count: selected.size, hidden: [...selected].filter(digest => !visibleDigests.has(digest)).length};
}

// Compact native display only; exact source timestamps remain in source_inspection.
export function nativeTimingFacts(source) {
  const date = new Date(source.reviewed.timestamps.ended_at);
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const pad = number => String(number).padStart(2, '0');
  const ended = Number.isFinite(date.getTime()) ? `${pad(date.getUTCDate())} ${months[date.getUTCMonth()]} ${date.getUTCFullYear()} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} UTC (source-reported)` : 'Unknown';
  const seconds = source.measurements.source_reported_runner_duration_seconds;
  const duration = typeof seconds === 'number' && Number.isFinite(seconds) && seconds >= 0 ? `${seconds} s (source-reported; not model or human time)` : 'Unknown';
  return [['Run ended', ended], ['Runner duration', duration]];
}
