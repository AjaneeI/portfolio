import {icon} from './icons.js';
import {outcomeKey, nativeTimingFacts} from './model.mjs';

// Imported content is always textContent. Only pinned, trusted Lucide SVGs are parsed.
export function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = String(text);
  if (className) node.className = className;
  return node;
}
export function value(item) { return item === null ? 'Unknown' : String(item); }
export function evidence(record) {
  return record.assessment.evidence_status === 'source_reported' ? 'Source-reported' : 'Unverified';
}
export function task(bundle) {
  return ({success:'Success', not_completed:'Not completed', pending:'Pending', unknown:'Unknown'})[outcomeKey(bundle)];
}
export function policy(bundle) {
  return ({allow:'Allowed', denied:'Denied', needs_approval:'Approval required', not_evaluated:'Not evaluated'})[bundle.outcome.policy_outcome] ?? 'Unknown / not supplied';
}
export function taskTone(bundle) {
  return ({success:'mint', not_completed:'muted', pending:'amber', unknown:'muted'})[outcomeKey(bundle)];
}
export function policyTone(bundle) {
  return ({allow:'mint', denied:'red', needs_approval:'amber', not_evaluated:'muted'})[bundle.outcome.policy_outcome] ?? 'muted';
}
export function statusLabel(text, tone) {
  const label = el('span', undefined, 'status-label');
  label.append(icon('circle-check', `status-dot tone-${tone}`), el('span', text));
  return label;
}
function definitions(entries, className = 'facts') {
  const dl = el('dl', undefined, className);
  for (const [name, content] of entries) {
    const row = el('div'); row.append(el('dt', name), el('dd', content)); dl.append(row);
  }
  return dl;
}
function disclosure(target, title, content) {
  const details = el('details'); details.append(el('summary', title), content); target.append(details); return details;
}
function emptyInspector(target, filtered) {
  const region = el('div', undefined, 'inspector-empty');
  region.append(icon('file-check'), el('h2', 'Inspect run evidence'),
    el('p', filtered ? 'The inspected run is outside this view. Select a visible run or clear the filters.' :
      'Select a run to inspect its outcome, checks and source provenance.'));
  target.replaceChildren(region);
}
async function copySource(name, text, notify) {
  try { await navigator.clipboard.writeText(text); notify(`${name} copied in full.`); }
  catch {
    const input = document.getElementById('copy-value'); input.value = text;
    document.getElementById('copy-dialog').showModal(); input.focus(); input.select();
  }
}
export function renderDetail(target, record, notify, filtered = false) {
  if (!record) { emptyInspector(target, filtered); return; }
  target.replaceChildren();
  const bundle = record.bundle;
  const heading = el('div', undefined, 'inspector-heading'), name = el('div');
  name.append(el('h2', bundle.workflow_id), el('span', `${bundle.run_id} · revision ${record.revision}`, 'run-sub'));
  const raw = el('button'); raw.append(icon('file-check'), el('span', 'View raw record'));
  raw.addEventListener('click', () => {
    document.getElementById('raw-record').textContent = JSON.stringify(record, null, 2);
    document.getElementById('record-dialog').showModal();
  });
  heading.append(name, raw); target.append(heading);
  const bench = el('div', undefined, 'inspection-bench');
  const outcome = el('section', undefined, 'bench-column'); outcome.append(el('h3', 'Reported outcome'));
  const outcomeHead = el('div', undefined, 'outcome-head'), outcomeCopy = el('div');
  const description = ({success:'The imported report says this task succeeded.', not_completed:'The imported source reports the task was not completed.',
    pending:'The imported source reports a pending decision.', unknown:'The source does not establish a task outcome.'})[outcomeKey(bundle)];
  outcomeCopy.append(el('p', task(bundle), 'outcome-title'), el('p', record.source_inspection?.receipt.decision === 'changes_requested' ? 'The imported report says the checks passed, but its reviewer requested changes. The task is still not completed.' : description, 'outcome-description'));
  outcomeHead.append(icon('circle-check', `status-dot tone-${taskTone(bundle)}`), outcomeCopy);
  outcome.append(outcomeHead, el('p', 'This Console checks the evidence files. A separate trusted check has not confirmed the task result.', 'outcome-description'), definitions([
    ['Policy', policy(bundle)], ['Evidence', evidence(record)], ['Independently verified', 'No'],
    ...(record.source_inspection ? nativeTimingFacts(record.source_inspection) : [
      ['Recorded', 'Unknown'],
      ['Time', bundle.timing === null ? 'Unknown' : `${bundle.timing.started_at} → ${bundle.timing.ended_at} (source-reported)`]
    ]),
    ['Cost', bundle.cost.kind === 'unknown' ? 'Unknown' : `${bundle.cost.value} ${bundle.cost.currency} (${bundle.cost.kind}, source-reported)`],
    ['Synthetic', bundle.source.synthetic === true ? 'Yes (source-reported)' : bundle.source.synthetic === false ? 'No (source-reported)' : 'Unknown']
  ]));
  const checks = el('section', undefined, 'bench-column'); checks.append(el('h3', 'Checks'));
  const sources = el('section', undefined, 'bench-column provenance-column'); sources.append(el('h3', 'Source provenance'));
  const provenance = el('div', undefined, 'provenance');
  for (const [label, text] of [['Repository',bundle.source.repository], ['Base',bundle.source.base_sha], ['Head',bundle.source.head_sha],
    ['Tree',bundle.source.tree_sha], ['Raw (SHA256)',record.raw_sha256], ['Scope',bundle.scope_revision]]) {
    const displayed = value(text);
    const row = el('div', undefined, 'source-row'), content = el('span', displayed, 'source-value' + (label === 'Repository' ? ' repository' : ''));
    const copy = el('button', undefined, 'copy-source'); copy.append(icon('copy'));
    copy.setAttribute('aria-label', `Copy ${label} in full`); copy.title = `Copy ${label} in full`;
    content.title = displayed;
    copy.addEventListener('click', () => copySource(label, displayed, notify));
    row.append(el('span', label, 'source-name'), content, copy); provenance.append(row);
  }
  sources.append(provenance); bench.append(outcome, checks, sources); target.append(bench);
  const footer = el('div', undefined, 'inspection-footer'), full = el('details', undefined, 'full-details'), summary = el('summary');
  summary.append(icon('chevron-down'), el('span', 'Full evidence details')); full.append(summary);
  const sections = el('div', undefined, 'evidence-sections');
  for (const [kind, label] of [['task','Task checks'],['safety','Safety checks']]) {
    const cases = bundle.checks.filter(item => item.kind === kind);
    const counts = {passed:cases.filter(item=>item.outcome==='passed').length, failed:cases.filter(item=>item.outcome==='failed').length,
      unknown:cases.filter(item=>item.outcome==='unknown').length};
    const group = el('div', undefined, 'check-group'), button = el('button', undefined, 'check-trigger');
    const tone = counts.failed ? 'red' : counts.unknown || !cases.length ? 'muted' : 'mint';
    button.append(icon('circle-check', `status-dot tone-${tone}`), el('span', cases.length ? `${counts.passed} / ${cases.length} passed` : `No ${kind} cases supplied / unknown`), icon('chevron-right'));
    group.append(el('p', label, 'check-heading'), button, el('p', `${counts.failed} failed · ${counts.unknown} unknown`, 'check-count'));
    checks.append(group);
    const disclosure_ = disclosure(sections, `${label} — every source-reported case`, el('pre', JSON.stringify(cases,null,2)));
    button.addEventListener('click', () => { full.open = true; disclosure_.open = true; disclosure_.scrollIntoView({block:'nearest'}); disclosure_.querySelector('summary').focus(); });
  }
  disclosure(sections, 'Imported claims and metadata', definitions([
    ['Schema',bundle.schema_version], ['Task ID',bundle.task_id], ['Execution',bundle.outcome.execution_status],
    ['Source verification claim',`${bundle.outcome.claimed_verification} (imported claim, not effective verification)`],
    ...(record.source_evidence ? [['Reason code',bundle.outcome.reason_code]] : []),
    ['Task success claim',value(bundle.outcome.task_success)], ['Policy claim',bundle.outcome.policy_outcome ?? 'Unknown / not supplied'],
    ['Effective assessment notice',record.assessment.notice]
  ]));
  if (record.source_inspection) {
    const native = record.source_inspection;
    for (const [title, data] of [
      ['ARMS original versus reviewed outcome claims', {original:native.original.outcome, reviewed:native.reviewed.outcome}],
      [`ARMS expected failing baseline — ${native.baseline.passed_count} passed / ${native.baseline.total_count}, ${native.baseline.failed_count} failed, exit ${native.baseline.exit_code}`, native.baseline],
      [`ARMS candidate — ${native.candidate.passed_count} passed / ${native.candidate.total_count}, exit ${native.candidate.exit_code}`, native.candidate],
      ['ARMS stages, exact source timestamps and review IDs (unauthenticated)', {timestamps:native.reviewed.timestamps, measurements:native.measurements, events:native.reviewed.events, provenance:native.reviewed.provenance, receipt:native.receipt}],
      ['ARMS limitations, authority and raw file references', {limitations:native.limitations, authority:native.authority, publication_permission:native.publication_permission, files:native.files}]
    ]) disclosure(sections, title, el('pre', JSON.stringify(data,null,2)));
  }
  if (record.source_evidence) {
    disclosure(sections, 'Complete raw EV source envelope (untrusted)', el('pre', JSON.stringify(record.source_evidence,null,2)));
    disclosure(sections, 'Exact source bytes (integrity only)', el('pre', JSON.stringify(record.source_bytes,null,2)));
    disclosure(sections, 'Unavailable evidence and trust', el('p',
      'Display projection only; not fixture validation. Case evidence and artifact content are unavailable. ' +
      'Declared artifact descriptors and command references remain in the source envelope; no attached bytes were supplied. ' +
      'Source claims and review are unauthenticated. Policy, authority and publication permission are not supplied. ' +
      'Original runtime and upstream model/provider are unknown. Raw envelope comparisons are unavailable.'));
  }
  disclosure(sections, 'Configuration', el('pre',JSON.stringify(bundle.configuration,null,2)));
  disclosure(sections, 'Commands (data only)', el('pre',JSON.stringify(bundle.commands,null,2)));
  const artifacts = el('div');
  for (const artifact of bundle.artifacts) artifacts.append(el('p',`${artifact.id} · SHA256 ${artifact.sha256}`,'comparison-refs'),el('pre',artifact.text));
  if (!bundle.artifacts.length) artifacts.append(el('p','No artifacts recorded.','muted'));
  disclosure(sections, 'Artifacts (data only)', artifacts);
  sections.append(el('p','Imported claims remain untrusted. Hashes establish byte integrity, not authorship or truth. ' +
    'Missing evidence stays unverified. No workflow, command, path or URL is executed or fetched. ' +
    (record.source_evidence ? 'Raw EV envelope only; general EV support and the final shared evidence contract remain open.' : record.source_inspection ? 'Pinned native profile only; general EV support and the final shared evidence contract remain open.' : 'This record uses the Console fixture dialect. Native ARMS imports use a separate pinned profile; general EV support remains open.'),'footnote'));
  full.append(sections);
  const exports = el('div',undefined,'exports');
  for (const [format,label] of [['json','Export JSON'],['markdown','Export Markdown']]) {
    const link=el('a',undefined,'export');link.href=`/api/export/${record.raw_sha256}?format=${format}`;link.download='';
    link.append(icon('file-check'),el('span',label));exports.append(link);
  }
  footer.append(full,exports);target.append(footer);
}
export function renderComparison(target,result) {
  const exports=el('div',undefined,'exports');
  for (const [format,label] of [['json','Export comparison JSON'],['markdown','Export comparison Markdown']]) {
    const link=el('a',label,'export');link.href=`/api/export-comparison?a=${encodeURIComponent(result.a)}&b=${encodeURIComponent(result.b)}&format=${format}`;link.download='';
    exports.append(link);
  }
  target.replaceChildren(el('p',`A: ${result.a}\nB: ${result.b}`,'comparison-refs'));
  target.append(el('p','Source-reported comparison. No run is independently verified.','notice'));
  if (result.comparison_stage) target.append(el('p', 'ARMS candidate cases only. Each original baseline remains in its source inspection. These are imported report revisions, not new workflow runs.', 'notice'));
  if (!result.compatible) {target.append(el('p',`Incompatible comparison: ${result.reason}. Counts and improvement are not calculated.`,'comparison-note'),exports);return;}
  for (const side of ['a','b']) {
    target.append(el('h3',`Run ${side.toUpperCase()} denominators`));
    const entries=['task','safety'].map(kind=>{const c=result.counts[side][kind];return [kind==='task'?'Task checks':'Safety checks',c.total ? `${c.passed} / ${c.total} passed · ${c.failed} failed · ${c.unknown} unknown` : 'No cases supplied / unknown'];});
    const outcome=result.outcomes[side];entries.push(['Task success',value(outcome.task_success)],['Policy',outcome.policy_outcome ?? 'Unknown / not supplied'],['Evidence',result.assessments[side].evidence_status]);
    target.append(definitions(entries,'comparison-facts'));
  }
  const scroll=el('div',undefined,'table-scroll');scroll.tabIndex=0;scroll.setAttribute('role','region');scroll.setAttribute('aria-label','Every compared check');
  const table=el('table',undefined,'comparison-table'),head=el('thead'),header=el('tr');
  for (const title of ['Check','Kind','Run A','Run B']) {const th=el('th',title);th.scope='col';header.append(th);}head.append(header);table.append(head);
  const body=el('tbody');for(const item of result.cases){const row=el('tr');for(const key of ['id','kind','a','b'])row.append(el('td',item[key]));body.append(row);}table.append(body);scroll.append(table);
  target.append(scroll,el('p','Every case is shown. No composite score or automatic improvement claim is calculated.','footnote'),exports);
}
