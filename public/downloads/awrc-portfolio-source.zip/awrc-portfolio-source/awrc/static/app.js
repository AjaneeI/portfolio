import * as api from './api.js';
import {icon} from './icons.js';
import {filterRecords, visibleActive, toggleSelection, selectionInfo} from './model.mjs';
import {el, task, policy, evidence, taskTone, policyTone, statusLabel, renderDetail, renderComparison} from './view.js';

const $ = id => document.getElementById(id);
let selected = new Set(), records = [], visible = [], active, busy = false, connected = false, fileBytes;
let toastTimer;
for (const marker of document.querySelectorAll('[data-icon]')) marker.replaceWith(icon(marker.dataset.icon));
const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
$('search-shortcut').textContent = isMac ? '⌘ K' : 'Ctrl K';
function message(text, quiet = false) {
  $('status').textContent = text; $('status').className = quiet ? 'visually-hidden' : 'toast';
  clearTimeout(toastTimer);
  if (!quiet) toastTimer = setTimeout(() => { $('status').className = 'visually-hidden'; }, 6500);
}
function error(text) { $('error').hidden = !text; $('error').textContent = text || ''; }
function filters() {
  return {query:$('search').value,outcome:$('outcome-filter').value,policy:$('policy-filter').value,evidence:$('evidence-filter').value};
}
function controls() {
  for (const id of ['fixtures','open-import']) $(id).disabled = busy || !connected;
  $('refresh').disabled = busy;
  $('compare').disabled = $('compare-nav').disabled = busy || selected.size !== 2;
  const info = selectionInfo(selected,visible);
  $('selection-count').textContent = `${info.count} selected${info.hidden ? ` · ${info.hidden} hidden` : ''}`;
  $('compare-label').textContent = `Compare ${info.count}`;
  $('clear-selection').hidden = !info.count;
  for (const checkbox of $('runs').querySelectorAll('input')) checkbox.disabled = !checkbox.checked && selected.size === 2;
}
function inspect(record) {
  active = record.raw_sha256;
  for (const row of $('runs').children) row.classList.toggle('active',row.dataset.digest === active);
  renderDetail($('detail'),record,message);
}
function render() {
  visible = filterRecords(records,filters());
  const lostActive = active !== undefined && !visibleActive(visible,active);
  active = visibleActive(visible,active);
  const body = $('runs'); body.replaceChildren();
  $('empty').hidden = visible.length !== 0;
  $('empty-title').textContent = records.length ? 'No runs match this view' : 'No evidence imported';
  $('empty-copy').textContent = records.length ? 'Try another search or clear the filters. Comparison selections stay saved across views.' :
    'Import a bundle or use the local workspace menu to explicitly load synthetic fixtures.';
  $('clear-filters').hidden = !records.length;
  $('filtered-count').hidden = visible.length === records.length;
  $('filtered-count').textContent = `${visible.length} of ${records.length} evidence revisions shown. Comparison selections persist across filters.`;
  $('record-count').textContent = `${records.length} imported revision${records.length === 1 ? '' : 's'}`;
  $('workspace-kind').textContent = !records.length ? 'Local · Empty' : records.every(record=>record.bundle.source.synthetic) ? 'Local · Synthetic' : 'Local · Imported';
  for (const record of visible) {
    const bundle = record.bundle, digest = record.raw_sha256, row = el('tr'); row.dataset.digest = digest;
    if (active === digest) row.className = 'active';
    const checkbox = el('input'); checkbox.type = 'checkbox'; checkbox.checked = selected.has(digest);
    checkbox.setAttribute('aria-label',`Compare ${bundle.workflow_id} / ${bundle.run_id} revision ${record.revision}`);
    checkbox.addEventListener('change',()=>{selected=toggleSelection(selected,digest);checkbox.checked=selected.has(digest);controls();});
    const cell = el('td'), checkboxControl = el('label', undefined, 'checkbox-control');
    checkboxControl.append(checkbox, icon('check', 'checkbox-mark')); cell.append(checkboxControl); row.append(cell);
    const nameCell=el('td'),button=el('button',bundle.workflow_id,'run-button');
    button.setAttribute('aria-label',`Inspect ${bundle.workflow_id} / ${bundle.run_id} revision ${record.revision}`);
    button.addEventListener('click',()=>inspect(record));
    nameCell.append(button,el('span',`${bundle.run_id} · revision ${record.revision}`,'run-sub'));row.append(nameCell);
    for(const [text,tone] of [[task(bundle),taskTone(bundle)],[policy(bundle),policyTone(bundle)],[evidence(record),record.assessment.evidence_status==='source_reported'?'purple':'muted']]){
      const statusCell=el('td');statusCell.append(statusLabel(text,tone));row.append(statusCell);
    }
    const openCell=el('td'),open=el('button',undefined,'row-open');open.append(icon('chevron-right'));
    open.setAttribute('aria-label',`Open ${bundle.run_id} revision ${record.revision} details`);open.addEventListener('click',()=>inspect(record));openCell.append(open);row.append(openCell);body.append(row);
  }
  controls();renderDetail($('detail'),records.find(record=>record.raw_sha256===active),message,lostActive);
}
function clearFilters() {
  $('search').value='';for(const id of ['outcome-filter','policy-filter','evidence-filter'])$(id).value='';render();
}
async function refresh() {
  records=await api.runs();
  for(const digest of selected)if(!records.some(record=>record.raw_sha256===digest))selected.delete(digest);
  render();
}
async function operation(action) {
  busy=true;controls();error('');
  try {await action();}catch(cause){error(cause.message);message('Action did not complete. Stored evidence is preserved.');}
  finally {busy=false;controls();}
}
$('refresh').addEventListener('click',()=>operation(async()=>{
  $('workspace-menu').open=false;await api.connect();connected=true;await refresh();message(`${records.length} evidence revisions loaded.`);
}));
$('fixtures').addEventListener('click',()=>operation(async()=>{
  $('workspace-menu').open=false;await api.loadFixtures();records=await api.runs();active=records[0]?.raw_sha256;clearFilters();
  message(`Synthetic fixtures loaded. ${records.length} evidence revisions stored; duplicate bytes are reused.`);
}));
$('search').addEventListener('input',render);
for(const id of ['outcome-filter','policy-filter','evidence-filter'])$(id).addEventListener('change',render);
$('clear-filters').addEventListener('click',()=>{clearFilters();$('search').focus();});
$('clear-selection').addEventListener('click',()=>{
  selected.clear();
  for(const checkbox of $('runs').querySelectorAll('input')) checkbox.checked=false;
  controls();
  ($('runs').querySelector('input') || $('search')).focus();
});
$('runs-nav').addEventListener('click',()=>{$('runs-section').scrollIntoView({block:'start'});$('search').focus();});
document.addEventListener('keydown',event=>{
  if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'&&!document.querySelector('dialog[open]')){event.preventDefault();$('search').focus();$('search').select();}
  if(event.key==='Escape')$('workspace-menu').open=false;
});
document.addEventListener('click',event=>{if(!$('workspace-menu').contains(event.target))$('workspace-menu').open=false;});
const importDialog=$('import-dialog');
$('open-import').addEventListener('click',()=>{$('import-error').hidden=true;importDialog.showModal();$('bundle-json').focus();});
$('cancel-import').addEventListener('click',()=>importDialog.close());
$('bundle-json').addEventListener('input',()=>{fileBytes=undefined;$('bundle-file').value='';});
$('bundle-file').addEventListener('change',async()=>{
  const file=$('bundle-file').files[0];fileBytes=undefined;if(!file)return;
  try{if(file.size>1048576)throw new Error('Bundle exceeds the 1 MiB limit.');fileBytes=await file.arrayBuffer();$('bundle-json').value=new TextDecoder('utf-8',{fatal:true}).decode(fileBytes);$('import-error').hidden=true;}
  catch(cause){fileBytes=undefined;$('bundle-json').value='';$('import-error').textContent=cause instanceof TypeError?'File must contain valid UTF-8 JSON.':cause.message;$('import-error').hidden=false;}
});
$('import-form').addEventListener('submit',async event=>{
  event.preventDefault();$('submit-import').disabled=true;$('cancel-import').disabled=true;$('import-error').hidden=true;
  try{
    const raw=fileBytes||new TextEncoder().encode($('bundle-json').value);if(raw.byteLength>1048576)throw new Error('Bundle exceeds the 1 MiB limit.');
    const before=new Set(records.map(record=>record.raw_sha256));const record=await api.importBundle(raw);active=record.raw_sha256;records=await api.runs();clearFilters();importDialog.close();error('');
    message(before.has(active)?'Identical bundle already stored; no revision added.':`Bundle imported as revision ${record.revision}. Source claims remain untrusted.`);
  }catch(cause){$('import-error').textContent=cause.message;$('import-error').hidden=false;}
  finally{$('submit-import').disabled=false;$('cancel-import').disabled=false;}
});
function compareSelected(){return operation(async()=>{const[a,b]=selected;const result=await api.compare(a,b);renderComparison($('comparison'),result);$('comparison-dialog').showModal();});}
$('compare').addEventListener('click',compareSelected);$('compare-nav').addEventListener('click',compareSelected);
$('close-comparison').addEventListener('click',()=>$('comparison-dialog').close());
$('close-record').addEventListener('click',()=>$('record-dialog').close());$('close-copy').addEventListener('click',()=>$('copy-dialog').close());
await operation(async()=>{await api.connect();connected=true;records=await api.runs();active=records[0]?.raw_sha256;render();message(records.length?`${records.length} evidence revisions loaded.`:'Local workspace ready. No evidence imported.',true);});
