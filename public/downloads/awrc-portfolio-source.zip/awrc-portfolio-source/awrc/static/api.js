let token;

export async function request(path, {body} = {}) {
  const options = {cache: 'no-store', credentials: 'same-origin'};
  if (body !== undefined) {
    options.method = 'POST';
    options.headers = {'Content-Type': 'application/json', 'X-AWRC-CSRF': token};
    options.body = body;
  }
  let response;
  try { response = await fetch(path, options); }
  catch { throw new Error('Local workspace unavailable. Check that the Console is running, then refresh.'); }
  let data;
  try { data = await response.json(); }
  catch { throw new Error('The local workspace returned an unreadable response. Refresh and try again.'); }
  if (!response.ok) throw new Error(data.error || 'Request rejected');
  return data;
}
export async function connect() {
  token = (await request('/api/bootstrap')).csrf_token;
}
export const importBundle = raw => request('/api/import', {body: raw});
export const loadFixtures = () => request('/api/fixtures', {body: '{}'});
export const runs = () => request('/api/runs');
export const compare = (a, b) => request(`/api/compare?a=${encodeURIComponent(a)}&b=${encodeURIComponent(b)}`);
