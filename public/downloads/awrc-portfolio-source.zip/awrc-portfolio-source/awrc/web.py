"""Data-only loopback interface; no arbitrary files, subprocesses or remote calls."""
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import socket
import sqlite3
from urllib.parse import parse_qs, urlsplit

from . import EvidenceStore, comparison_report, report
from .ingestion import ingest

LIMIT = 1_048_576
STATIC = Path(__file__).parent / 'static'
FIXTURES = Path(__file__).resolve().parents[1] / 'fixtures'
ASSETS = {'/': ('index.html', 'text/html; charset=utf-8'),
          '/static/style.css': ('style.css', 'text/css; charset=utf-8'),
          **{f'/static/{name}.js': (f'{name}.js', 'text/javascript; charset=utf-8') for name in ('app', 'api', 'view')}}
ASSETS.update({
    '/static/model.mjs': ('model.mjs', 'text/javascript; charset=utf-8'),
    '/static/icons.js': ('icons.js', 'text/javascript; charset=utf-8'),
    '/static/radix.css': ('radix.css', 'text/css; charset=utf-8'),
    '/static/InterVariable.woff2': ('InterVariable.woff2', 'font/woff2'),
})
CSP = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'none'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"


class ConsoleServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False


class Handler(BaseHTTPRequestHandler):
    server_version = 'AWRC'
    sys_version = ''

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass  # No payloads, tokens, source identifiers or URLs in request logs.

    def send_error(self, code, message=None, explain=None):
        self._json(code, {'error': 'Request rejected'})

    def _reply(self, status, data, media, extra=None):
        self.send_response(status)
        self.send_header('Content-Type', media)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', CSP)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Connection', 'close')
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.close_connection = True
        if self.command != 'HEAD':
            self.wfile.write(data)

    def _json(self, status, value):
        self._reply(status, json.dumps(value, ensure_ascii=True, allow_nan=False).encode(), 'application/json; charset=utf-8')

    def _boundary(self, mutation=False):
        host = self.headers.get_all('Host', [])
        origins = self.headers.get_all('Origin', [])
        if host != [f'127.0.0.1:{self.server.server_port}']:
            self._json(403, {'error': 'Use the exact local workspace URL'})
            return False
        if origins and origins != [self.server.origin]:
            self._json(403, {'error': 'Cross-origin request rejected'})
            return False
        if mutation:
            tokens = self.headers.get_all('X-AWRC-CSRF', [])
            if origins != [self.server.origin] or len(tokens) != 1 or not tokens[0].isascii() or not hmac.compare_digest(tokens[0], self.server.csrf):
                self._json(403, {'error': 'Workspace token or origin rejected; refresh this page'})
                return False
        return True

    def do_GET(self):
        if not self._boundary():
            return
        try:
            self._get()
        except KeyError:
            self._json(404, {'error': 'Evidence record not found'})
        except ValueError:
            self._json(400, {'error': 'Invalid request or stored evidence'})
        except (OSError, sqlite3.Error):
            self._json(503, {'error': 'Local evidence storage unavailable'})

    def _get(self):
        parsed = urlsplit(self.path)
        # Absolute-form targets and fragments are never part of this interface.
        if parsed.scheme or parsed.netloc or parsed.fragment:
            self._json(404, {'error': 'Route not found'})
            return
        path, query = parsed.path, parsed.query
        if path in ASSETS and not query:
            filename, media = ASSETS[path]
            self._reply(200, (STATIC / filename).read_bytes(), media)
            return
        if path == '/api/bootstrap' and not query:
            self._json(200, {'csrf_token': self.server.csrf})
            return
        if path in ('/api/import', '/api/fixtures') and not query:
            self._json(405, {'error': 'Method not allowed'})
            return
        with EvidenceStore(self.server.db_path) as store:
            if path == '/api/runs' and not query:
                self._json(200, store.list_runs())
            elif path.startswith('/api/runs/') and not query and '/' not in path[len('/api/runs/'):]:
                self._json(200, store.get(path[len('/api/runs/'):]))
            elif path == '/api/compare':
                params = parse_qs(query, strict_parsing=True)
                if set(params) != {'a', 'b'} or any(len(values) != 1 for values in params.values()):
                    raise ValueError('Invalid parameters')
                self._json(200, store.compare(params['a'][0], params['b'][0]))
            elif path == '/api/export-comparison':
                params = parse_qs(query, strict_parsing=True, keep_blank_values=True)
                if (set(params) != {'a', 'b', 'format'} or any(len(values) != 1 for values in params.values()) or
                        params['format'] not in (['json'], ['markdown'])):
                    raise ValueError('Invalid parameters')
                a, b, format_ = params['a'][0], params['b'][0], params['format'][0]
                data = comparison_report(store, a, b, format_).encode('utf-8')
                extension, media = ('json', 'application/json') if format_ == 'json' else ('md', 'text/markdown')
                self._reply(200, data, media + '; charset=utf-8', {
                    'Content-Disposition': f'attachment; filename="awrc-comparison-{a}-{b}.{extension}"'})
            elif path.startswith('/api/export/') and '/' not in path[len('/api/export/'):]:
                params = parse_qs(query, strict_parsing=True)
                if set(params) != {'format'} or params['format'] not in (['json'], ['markdown']):
                    raise ValueError('Invalid format')
                digest, format_ = path[len('/api/export/'):], params['format'][0]
                data = report(store.get(digest), format_).encode('utf-8')
                extension, media = ('json', 'application/json') if format_ == 'json' else ('md', 'text/markdown')
                self._reply(200, data, media + '; charset=utf-8', {'Content-Disposition': f'attachment; filename="awrc-{digest}.{extension}"'})
            else:
                self._json(404, {'error': 'Route not found'})

    def do_POST(self):
        if not self._boundary(True):
            return
        if self.path not in ('/api/import', '/api/fixtures'):
            self._json(405 if self.path == '/api/runs' else 404, {'error': 'Route or method not allowed'})
            return
        lengths = self.headers.get_all('Content-Length', [])
        if (self.headers.get_all('Transfer-Encoding', []) or len(lengths) != 1 or
                not lengths[0].isascii() or not lengths[0].isdigit()):
            self._json(400, {'error': 'One bounded Content-Length is required'})
            return
        length_text = lengths[0].lstrip('0') or '0'
        if len(length_text) > 7:
            self._json(413, {'error': 'Bundle exceeds the 1 MiB limit'})
            return
        length = int(length_text)
        if length > LIMIT:
            self._json(413, {'error': 'Bundle exceeds the 1 MiB limit'})
            return
        if (self.headers.get_all('Content-Encoding', []) or
                self.headers.get_all('Content-Type', []) != ['application/json']):
            self._json(415, {'error': 'Use unencoded application/json'})
            return
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError('Incomplete body')
            if self.path == '/api/import':
                ingest(raw)
                with EvidenceStore(self.server.db_path) as store:
                    self._json(200, store.import_bytes(raw))
            else:
                if raw != b'{}':
                    raise ValueError('Invalid fixture request')
                # Only explicit packaged names; request data cannot select a path.
                bundles = [(FIXTURES / name).read_bytes() for name in
                           ('success.json', 'safe-denial.json', 'pending-approval.json', 'incomplete-success.json')]
                for bundle in bundles:
                    ingest(bundle)
                with EvidenceStore(self.server.db_path) as store:
                    self._json(200, [store.import_bytes(bundle) for bundle in bundles])
        except (ValueError, KeyError):
            self._json(400, {'error': 'Invalid fixture or ARMS inspection bundle; no import made'})
        except (TimeoutError, socket.timeout):
            self._json(408, {'error': 'Request body timed out'})
        except (OSError, sqlite3.Error):
            self._json(503, {'error': 'Local evidence storage unavailable'})

    def _unsupported(self):
        if self._boundary():
            self._json(405, {'error': 'Method not allowed'})

    do_HEAD = do_PUT = do_DELETE = do_PATCH = do_OPTIONS = do_TRACE = do_CONNECT = _unsupported


def create_server(db_path, port=8765):
    """Operator-only path/port; returned server binds IPv4 loopback exclusively."""
    if isinstance(port, bool) or not isinstance(port, int) or not 0 <= port <= 65535:
        raise ValueError('Invalid port')
    with EvidenceStore(db_path):
        pass
    server = ConsoleServer(('127.0.0.1', port), Handler)
    server.db_path = db_path
    server.origin = f'http://127.0.0.1:{server.server_port}'
    server.csrf = secrets.token_urlsafe(32)
    return server


def serve(db_path, port=8765):
    server = create_server(db_path, port)
    print(f'Reliability Console: {server.origin}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
