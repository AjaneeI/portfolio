"""Strict data-only dispatch; native projections are never fixture validation."""
import base64
import binascii
import hashlib
import json
from .validation import (MAX_BYTES, _bounded_depth, _unique_object, _constant,
                         _scalars, validate_bundle)

NATIVE = 'awrc.arms-inspection.v0.1'


def require(condition):
    if not condition:
        raise ValueError('Invalid imported evidence')


def ingest(raw):
    require(type(raw) is bytes and 0 < len(raw) <= MAX_BYTES)
    _bounded_depth(raw)
    try:
        source = json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object, parse_constant=_constant)
        _scalars(source)
        require(type(source) is dict)
        if source.get('schema_version') == 'ev.v0.1':
            from .envelope import ingest_envelope
            return ingest_envelope(raw)
        if source.get('schema_version') != NATIVE:
            return {'bundle': validate_bundle(raw)}
        from .arms_adapter import FILES, inspect_files
        files = source.get('files')
        require(type(files) is dict and set(files) == set(FILES))
        decoded = {}
        for name in FILES:
            item = files[name]
            require(type(item) is dict and set(item) == {'sha256','size_bytes','base64'})
            require(type(item['base64']) is str and len(item['base64']) <= MAX_BYTES)
            data = base64.b64decode(item['base64'], validate=True)
            require(base64.b64encode(data).decode('ascii') == item['base64'])
            require(type(item['size_bytes']) is int and item['size_bytes'] == len(data))
            require(item['sha256'] == hashlib.sha256(data).hexdigest())
            decoded[name] = data
        recomputed = inspect_files(decoded)
        # Canonical serialization distinguishes booleans from integers as well as claims.
        require(json.dumps(source, sort_keys=True, allow_nan=False) == json.dumps(recomputed, sort_keys=True, allow_nan=False))
        return {'format': NATIVE, 'source_inspection': recomputed, 'bundle': present(recomputed)}
    except (UnicodeError, RecursionError, OverflowError, TypeError, binascii.Error) as exc:
        raise ValueError('Invalid imported evidence') from exc


def present(source):
    from .arms_adapter import ARTIFACTS
    logical_ids = {filename: logical_id for logical_id, filename in ARTIFACTS.items()}
    reviewed = source['reviewed']
    return dict(schema_version=NATIVE, workflow_id='arms-native-offline', run_id=reviewed['run_id'],
                task_id=reviewed['task']['task_id'], scope_revision=reviewed['task']['scope_revision'],
                source={**reviewed['source'], 'repository':reviewed['task']['repository'], 'synthetic':True},
                configuration={**reviewed['configuration'], 'fixture_id':reviewed['task']['fixture_id']},
                outcome=dict(execution_status=reviewed['outcome']['execution'], task_success=reviewed['outcome']['task_success'],
                             policy_outcome=None, claimed_verification=reviewed['outcome']['verification']),
                commands=[{**command, 'artifact_ids':[command['artifact_id']]} for command in reviewed['commands']],
                checks=[dict(id=case['id'], kind='task', outcome='passed' if case['passed'] else 'failed',
                             command_id='candidate_checks') for case in source['candidate']['checks']],
                artifacts=[dict(id=logical_ids.get(name, name), sha256=item['sha256'], text=base64.b64decode(item['base64']).decode('utf-8'))
                           for name,item in source['files'].items()],
                timing=reviewed['timestamps'], cost={'kind':'unknown'})
