"""Offline operator interface: python -m awrc --db PATH COMMAND."""
import argparse
import json
import sqlite3
import sys

from . import EvidenceStore, comparison_report, report
from .ingestion import ingest
from .validation import read_bundle_file


def main(argv=None):
    parser = argparse.ArgumentParser(description="Inspect untrusted AWRC fixture evidence locally")
    parser.add_argument("--db", required=True, help="Local SQLite database path")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("import").add_argument("file")
    commands.add_parser("list")
    commands.add_parser("show").add_argument("digest")
    compare = commands.add_parser("compare")
    compare.add_argument("a"); compare.add_argument("b")
    export = commands.add_parser("export")
    export.add_argument("digest")
    export.add_argument("--format", required=True, choices=("json", "markdown"))
    export_comparison = commands.add_parser("export-comparison")
    export_comparison.add_argument("a"); export_comparison.add_argument("b")
    export_comparison.add_argument("--format", required=True, choices=("json", "markdown"))
    browser = commands.add_parser("serve", help="Open the data-only local browser workspace")
    browser.add_argument("--port", type=int, default=8765, help="Loopback port (0 selects an available port)")
    args = parser.parse_args(argv)
    try:
        if args.command == "serve":
            from .web import serve
            serve(args.db, args.port)
            return 0
        raw = None
        if args.command == "import":
            raw = read_bundle_file(args.file)
            # Reject before opening/creating a database, including on invalid input.
            ingest(raw)
        with EvidenceStore(args.db) as store:
            if args.command == "import":
                output = store.import_bytes(raw)
            elif args.command == "list":
                output = store.list_runs()
            elif args.command == "show":
                output = store.get(args.digest)
            elif args.command == "compare":
                output = store.compare(args.a, args.b)
            elif args.command == "export-comparison":
                sys.stdout.write(comparison_report(store, args.a, args.b, args.format))
                return 0
            else:
                sys.stdout.write(report(store.get(args.digest), args.format))
                return 0
        sys.stdout.write(json.dumps(output, ensure_ascii=True, allow_nan=False, indent=2, sort_keys=True) + "\n")
        return 0
    except (ValueError, KeyError):
        # Validator messages are fixed, but never include arbitrary exception text
        # from a dependency or an imported payload in operator logs.
        print("awrc: invalid input or evidence digest not found", file=sys.stderr)
    except (OSError, sqlite3.Error):
        print("awrc: local evidence storage unavailable", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
