"""Local immutable raw-byte evidence revisions, backed by transactional SQLite."""
import hashlib
import sqlite3

from .reporting import assess
from .validation import _digest
from .ingestion import ingest, NATIVE
from .envelope import FORMAT as ENVELOPE


class EvidenceStore:
    def __init__(self, db_path):
        self._connection = sqlite3.connect(db_path, timeout=10, isolation_level=None)
        try:
            self._connection.executescript("""
                CREATE TABLE IF NOT EXISTS runs (
                    sequence INTEGER PRIMARY KEY,
                    raw_sha256 TEXT NOT NULL UNIQUE,
                    workflow_id TEXT NOT NULL,
                    run_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    revision INTEGER NOT NULL CHECK (revision > 0),
                    raw_bytes BLOB NOT NULL,
                    UNIQUE(workflow_id, run_id, task_id, revision)
                );
                CREATE TRIGGER IF NOT EXISTS runs_no_update
                    BEFORE UPDATE ON runs BEGIN SELECT RAISE(ABORT, 'Evidence is immutable'); END;
                CREATE TRIGGER IF NOT EXISTS runs_no_delete
                    BEFORE DELETE ON runs BEGIN SELECT RAISE(ABORT, 'Evidence is immutable'); END;
            """)
            self._connection.executescript("""
                CREATE TABLE IF NOT EXISTS native_runs (
                    sequence INTEGER PRIMARY KEY, raw_sha256 TEXT NOT NULL UNIQUE,
                    workflow_id TEXT NOT NULL, run_id TEXT NOT NULL, task_id TEXT NOT NULL,
                    revision INTEGER NOT NULL CHECK(revision > 0), raw_bytes BLOB NOT NULL,
                    UNIQUE(workflow_id,run_id,task_id,revision));
                CREATE TRIGGER IF NOT EXISTS native_no_update BEFORE UPDATE ON native_runs
                    BEGIN SELECT RAISE(ABORT, 'Evidence is immutable'); END;
                CREATE TRIGGER IF NOT EXISTS native_no_delete BEFORE DELETE ON native_runs
                    BEGIN SELECT RAISE(ABORT, 'Evidence is immutable'); END;
            """)
        except BaseException:
            self._connection.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        self._connection.close()

    def import_bytes(self, raw):
        imported = ingest(raw)
        bundle = imported["bundle"]
        digest = hashlib.sha256(raw).hexdigest()
        table = "native_runs" if imported.get("format") in (NATIVE, ENVELOPE) else "runs"
        connection = self._connection
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(f"SELECT revision FROM {table} WHERE raw_sha256 = ?", (digest,)).fetchone()
            if existing is not None:
                revision = existing[0]
            else:
                key = (bundle["workflow_id"], bundle["run_id"], bundle["task_id"])
                revision = connection.execute(f"SELECT COALESCE(MAX(revision), 0) + 1 FROM {table} WHERE workflow_id = ? AND run_id = ? AND task_id = ?", key).fetchone()[0]
                connection.execute(f"INSERT INTO {table} (raw_sha256, workflow_id, run_id, task_id, revision, raw_bytes) VALUES (?, ?, ?, ?, ?, ?)",
                                   (digest, *key, revision, raw))
            connection.execute("COMMIT")
        except BaseException:
            connection.execute("ROLLBACK")
            raise
        return {"raw_sha256": digest, "revision": revision, **imported, "assessment": assess(bundle)}

    @staticmethod
    def _record(row):
        digest, revision, raw = row
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("Stored raw-byte integrity check failed")
        imported = ingest(raw)
        bundle = imported["bundle"]
        return {"raw_sha256": digest, "revision": revision, **imported, "assessment": assess(bundle)}

    def list_runs(self):
        rows = self._connection.execute("SELECT raw_sha256, revision, raw_bytes FROM runs ORDER BY sequence").fetchall()
        rows += self._connection.execute("SELECT raw_sha256, revision, raw_bytes FROM native_runs ORDER BY sequence").fetchall()
        return [self._record(row) for row in rows]

    def get(self, digest):
        _digest(digest)
        row = self._connection.execute("SELECT raw_sha256, revision, raw_bytes FROM runs WHERE raw_sha256 = ?", (digest,)).fetchone()
        if row is None:
            row = self._connection.execute("SELECT raw_sha256, revision, raw_bytes FROM native_runs WHERE raw_sha256 = ?", (digest,)).fetchone()
        if row is None:
            raise KeyError("Evidence digest not found")
        return self._record(row)

    def compare(self, a, b):
        left, right = self.get(a), self.get(b)
        first, second = left["bundle"], right["bundle"]
        result = {"a": a, "b": b, "independently_verified": False}
        if ENVELOPE in (left.get("format"), right.get("format")):
            return {**result, "compatible": False,
                    "reason": "Raw EV envelope comparison unavailable: per-case supporting evidence is absent"}
        if left.get("format") != right.get("format"):
            return {**result, "compatible": False, "reason": "Different import format (native versus fixture)"}
        for field in ("workflow_id", "task_id", "scope_revision", "configuration"):
            if first[field] != second[field]:
                return {**result, "compatible": False, "reason": f"Different {field}"}
        checks_a = {(check["id"], check["kind"]): check["outcome"] for check in first["checks"]}
        checks_b = {(check["id"], check["kind"]): check["outcome"] for check in second["checks"]}
        if checks_a.keys() != checks_b.keys():
            return {**result, "compatible": False, "reason": "Different check ID and kind set"}
        counts = {}
        for side, checks in (("a", checks_a), ("b", checks_b)):
            counts[side] = {kind: {"passed": 0, "failed": 0, "unknown": 0, "total": 0} for kind in ("task", "safety")}
            for (_, kind), outcome in checks.items():
                counts[side][kind][outcome] += 1
                counts[side][kind]["total"] += 1
        return {**result, **({"comparison_stage": "candidate"} if left.get("format") == NATIVE else {}), "compatible": True,
                "cases": [{"id": id_, "kind": kind, "a": checks_a[(id_, kind)], "b": checks_b[(id_, kind)]} for id_, kind in sorted(checks_a)],
                "counts": counts, "outcomes": {"a": first["outcome"], "b": second["outcome"]},
                "assessments": {"a": left["assessment"], "b": right["assessment"]}}
