"""Bounded data-only validation for the local AWRC fixture dialect."""
import hashlib
import json
import math
import os
import re
import stat
from datetime import datetime

MAX_BYTES = 1_048_576
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z")
_SHA40 = re.compile(r"[0-9a-f]{40}\Z")
_SHA64 = re.compile(r"[0-9a-f]{64}\Z")
# Explicit extended ISO8601 subset; datetime.fromisoformat alone also accepts
# arbitrary separators and normalizes representations outside this dialect.
_TIMESTAMP = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]"
    r"(?:\.[0-9]{1,6})?(?:Z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])\Z"
)


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _fields(value, names):
    _require(type(value) is dict and set(value) == set(names.split()), "Invalid object fields")


def _id(value):
    _require(type(value) is str and _ID.fullmatch(value) and ".." not in value, "Invalid identifier")


def _digest(value, pattern=_SHA64):
    _require(type(value) is str and pattern.fullmatch(value), "Invalid digest")


def _text(value, limit, *, nonempty=False):
    _require(type(value) is str, "Expected text")
    try:
        encoded = value.encode("utf-8")
    except UnicodeError:
        raise ValueError("Invalid Unicode text") from None
    _require(len(encoded) <= limit and (not nonempty or bool(value.strip())), "Invalid text length")
    return encoded


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        _require(key not in value, "Duplicate JSON key")
        value[key] = item
    return value


def _constant(_value):
    raise ValueError("Non-finite JSON number")


def _bounded_depth(raw):
    # Inspect before json.loads, which can otherwise recurse on attacker-controlled input.
    depth = 0
    quoted = escaped = False
    for byte in raw:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
            _require(depth <= 16, "JSON nesting exceeds 16")
        elif byte in (93, 125):
            depth -= 1


def _scalars(value):
    if type(value) is dict:
        for key, item in value.items():
            _text(key, MAX_BYTES)
            _scalars(item)
    elif type(value) is list:
        for item in value:
            _scalars(item)
    elif type(value) is str:
        _text(value, MAX_BYTES)
    elif type(value) is float:
        _require(math.isfinite(value), "Non-finite JSON number")


def _items(value, maximum):
    _require(type(value) is list and len(value) <= maximum, "Invalid list or item limit")
    ids = set()
    for item in value:
        _require(type(item) is dict and "id" in item, "Invalid list item")
        _id(item["id"])
        _require(item["id"] not in ids, "Duplicate item identifier")
        ids.add(item["id"])
    return ids


def validate_bundle(raw: bytes) -> dict:
    """Return validated source data, raising ValueError without echoing its content."""
    _require(type(raw) is bytes, "Input must be bytes")
    _require(len(raw) <= MAX_BYTES, "Input exceeds 1048576 bytes")
    _bounded_depth(raw)
    try:
        data = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object, parse_constant=_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise ValueError("Invalid JSON input") from None
    except ValueError:
        # Includes duplicate keys, non-finite constants, and interpreter integer limits.
        raise ValueError("Invalid JSON values") from None
    _scalars(data)
    _fields(data, "schema_version workflow_id run_id task_id scope_revision source configuration outcome commands checks artifacts timing cost")
    _require(data["schema_version"] == "awrc.fixture.v0.1", "Unsupported schema version")
    for name in ("workflow_id", "run_id", "task_id", "scope_revision"):
        _id(data[name])
    source = data["source"]
    _fields(source, "repository base_sha head_sha tree_sha synthetic")
    _require(type(source["repository"]) is str, "Invalid repository")
    components = source["repository"].split("/")
    _require(len(components) == 2, "Invalid repository")
    for component in components:
        _id(component)
    for name in ("base_sha", "head_sha", "tree_sha"):
        _digest(source[name], _SHA40)
    _require(type(source["synthetic"]) is bool, "Invalid synthetic flag")
    configuration = data["configuration"]
    _fields(configuration, "digest suite_digest fixture_digest evaluation_rules_digest verifier_version")
    for name in ("digest", "suite_digest", "fixture_digest", "evaluation_rules_digest"):
        _digest(configuration[name])
    _text(configuration["verifier_version"], 256, nonempty=True)
    outcome = data["outcome"]
    _fields(outcome, "execution_status task_success policy_outcome claimed_verification")
    _require(type(outcome["execution_status"]) is str and outcome["execution_status"] in ("completed", "failed", "pending", "unknown"), "Invalid execution status")
    _require(outcome["task_success"] is None or type(outcome["task_success"]) is bool, "Invalid task success")
    _require(type(outcome["policy_outcome"]) is str and outcome["policy_outcome"] in ("allow", "denied", "needs_approval", "not_evaluated"), "Invalid policy outcome")
    _require(type(outcome["claimed_verification"]) is str and outcome["claimed_verification"] in ("verified", "failed", "unverified"), "Invalid verification claim")
    artifact_ids = _items(data["artifacts"], 16)
    for artifact in data["artifacts"]:
        _fields(artifact, "id sha256 text")
        _digest(artifact["sha256"])
        text = _text(artifact["text"], 65_536)
        _require(hashlib.sha256(text).hexdigest() == artifact["sha256"], "Artifact hash mismatch")
    command_ids = _items(data["commands"], 64)
    for command in data["commands"]:
        _fields(command, "id exit_code artifact_ids")
        _require(command["exit_code"] is None or type(command["exit_code"]) is int, "Invalid command exit code")
        refs = command["artifact_ids"]
        _require(type(refs) is list and len(refs) <= 16, "Invalid artifact references")
        seen = set()
        for ref in refs:
            _id(ref)
            _require(ref in artifact_ids and ref not in seen, "Unknown or duplicate artifact reference")
            seen.add(ref)
    _items(data["checks"], 64)
    for check in data["checks"]:
        _fields(check, "id kind outcome command_id")
        _require(type(check["kind"]) is str and check["kind"] in ("task", "safety"), "Invalid check kind")
        _require(type(check["outcome"]) is str and check["outcome"] in ("passed", "failed", "unknown"), "Invalid check outcome")
        _id(check["command_id"])
        _require(check["command_id"] in command_ids, "Unknown command reference")
    timing = data["timing"]
    if timing is not None:
        _fields(timing, "started_at ended_at")
        instants = []
        for name in ("started_at", "ended_at"):
            _text(timing[name], 128, nonempty=True)
            _require(_TIMESTAMP.fullmatch(timing[name]), "Unsupported timestamp syntax")
            try:
                instant = datetime.fromisoformat(timing[name])
                _require(instant.utcoffset() is not None, "Timestamp requires UTC offset")
            except (ValueError, OverflowError):
                raise ValueError("Invalid offset timestamp") from None
            instants.append(instant)
        _require(instants[1] >= instants[0], "Timing ends before it starts")
    cost = data["cost"]
    _fields(cost, "kind value currency")
    _require(type(cost["kind"]) is str and cost["kind"] in ("unknown", "estimated", "actual"), "Invalid cost kind")
    if cost["kind"] == "unknown":
        _require(cost["value"] is None and cost["currency"] is None, "Unknown cost must remain null")
    else:
        _require(type(cost["value"]) in (int, float) and cost["value"] >= 0, "Invalid cost value")
        _require(type(cost["currency"]) is str and re.fullmatch(r"[A-Z]{3}", cost["currency"]), "Invalid currency")
    return data


def read_bundle_file(path) -> bytes:
    """Read a bounded regular file, rejecting symlinks in every path component.

    Descriptor-relative traversal pins each directory. O_NOFOLLOW closes the
    symlink-check/open race, and O_NONBLOCK prevents waiting on FIFO inputs.
    Unsupported platforms fail closed instead of following an unsafe fallback.
    """
    if not all(hasattr(os, flag) for flag in ("O_NOFOLLOW", "O_DIRECTORY", "O_NONBLOCK")) or os.open not in os.supports_dir_fd:
        raise ValueError("Safe file import unavailable on this platform")
    try:
        filename = os.fspath(path)
        _require(type(filename) is str and bool(filename) and "\0" not in filename, "Invalid input path")
        # Do not normalize '..': an earlier symlink component must still be rejected.
        components = [part for part in filename.split("/") if part and part != "."]
        _require(bool(components), "Expected a regular input file")
        directory_fd = os.open("/" if filename.startswith("/") else ".", os.O_RDONLY | os.O_DIRECTORY)
        file_fd = None
        try:
            for component in components[:-1]:
                next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
                os.close(directory_fd)
                directory_fd = next_fd
            file_fd = os.open(components[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
            info = os.fstat(file_fd)
            _require(stat.S_ISREG(info.st_mode), "Expected a regular input file")
            _require(info.st_size <= MAX_BYTES, "Input exceeds 1048576 bytes")
            chunks = []
            remaining = MAX_BYTES + 1
            while remaining:
                chunk = os.read(file_fd, min(65_536, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            result = b"".join(chunks)
            _require(len(result) <= MAX_BYTES, "Input exceeds 1048576 bytes")
            return result
        finally:
            if file_fd is not None:
                os.close(file_fd)
            os.close(directory_fd)
    except (OSError, TypeError):
        raise ValueError("Cannot safely read regular input file") from None
