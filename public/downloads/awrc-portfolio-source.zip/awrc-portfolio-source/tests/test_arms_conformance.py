"""Portable data-only conformance recipes; never execute producer or patch code."""
import base64
import copy
import hashlib
import json
import traceback
from pathlib import Path
import unittest

from awrc import arms_profile as profile
from awrc.arms_adapter import ARTIFACTS, FILES, inspect_files
from awrc.ingestion import ingest
from awrc.store import EvidenceStore

ROOT = Path(__file__).resolve().parents[1]
CORPUS = ROOT / 'fixtures/arms-conformance'


def encode(obj):
    return json.dumps(obj, allow_nan=False).encode()


def set_path(obj, path, value):
    for key in path[:-1]:
        obj = obj[key]
    obj[path[-1]] = copy.deepcopy(value)


def rebind(files, decision='approved'):
    original = json.loads(files['evidence.json'])
    for artifact in original['artifacts']:
        raw = files[ARTIFACTS[artifact['id']]]
        artifact.update(sha256=hashlib.sha256(raw).hexdigest(), size_bytes=len(raw))
    files['evidence.json'] = profile.canonical_bytes(original)
    receipt = json.loads(files['review-receipt.json'])
    receipt.update(evidence_sha256=profile.digest(original), decision=decision)
    files['review-receipt.json'] = profile.canonical_bytes(receipt)
    reviewed = copy.deepcopy(original)
    reviewed['provenance'].update(reviewer=receipt['reviewer'], reviewed_head=receipt['head_sha'],
                                 review_state=decision, review_receipt_sha256=profile.digest(receipt))
    reviewed['outcome'].update(task_success=decision == 'approved', reason_code=
        'reviewed_synthetic_fix' if decision == 'approved' else 'review_changes_requested')
    files['reviewed-evidence.json'] = profile.canonical_bytes(reviewed)


def recipe(files, steps):
    """Closed vocabulary; filenames are fixed and paths only traverse in-memory JSON."""
    files = dict(files)
    for step in steps:
        op = step['op']
        if op == 'rebind':
            rebind(files, step.get('decision', 'approved'))
        elif op == 'set':
            name = step['file']
            if name not in FILES:
                raise ValueError('Unknown fixed file')
            obj = json.loads(files[name])
            set_path(obj, step['path'], step['value'])
            files[name] = profile.canonical_bytes(obj)
        elif op == 'paired_cases':
            for name in ('baseline-checks.json', 'candidate-checks.json'):
                obj = json.loads(files[name]); mode = step['mode']
                if mode == 'omit': obj['checks'].pop()
                elif mode == 'expected': obj['checks'][0].update(actual=999, expected=999, passed=True)
                elif mode == 'extra': obj['checks'].append(dict(id='extra', actual=0, expected=0, passed=True))
                elif mode == 'rename': obj['checks'][0]['id'] = 'renamed'
                else: raise ValueError('Unknown case operation')
                files[name] = profile.canonical_bytes(obj)
        elif op == 'raw':
            if step['file'] not in FILES: raise ValueError('Unknown fixed file')
            files[step['file']] = step['text'].encode()
        elif op == 'remove':
            if step['file'] not in FILES: raise ValueError('Unknown fixed file')
            del files[step['file']]
        else:
            raise ValueError('Unknown recipe operation')
    return files


def embedded(report, files):
    report = copy.deepcopy(report)
    report['files'] = {name: dict(base64=base64.b64encode(raw).decode(),
        sha256=hashlib.sha256(raw).hexdigest(), size_bytes=len(raw)) for name, raw in files.items()}
    return report


class ConformanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads((CORPUS / 'manifest.json').read_bytes())
        cls.files = {name: (ROOT / 'fixtures/arms-native' / name).read_bytes() for name in FILES}
        cls.golden = inspect_files(cls.files)

    def test_descriptor_and_pins(self):
        self.assertIn('ARMS reviewed retry-backoff offline profile', (ROOT/'docs/arms-offline-profile.md').read_text())
        for name, pin in self.manifest['pins'].items():
            raw = (ROOT / name).read_bytes()
            self.assertEqual({'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes':len(raw)}, pin, name)
        self.assertEqual(len(self.manifest['golden_files']), 8)
        self.assertEqual(set(self.manifest['golden_files']), set(FILES))
        for name, pin in self.manifest['golden_files'].items():
            self.assertEqual(pin, self.manifest['pins']['fixtures/arms-native/' + name])

    def test_closed_vocabulary(self):
        with self.assertRaises(ValueError): recipe(self.files, [{'op':'execute'}])
        with self.assertRaises(ValueError): recipe(self.files, [{'op':'raw', 'file':'../bad', 'text':'x'}])

    def test_all_vectors(self):
        seen = set()
        for vector in self.manifest['vectors']:
            with self.subTest(vector=vector['id']):
                self.assertNotIn(vector['id'], seen); seen.add(vector['id'])
                files = recipe(self.files, vector['recipe'])
                expected = vector['expected']; layer = expected['layer']
                if layer == 'reader':
                    if vector['id'] == 'denied-native':
                        # A broader-producer denial must be valid before subset refusal.
                        for name in ('evidence.json', 'reviewed-evidence.json'):
                            profile.loads_evidence(files[name])
                        try:
                            inspect_files(files)
                        except ValueError as exc:
                            frames = traceback.extract_tb(exc.__traceback__)
                            boundary = [frame for frame in frames
                                if Path(frame.filename).name == 'arms_adapter.py'
                                and frame.name == 'inspect_files']
                            self.assertEqual(len(boundary), 1)
                            self.assertEqual(boundary[0].lineno, 106)
                            self.assertIn('original["outcome"]', boundary[0].line)
                        else:
                            self.fail('Valid denied input bypassed supported-subset refusal')
                    else:
                        with self.assertRaises(ValueError): inspect_files(files)
                    raw = encode(embedded(self.golden, files))
                else:
                    report = inspect_files(files)
                    if layer == 'accepted':
                        self.assertEqual(report['baseline']['passed_count'], expected['baseline_passed'])
                        self.assertEqual(report['baseline']['failed_count'], expected['baseline_failed'])
                        self.assertEqual(report['candidate']['passed_count'], expected['candidate_passed'])
                        self.assertEqual(report['candidate']['failed_count'], 0)
                        self.assertEqual(report['baseline']['total_count'], 18)
                        self.assertEqual(report['candidate']['total_count'], 18)
                        self.assertEqual(report['reviewed']['outcome']['task_success'], expected['task_success'])
                        self.assertEqual(report['original']['outcome']['task_success'], False)
                        self.assertIs(report['independently_verified'], False)
                        self.assertIsNone(report['authority']); self.assertIsNone(report['publication_permission'])
                        self.assertEqual(report['measurements']['human_minutes'], None)
                        self.assertEqual(report['measurements']['cost_amount'], None)
                    for change in vector.get('report_sets', []): set_path(report, change['path'], change['value'])
                    raw = encode(report)
                    mode = vector.get('raw_mode')
                    if mode == 'duplicate': raw = b'{"schema_version":"duplicate",' + raw[1:]
                    elif mode == 'depth': raw = b'[' * 17 + b'0' + b']' * 17
                    elif mode == 'oversize': raw = b' ' * 1048577
                    elif mode == 'nan': raw = b'{"x":NaN}'
                    elif mode is not None: raise ValueError('Unknown raw mode')
                with EvidenceStore(':memory:') as store:
                    if layer != 'accepted':
                        with self.assertRaises(ValueError): ingest(raw)
                        with self.assertRaises(ValueError): store.import_bytes(raw)
                        self.assertEqual(store.list_runs(), [])
                    else:
                        imported = ingest(raw)
                        self.assertEqual(imported['source_inspection'], report)
                        record = store.import_bytes(raw)
                        self.assertEqual(store.get(record['raw_sha256'])['source_inspection'], report)
                        for name, item in report['files'].items():
                            self.assertEqual(base64.b64decode(item['base64']), files[name])
                        original = store.import_bytes(encode(self.golden))
                        comparison = store.compare(original['raw_sha256'], record['raw_sha256'])
                        self.assertEqual(comparison['compatible'], expected['comparison_compatible'])
                        if expected['comparison_compatible']:
                            self.assertEqual(comparison['counts']['b']['task']['total'],18)
                            self.assertEqual(comparison['counts']['b']['task']['passed'],18)
                        else:
                            self.assertNotIn('counts', comparison); self.assertNotIn('cases', comparison)
                        if vector.get('compare_fixture'):
                            fixture = store.import_bytes((ROOT/'fixtures/success.json').read_bytes())
                            refusal = store.compare(record['raw_sha256'], fixture['raw_sha256'])
                            self.assertFalse(refusal['compatible'])
                            self.assertNotIn('counts', refusal); self.assertNotIn('cases', refusal)
                print('VECTOR', vector['id'], expected['disposition'], layer)
        self.assertEqual(len(seen), self.manifest['vector_count'])
