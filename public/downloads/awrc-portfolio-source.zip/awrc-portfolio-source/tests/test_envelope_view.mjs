import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderDetail} from '../awrc/static/view.js';
class Element {
  constructor(tag) {this.tagName=tag; this.children=[]; this.textContent=''; this.attributes={}; this.listeners={};}
  append(...nodes) {this.children.push(...nodes);}
  replaceChildren(...nodes) {this.children=[...nodes];}
  setAttribute(name,value) {this.attributes[name]=value;}
  addEventListener(name,fn) {this.listeners[name]=fn;}
}
globalThis.document={createElement:tag=>new Element(tag),importNode:node=>node};
globalThis.DOMParser=class {parseFromString(){return {documentElement:new Element('svg')};}};
function all(node){return [node,...node.children.flatMap(all)];}
function text(node){return [node.textContent,...node.children.map(text)].join(' ');}
function record(synthetic=null) {return {format:'ev.v0.1', revision:1, raw_sha256:'a'.repeat(64),
  assessment:{evidence_status:'unverified',independently_verified:false,notice:'Display projection; supporting evidence unavailable.'},
  source_evidence:{schema_version:'ev.v0.1',artifacts:[{id:'candidate_checks',sha256:'b'.repeat(64)}],
    limitations:['<script>owned()</script>[link](https://evil.invalid)']},
  source_bytes:{base64:'ZXhhY3QgYnl0ZXM=',sha256:'a'.repeat(64),size_bytes:11},
  bundle:{schema_version:'ev.v0.1',workflow_id:'arms-native-envelope',run_id:'run',task_id:'task',scope_revision:'scope',
    source:{repository:'<script>owned()</script>',base_sha:'c'.repeat(40),head_sha:null,tree_sha:null,synthetic},
    configuration:{},outcome:{execution_status:'pending',claimed_verification:'unverified',task_success:false,policy_outcome:null,reason_code:'incomplete'},
    timing:{started_at:'2026-10-22T00:00:00Z',ended_at:'2026-10-22T00:00:01Z'},cost:{kind:'unknown'},commands:[],checks:[],artifacts:[]}};}

test('raw envelope details show unknown synthetic, null source and unavailable evidence explicitly',()=>{
  const target=new Element('div');renderDetail(target,record(),()=>{});
  const output=text(target);
  assert.match(output,/Synthetic Unknown/);
  assert.match(output,/Head Unknown/);assert.match(output,/Tree Unknown/);
  assert.doesNotMatch(output,/null|undefined|No \(source-reported\)/);
  assert.match(output,/case.*unavailable|No task cases supplied/i);
  assert.match(output,/artifact content.*unavailable/i);
  assert.match(output,/review.*unauthenticated/i);
  assert.match(output,/display projection/i);
  assert.doesNotMatch(output,/This record uses the Console fixture dialect/);
  assert.match(output,/incomplete/);
});

test('raw envelope and byte descriptor are complete inert text in full details',()=>{
  const target=new Element('div'),source=record();renderDetail(target,source,()=>{});
  const pres=all(target).filter(node=>node.tagName==='pre');
  assert.ok(pres.some(node=>node.textContent===JSON.stringify(source.source_evidence,null,2)));
  assert.ok(pres.some(node=>node.textContent===JSON.stringify(source.source_bytes,null,2)));
  assert.equal(all(target).filter(node=>node.tagName==='script').length,0);
  assert.equal(all(target).filter(node=>node.tagName==='a').length,2);
  assert.ok(all(target).filter(node=>node.tagName==='a').every(node=>node.href.startsWith('/api/export/')));
});

for(const [synthetic,label] of [[true,'Yes (source-reported)'],[false,'No (source-reported)']]) {
  test(`existing explicit synthetic ${synthetic} retains its label`,()=>{
    const source=record(synthetic);delete source.source_evidence;delete source.source_bytes;
    const target=new Element('div');renderDetail(target,source,()=>{});
    assert.ok(text(target).includes(`Synthetic ${label}`));
  });
}
