import base64
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from awrc.arms_adapter import inspect_run
from awrc.store import EvidenceStore
from awrc.reporting import report

ROOT = Path(__file__).resolve().parents[1]

def native():
    return inspect_run(ROOT / 'fixtures/arms-native')

def encoded(value):
    return json.dumps(value).encode()

class NativeImportTests(unittest.TestCase):
    def test_durable_native_source_and_exact_files(self):
        source = native()
        raw = encoded(source)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'runs.db'
            with EvidenceStore(path) as store:
                record = store.import_bytes(raw)
                self.assertEqual(record['format'], 'awrc.arms-inspection.v0.1')
                self.assertEqual(store.import_bytes(raw)['revision'], 1)
                self.assertEqual(store.import_bytes(encoded(source)+b' ')['revision'], 2)
            with EvidenceStore(path) as store:
                restored = store.get(record['raw_sha256'])
                self.assertEqual(restored['source_inspection'], source)
                self.assertIsNone(restored['bundle']['outcome']['policy_outcome'])
                self.assertFalse(restored['source_inspection']['original']['outcome']['task_success'])
                self.assertTrue(restored['bundle']['outcome']['task_success'])
                self.assertEqual(len(restored['bundle']['checks']), 18)
                self.assertIn('Complete native source inspection', report(restored, 'markdown'))
                for name, entry in restored['source_inspection']['files'].items():
                    self.assertEqual(base64.b64decode(entry['base64']), (ROOT/'fixtures/arms-native'/name).read_bytes())
                self.assertEqual(store.compare(record['raw_sha256'], record['raw_sha256'])['counts']['a']['task']['total'],18)
                with self.assertRaises(Exception):
                    store._connection.execute('DELETE FROM native_runs')

    def test_reject_rebound_claims_without_rows(self):
        source = native()
        with EvidenceStore(':memory:') as store:
            for mutate in [lambda s:s.update(independently_verified=True),
                           lambda s:s.update(independently_verified=0),
                           lambda s:s.update(read_only=1),
                           lambda s:s['candidate'].update(passed_count=True),
                           lambda s:s['candidate'].update(passed_count=17),
                           lambda s:s['files']['repair.patch'].update(sha256='0'*64),
                           lambda s:s['files'].update({'../bad':s['files']['repair.patch']}),
                           lambda s:s['reviewed']['outcome'].update(task_success=False)]:
                changed=copy.deepcopy(source); mutate(changed)
                with self.assertRaises(ValueError):store.import_bytes(encoded(changed))
            self.assertEqual(store.list_runs(), [])

    def test_synthetic_changes_requested_and_cross_format_comparison(self):
        from awrc import arms_profile
        from awrc.arms_adapter import inspect_files
        source = native()
        files = {name:base64.b64decode(item['base64']) for name,item in source['files'].items()}
        receipt = copy.deepcopy(source['receipt'])
        receipt.update(decision='changes_requested', blocking_findings=1, notes='Synthetic QA receipt only')
        files['review-receipt.json'] = arms_profile.canonical_bytes(receipt)
        reviewed = copy.deepcopy(source['reviewed'])
        reviewed['provenance'].update(review_state='changes_requested', review_receipt_sha256=hashlib.sha256(files['review-receipt.json']).hexdigest())
        reviewed['outcome'].update(task_success=False, reason_code='review_changes_requested')
        files['reviewed-evidence.json'] = arms_profile.canonical_bytes(reviewed)
        other = inspect_files(files)
        with EvidenceStore(':memory:') as store:
            a = store.import_bytes(encoded(source)); b = store.import_bytes(encoded(other))
            comparison = store.compare(a['raw_sha256'], b['raw_sha256'])
            self.assertTrue(comparison['compatible'])
            self.assertEqual(comparison['counts']['b']['task']['passed'],18)
            self.assertFalse(comparison['outcomes']['b']['task_success'])
            fixture=store.import_bytes((ROOT/'fixtures/success.json').read_bytes())
            self.assertIn('format',store.compare(a['raw_sha256'],fixture['raw_sha256'])['reason'])
            # Same display identity must have independent revision numbering.
            fixture_source=json.loads((ROOT/'fixtures/success.json').read_bytes())
            for key in ['workflow_id','run_id','task_id']: fixture_source[key]=a['bundle'][key]
            collision=store.import_bytes(encoded(fixture_source))
            self.assertEqual(collision['revision'],1)
            self.assertEqual(store._connection.execute('SELECT COUNT(*) FROM native_runs').fetchone()[0],2)

    def test_strict_input_and_cli_reject_before_database_creation(self):
        import subprocess
        import sys
        from awrc.ingestion import ingest
        for raw in [b'{"schema_version":1,"schema_version":2}', b'{"a":NaN}', b'['*17+b'0'+b']'*17,
                    b'\xff', b'{}', b'x'*1048577]:
            with self.assertRaises(ValueError): ingest(raw)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp); (path/'bad.json').write_bytes(b'{}')
            result=subprocess.run([sys.executable,'-m','awrc','--db',str(path/'absent.db'),'import',str(path/'bad.json')],capture_output=True)
            self.assertEqual(result.returncode,1)
            self.assertFalse((path/'absent.db').exists())

    def test_stored_native_raw_tamper_detected(self):
        with EvidenceStore(':memory:') as store:
            record=store.import_bytes(encoded(native()))
            store._connection.execute('DROP TRIGGER native_no_update')
            store._connection.execute('UPDATE native_runs SET raw_bytes=?',(b'{}',))
            with self.assertRaises(ValueError):store.get(record['raw_sha256'])

    def test_synthetic_scope_and_configuration_mismatch_refuse_counts(self):
        from awrc import arms_profile
        from awrc.arms_adapter import inspect_files
        source = native()
        for field in ['scope_revision','digest']:
            files={name:base64.b64decode(item['base64']) for name,item in source['files'].items()}
            original=copy.deepcopy(source['original']); reviewed=copy.deepcopy(source['reviewed'])
            for envelope in [original,reviewed]:
                if field=='scope_revision': envelope['task'][field]='synthetic-QA-other-scope'
                else: envelope['configuration'][field]='a'*64
            receipt=copy.deepcopy(source['receipt']); receipt['evidence_sha256']=arms_profile.digest(original)
            files['review-receipt.json']=arms_profile.canonical_bytes(receipt)
            reviewed['provenance']['review_receipt_sha256']=hashlib.sha256(files['review-receipt.json']).hexdigest()
            files['evidence.json']=arms_profile.canonical_bytes(original)
            files['reviewed-evidence.json']=arms_profile.canonical_bytes(reviewed)
            changed=inspect_files(files)
            with EvidenceStore(':memory:') as store:
                a=store.import_bytes(encoded(source));b=store.import_bytes(encoded(changed))
                result=store.compare(a['raw_sha256'],b['raw_sha256'])
                self.assertFalse(result['compatible'])
                self.assertNotIn('counts',result)

    def test_native_projection_command_references_resolve_to_exact_artifact(self):
        source=native()
        from awrc.arms_adapter import ARTIFACTS
        with EvidenceStore(':memory:') as store:
            record=store.import_bytes(encoded(source))
        artifacts={item['id']:item for item in record['bundle']['artifacts']}
        for command in record['bundle']['commands']:
            for reference in command['artifact_ids']:
                self.assertIn(reference,artifacts)
                artifact=artifacts[reference]; filename=ARTIFACTS[reference]
                self.assertEqual(artifact['sha256'],source['files'][filename]['sha256'])
                self.assertEqual(artifact['text'].encode(),base64.b64decode(source['files'][filename]['base64']))
        self.assertTrue(set(ARTIFACTS).issubset(artifacts))
