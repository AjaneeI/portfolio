import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderComparison} from '../awrc/static/view.js';

// Minimal DOM surface for the actual renderer; browser downloads remain a separate check.
class Element {
  constructor(tag) { this.tagName=tag; this.children=[]; this.textContent=''; this.attributes={}; }
  append(...nodes) { this.children.push(...nodes); }
  replaceChildren(...nodes) { this.children=[...nodes]; }
  setAttribute(name,value) { this.attributes[name]=value; }
}
globalThis.document={createElement:tag=>new Element(tag),importNode:node=>node};
globalThis.DOMParser=class { parseFromString() { return {documentElement:new Element('svg')}; } };
function find(node,tag) { return [...(node.tagName===tag?[node]:[]),...node.children.flatMap(child=>find(child,tag))]; }
function text(node) { return [node.textContent,...node.children.map(text)].join(' '); }
const counts={task:{passed:0,failed:0,unknown:1,total:1},safety:{passed:0,failed:0,unknown:0,total:0}};
const outcome={task_success:null,policy_outcome:null};

for (const compatible of [true,false]) {
  test(`comparison ${compatible?'cases':'incompatibility'} retains download links for its displayed pair`,()=>{
    const result={a:'a'.repeat(64),b:'b'.repeat(64),independently_verified:false,compatible,
      ...(compatible?{comparison_stage:'candidate',counts:{a:counts,b:counts},outcomes:{a:outcome,b:outcome},
        assessments:{a:{evidence_status:'source_reported'},b:{evidence_status:'source_reported'}},
        cases:[{id:'case-1',kind:'task',a:'unknown',b:'unknown'}]}:{reason:'Different scope_revision'})};
    const target=new Element('div'); renderComparison(target,result);
    const links=find(target,'a');
    assert.equal(links.length,2);
    assert.deepEqual(links.map(text),['Export comparison JSON','Export comparison Markdown']);
    assert.deepEqual(links.map(link=>link.href),[
      `/api/export-comparison?a=${'a'.repeat(64)}&b=${'b'.repeat(64)}&format=json`,
      `/api/export-comparison?a=${'a'.repeat(64)}&b=${'b'.repeat(64)}&format=markdown`
    ]);
    assert.ok(links.every(link=>link.download===''));
    assert.equal(target.children.at(-1).children.length,2);
    result.a='c'.repeat(64); result.b='d'.repeat(64);
    assert.ok(links.every(link=>link.href.includes(`a=${'a'.repeat(64)}&b=${'b'.repeat(64)}`)));
    if (compatible) assert.equal(find(target,'tbody')[0].children.length,1);
    else assert.match(text(target),/Incompatible comparison: Different scope_revision/);
  });
}
