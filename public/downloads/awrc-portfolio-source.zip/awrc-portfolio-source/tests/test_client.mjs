import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
let model;
try { model = await import('../awrc/static/model.mjs'); } catch { model = {}; }
const fixtures = await Promise.all(['success','safe-denial','pending-approval','incomplete-success'].map(async name => ({raw_sha256:name,revision:1,bundle:JSON.parse(await readFile(new URL(`../fixtures/${name}.json`,import.meta.url)))})));
for (const fixture of fixtures) fixture.assessment={evidence_status:['success','safe-denial'].includes(fixture.raw_sha256)?'source_reported':'unverified'};

test('search covers workflow/run/task case-insensitively without changing raw records',()=>{
 assert.equal(typeof model.filterRecords,'function');
 assert.deepEqual(model.filterRecords(fixtures,{query:' SAFE-DENIAL '}).map(r=>r.raw_sha256),['safe-denial']);
 assert.equal(model.filterRecords(fixtures,{query:'WORKFLOW-1'}).length,4);
 assert.equal(model.filterRecords(fixtures,{query:'task-1'}).length,4);
 assert.equal(fixtures[0].bundle.run_id,'success');
});
test('outcome/policy/evidence filters combine with search and distinguish claims',()=>{
 assert.equal(typeof model.filterRecords,'function');
 assert.deepEqual(model.filterRecords(fixtures,{outcome:'success',evidence:'unverified'}).map(r=>r.raw_sha256),['incomplete-success']);
 assert.deepEqual(model.filterRecords(fixtures,{policy:'denied',evidence:'source_reported'}).map(r=>r.raw_sha256),['safe-denial']);
 assert.deepEqual(model.filterRecords(fixtures,{outcome:'pending',policy:'needs_approval'}).map(r=>r.raw_sha256),['pending-approval']);
 assert.equal(model.filterRecords(fixtures,{query:'absent'}).length,0);
});
test('filtered-out inspector clears rather than showing stale evidence',()=>{
 assert.equal(typeof model.visibleActive,'function');
 assert.equal(model.visibleActive(fixtures.slice(1),'success'),undefined);
 assert.equal(model.visibleActive(fixtures,'success'),'success');
 assert.equal(model.visibleActive([],undefined),undefined);
});
test('compare selection keeps hidden choices, caps two and reports hidden count',()=>{
 assert.equal(typeof model.toggleSelection,'function');
 let selected=model.toggleSelection(new Set(),'success');
 selected=model.toggleSelection(selected,'safe-denial');
 assert.deepEqual([...model.toggleSelection(selected,'pending-approval')],['success','safe-denial']);
 assert.deepEqual(model.selectionInfo(selected,fixtures.slice(2)),{count:2,hidden:2});
 selected=model.toggleSelection(selected,'success');
 assert.deepEqual([...selected],['safe-denial']);
 assert.deepEqual(model.selectionInfo(selected,fixtures),{count:1,hidden:0});
});

test('native source claims filter with unknown policy and preserve candidate outcome',()=>{
 const native={raw_sha256:'native',bundle:{workflow_id:'arms-native-offline',run_id:'uuid',task_id:'native-task',outcome:{task_success:false,execution_status:'completed',policy_outcome:null}},assessment:{evidence_status:'source_reported'}};
 assert.equal(model.filterRecords([native],{query:'native-task',policy:'unknown',evidence:'source_reported'}).length,1);
 assert.equal(model.outcomeKey(native.bundle),'not_completed');
});

test('native timing facts use compact UTC source time and distinct runner duration',()=>{
 assert.equal(typeof model.nativeTimingFacts,'function');
 const source={reviewed:{timestamps:{ended_at:'2026-10-21T03:45:55.159103Z'}},measurements:{source_reported_runner_duration_seconds:0.029971}};
 const facts=model.nativeTimingFacts(source);
 assert.deepEqual(facts,[['Run ended','21 Oct 2026 03:45:55 UTC (source-reported)'],['Runner duration','0.029971 s (source-reported; not model or human time)']]);
 assert.equal(source.reviewed.timestamps.ended_at,'2026-10-21T03:45:55.159103Z');
 assert.equal(model.nativeTimingFacts({...source,measurements:{source_reported_runner_duration_seconds:Infinity}})[1][1],'Unknown');
});
