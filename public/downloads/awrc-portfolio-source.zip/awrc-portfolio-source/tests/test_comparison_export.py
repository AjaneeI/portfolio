"""Comparison reports preserve the canonical calculation and both source records."""
import base64
import hashlib
import html
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import awrc
from awrc import EvidenceStore
from awrc.arms_adapter import inspect_run

ROOT = Path(__file__).resolve().parents[1]


class ComparisonExportTests(unittest.TestCase):
    def export(self, store, a, b, format='json'):
        self.assertTrue(callable(getattr(awrc, 'comparison_report', None)),
                        'Public comparison_report must export the canonical comparison')
        return awrc.comparison_report(store, a, b, format)

    def pair(self, store, *, incompatible=False, hostile=False):
        source = json.loads((ROOT / 'fixtures/success.json').read_bytes())
        if hostile:
            text = '<script>alert(1)</script> [go](https://evil.invalid) <https://evil.invalid> ![x](file:///x) `code`\n# title | cell'
            source['artifacts'][0].update(text=text, sha256=hashlib.sha256(text.encode()).hexdigest())
            source['configuration']['verifier_version'] = text
        a = store.import_bytes(json.dumps(source).encode())
        source['checks'][0]['outcome'] = 'unknown'
        source['outcome'].update(task_success=None, policy_outcome='needs_approval')
        source['commands'][0]['exit_code'] = None
        source['source']['head_sha'] = 'd' * 40
        if incompatible:
            source['scope_revision'] = 'different-scope'
        b = store.import_bytes(json.dumps(source).encode())
        return a, b

    def test_json_is_deterministic_with_exact_canonical_comparison_and_both_records(self):
        with EvidenceStore(':memory:') as store:
            a, b = self.pair(store)
            text = self.export(store, a['raw_sha256'], b['raw_sha256'])
            result = json.loads(text)
            self.assertEqual(result['schema_version'], 'awrc.comparison-report.v0.1')
            self.assertIs(result['independently_verified'], False)
            self.assertEqual(result['comparison'], store.compare(a['raw_sha256'], b['raw_sha256']))
            self.assertEqual(result['records'], {'a': store.get(a['raw_sha256']), 'b': store.get(b['raw_sha256'])})
            self.assertEqual(result['records'], {'a': a, 'b': b})
            self.assertEqual(result['comparison']['counts']['b']['task'], {'passed': 0, 'failed': 0, 'unknown': 1, 'total': 1})
            self.assertEqual([r['revision'] for r in result['records'].values()], [1, 2])
            self.assertIsNone(result['records']['b']['bundle']['timing'])
            self.assertEqual(result['records']['b']['bundle']['cost'], {'kind': 'unknown', 'value': None, 'currency': None})
            self.assertIsNone(result['records']['b']['bundle']['outcome']['task_success'])
            self.assertIsNone(result['records']['b']['bundle']['commands'][0]['exit_code'])
            self.assertEqual(text, self.export(store, a['raw_sha256'], b['raw_sha256']))
            self.assertEqual(awrc.report(a, 'json'), json.dumps(a, ensure_ascii=True, allow_nan=False, sort_keys=True, indent=2) + '\n')

    def test_incompatible_export_retains_exact_reason_without_invented_calculations(self):
        with EvidenceStore(':memory:') as store:
            a, b = self.pair(store, incompatible=True)
            result = json.loads(self.export(store, a['raw_sha256'], b['raw_sha256']))
            self.assertEqual(result['comparison'], {'a': a['raw_sha256'], 'b': b['raw_sha256'], 'independently_verified': False,
                                                   'compatible': False, 'reason': 'Different scope_revision'})
            self.assertEqual(result['records'], {'a': a, 'b': b})
            md = html.unescape(self.export(store, a['raw_sha256'], b['raw_sha256'], 'markdown'))
            self.assertIn('Different scope_revision', md)
            self.assertNotIn('comparison.counts', md)
            self.assertNotIn('comparison.cases', md)
            self.assertIn('records.b.bundle.checks.0.outcome: "unknown"', md)

    def test_markdown_preserves_evidence_and_unknowns_with_inert_imported_text(self):
        with EvidenceStore(':memory:') as store:
            a, b = self.pair(store, hostile=True)
            md = self.export(store, a['raw_sha256'], b['raw_sha256'], 'markdown')
            for active in ['<script>', '[go](https://', '<https://', '![x](file://', '`code`', '\n# title']:
                self.assertNotIn(active, md)
            decoded = html.unescape(md)
            for expected in ['comparison.counts.b.task.unknown: 1', 'comparison.counts.b.task.total: 1',
                             'comparison.cases.0.b: "unknown"', 'records.b.bundle.timing: unknown',
                             'records.b.bundle.cost.value: unknown', 'records.b.bundle.outcome.task_success: unknown',
                             'records.b.bundle.commands.0.exit_code: unknown', 'records.b.revision: 2']:
                self.assertIn(expected, decoded)
            for side, record in [('a', a), ('b', b)]:
                self.assertIn(f'records.{side}.raw_sha256: "{record["raw_sha256"]}"', decoded)
                self.assertIn(json.dumps(record['bundle']['artifacts'][0]['text'], ensure_ascii=True), decoded)
            self.assertEqual(md, self.export(store, a['raw_sha256'], b['raw_sha256'], 'markdown'))

    def test_native_export_preserves_both_complete_sources_and_candidate_only_counts(self):
        source = inspect_run(ROOT / 'fixtures/arms-native')
        raw = json.dumps(source).encode()
        with EvidenceStore(':memory:') as store:
            a = store.import_bytes(raw)
            b = store.import_bytes(raw + b'\n')
            result = json.loads(self.export(store, a['raw_sha256'], b['raw_sha256']))
            self.assertEqual(result['comparison'], store.compare(a['raw_sha256'], b['raw_sha256']))
            self.assertEqual(result['records'], {'a': a, 'b': b})
            self.assertEqual(result['comparison']['comparison_stage'], 'candidate')
            self.assertEqual(result['comparison']['counts']['a']['task']['total'], 18)
            self.assertEqual(result['comparison']['counts']['b']['safety']['total'], 0)
            md = html.unescape(self.export(store, a['raw_sha256'], b['raw_sha256'], 'markdown'))
            self.assertIn('review is unauthenticated', md)
            self.assertIn('not new workflow runs', md)
            for side in ['a', 'b']:
                saved = result['records'][side]['source_inspection']
                self.assertEqual(saved, source)
                self.assertEqual(saved['baseline']['passed_count'], 6)
                self.assertEqual(saved['baseline']['failed_count'], 12)
                self.assertFalse(saved['original']['outcome']['task_success'])
                self.assertTrue(saved['reviewed']['outcome']['task_success'])
                self.assertIn(f'records.{side}.source_inspection.baseline.failed_count: 12', md)
                for name, entry in saved['files'].items():
                    self.assertEqual(base64.b64decode(entry['base64']), (ROOT / 'fixtures/arms-native' / name).read_bytes())
                    for field in ['base64', 'sha256', 'size_bytes']:
                        self.assertIn(f'records.{side}.source_inspection.files.{name}.{field}: {json.dumps(entry[field])}', md)
            fixture = store.import_bytes((ROOT / 'fixtures/success.json').read_bytes())
            mixed = json.loads(self.export(store, a['raw_sha256'], fixture['raw_sha256']))
            self.assertEqual(mixed['comparison']['reason'], 'Different import format (native versus fixture)')
            self.assertNotIn('counts', mixed['comparison'])

    def test_export_revalidates_both_stored_rows_and_rejects_invalid_format_or_digest(self):
        with EvidenceStore(':memory:') as store:
            a, b = self.pair(store)
            for left, right, format, error in [(a['raw_sha256'], b['raw_sha256'], 'html', ValueError),
                                              ('invalid', b['raw_sha256'], 'json', ValueError),
                                              (a['raw_sha256'], 'f' * 64, 'json', KeyError)]:
                with self.subTest(left=left, right=right, format=format), self.assertRaises(error):
                    self.export(store, left, right, format)
            store._connection.execute('DROP TRIGGER runs_no_update')
            store._connection.execute('UPDATE runs SET raw_bytes=? WHERE raw_sha256=?', (b'{}', b['raw_sha256']))
            for left, right in [(a['raw_sha256'], b['raw_sha256']), (b['raw_sha256'], a['raw_sha256'])]:
                with self.assertRaises(ValueError):
                    self.export(store, left, right)

    def test_cli_exports_both_formats_and_incompatible_reason_without_database_mutation(self):
        with tempfile.TemporaryDirectory(dir='/private/tmp') as tmp:
            path = Path(tmp) / 'runs.sqlite'
            with EvidenceStore(path) as store:
                a, b = self.pair(store, incompatible=True)
                expected = store.compare(a['raw_sha256'], b['raw_sha256'])
            before = path.read_bytes()
            def cli(*args):
                return subprocess.run([sys.executable, '-m', 'awrc', '--db', str(path), 'export-comparison', *args],
                                      cwd=ROOT, capture_output=True, text=True, timeout=5)
            for format in ['json', 'markdown']:
                result = cli(a['raw_sha256'], b['raw_sha256'], '--format', format)
                self.assertEqual(result.returncode, 0, result.stderr)
                if format == 'json':
                    self.assertEqual(json.loads(result.stdout)['comparison'], expected)
                    self.assertEqual(json.loads(result.stdout)['records'], {'a': a, 'b': b})
                else:
                    self.assertIn('Different scope', html.unescape(result.stdout))
            for args in [(a['raw_sha256'], 'f' * 64, '--format', 'json'),
                         ('DO_NOT_ECHO', b['raw_sha256'], '--format', 'json'),
                         (a['raw_sha256'], b['raw_sha256'], '--format', 'html')]:
                result = cli(*args)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertNotIn('Traceback', result.stderr)
                self.assertNotIn('DO_NOT_ECHO', result.stderr)
            self.assertEqual(path.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
