import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from awrc.arms_adapter import inspect_run, checks, ARTIFACTS
from awrc import arms_profile as profile

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures/arms-native"

class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir="/private/tmp")
        self.addCleanup(self.tmp.cleanup)
        self.run = Path(self.tmp.name) / "run"
        shutil.copytree(FIXTURE, self.run)

    def alter(self, name, change):
        path = self.run / name
        obj = json.loads(path.read_bytes())
        change(obj)
        path.write_text(json.dumps(obj))

    def test_preserved_native(self):
        report = inspect_run(self.run)
        self.assertEqual((report["baseline"]["passed_count"], report["baseline"]["failed_count"]), (6, 12))
        self.assertEqual(report["candidate"]["passed_count"], 18)
        self.assertFalse(report["independently_verified"])
        self.assertFalse(report["original"]["outcome"]["task_success"])
        self.assertTrue(report["reviewed"]["outcome"]["task_success"])
        for name, identity in report["files"].items():
            raw = (FIXTURE / name).read_bytes()
            self.assertEqual(base64.b64decode(identity["base64"]), raw)
            self.assertEqual(identity["sha256"], hashlib.sha256(raw).hexdigest())

    def test_invalid_envelopes_and_receipts(self):
        mutations = [
          ("reviewed-evidence.json", lambda x: x["task"].update(task_id="forged")),
          ("review-receipt.json", lambda x: x.update(evidence_sha256="0"*64)),
          ("review-receipt.json", lambda x: x.update(reviewer=" ARMS-HOST-V0.1 ")),
          ("review-receipt.json", lambda x: x.update(blocking_findings=True)),
          ("review-receipt.json", lambda x: x.update(blocking_findings=1)),
          ("evidence.json", lambda x: x["outcome"].update(task_success=True)),
          ("evidence.json", lambda x: x.update(unknown=1)),
          ("evidence.json", lambda x: x.update(schema_version="ev.v2")),
          ("baseline-checks.json", lambda x: x.update(suite_digest="0"*64)),
          ("candidate-checks.json", lambda x: x.update(verifier_version="other")),
          ("baseline-checks.json", lambda x: x["checks"][1].update(passed=True)),
          ("candidate-checks.json", lambda x: x["checks"].append(x["checks"][0])),
          ("candidate-checks.json", lambda x: x["checks"][0].update(actual=float("nan"))),
        ]
        for name, mutation in mutations:
            with self.subTest(name=name, mutation=mutation):
                shutil.rmtree(self.run)
                shutil.copytree(FIXTURE, self.run)
                self.alter(name, mutation)
                with self.assertRaises(ValueError): inspect_run(self.run)

    def test_result_semantics_with_matching_hashes(self):
        config = json.loads((self.run/"evidence.json").read_bytes())["configuration"]
        mutations = [lambda x: x.update(suite_digest="0"*64),
                     lambda x: x.update(verifier_version="wrong"),
                     lambda x: x.update(extra=True),
                     lambda x: x["checks"][1].update(passed=True),
                     lambda x: x["checks"][1].update(actual=True),
                     lambda x: x["checks"][1].update(actual=float("inf")),
                     lambda x: x["checks"].append(x["checks"][0]),
                     lambda x: x.update(passed=True)]
        for mutation in mutations:
            obj = json.loads((FIXTURE/"baseline-checks.json").read_bytes())
            mutation(obj)
            with self.assertRaises(ValueError): checks(json.dumps(obj).encode(), config, False)

    def test_rebound_mismatched_case_sets(self):
        candidate = json.loads((self.run/"candidate-checks.json").read_bytes())
        candidate["checks"].pop()
        (self.run/"candidate-checks.json").write_bytes(profile.canonical_bytes(candidate))
        self.rebind()
        with self.assertRaises(ValueError): inspect_run(self.run)

    def rebind(self, decision="approved"):
        original = json.loads((self.run/"evidence.json").read_bytes())
        for artifact in original["artifacts"]:
            data = (self.run/ARTIFACTS[artifact["id"]]).read_bytes()
            artifact.update(sha256=hashlib.sha256(data).hexdigest(), size_bytes=len(data))
        (self.run/"evidence.json").write_bytes(profile.canonical_bytes(original))
        receipt = json.loads((self.run/"review-receipt.json").read_bytes())
        receipt.update(evidence_sha256=profile.digest(original), decision=decision)
        (self.run/"review-receipt.json").write_bytes(profile.canonical_bytes(receipt))
        reviewed = copy.deepcopy(original)
        reviewed["provenance"].update(reviewer=receipt["reviewer"], reviewed_head=receipt["head_sha"],
            review_state=decision, review_receipt_sha256=profile.digest(receipt))
        reviewed["outcome"].update(task_success=decision=="approved", reason_code=
            "reviewed_synthetic_fix" if decision=="approved" else "review_changes_requested")
        (self.run/"reviewed-evidence.json").write_bytes(profile.canonical_bytes(reviewed))

    def test_complete_suite_control_preserves_untrusted_actuals(self):
        # Ordering is not part of case identity; actuals are historical claims.
        for name in ("baseline-checks.json", "candidate-checks.json"):
            obj = json.loads((self.run/name).read_bytes())
            obj["checks"].reverse()
            if name == "baseline-checks.json":
                next(case for case in obj["checks"] if not case["passed"])["actual"] = 999
            (self.run/name).write_bytes(profile.canonical_bytes(obj))
        self.rebind()
        report = inspect_run(self.run)
        self.assertEqual(report["baseline"]["total_count"], 18)
        self.assertEqual(report["baseline"]["failed_count"], 12)
        self.assertIn(999, [case["actual"] for case in report["baseline"]["checks"]])
        self.assertFalse(report["independently_verified"])

    def test_paired_suite_forgery(self):
        for mode in ("omit", "expected", "extra", "rename", "suite", "verifier", "fixture"):
            with self.subTest(mode=mode):
                shutil.rmtree(self.run)
                shutil.copytree(FIXTURE, self.run)
                if mode in ("suite", "verifier", "fixture"):
                    original = json.loads((self.run/"evidence.json").read_bytes())
                    if mode == "fixture":
                        original["task"]["fixture_id"] = "unsupported"
                    else:
                        field = "suite_digest" if mode == "suite" else "verifier_version"
                        value = "0"*64 if mode == "suite" else "unsupported"
                        original["configuration"][field] = value
                        for name in ("baseline-checks.json", "candidate-checks.json"):
                            self.alter(name, lambda x: x.update({field: value}))
                    (self.run/"evidence.json").write_bytes(profile.canonical_bytes(original))
                else:
                    for name in ("baseline-checks.json", "candidate-checks.json"):
                        obj = json.loads((self.run/name).read_bytes())
                        if mode == "omit":
                            obj["checks"] = obj["checks"][:2]
                        elif mode == "expected":
                            obj["checks"][0].update(actual=999, expected=999)
                        elif mode == "extra":
                            obj["checks"].append(dict(id="extra-case", actual=0, expected=0, passed=True))
                        elif mode == "rename":
                            obj["checks"][0]["id"] = "renamed-case"
                        (self.run/name).write_bytes(profile.canonical_bytes(obj))
                self.rebind()
                with self.assertRaises(ValueError): inspect_run(self.run)

    def test_changes_requested(self):
        self.rebind("changes_requested")
        report = inspect_run(self.run)
        self.assertFalse(report["reviewed"]["outcome"]["task_success"])
        self.assertFalse(report["independently_verified"])

    def test_artifact_and_aggregate_bounds(self):
        (self.run/"repair.patch").write_bytes(b"changed")
        with self.assertRaises(ValueError): inspect_run(self.run)
        for name in ("repair.patch", "journal.json", "source-hashes.json"):
            (self.run/name).write_bytes(b"x"*800000)
        with self.assertRaises(ValueError): inspect_run(self.run)

    def test_raw_receipt_identity(self):
        path = self.run / "review-receipt.json"
        path.write_bytes(path.read_bytes() + b" ")
        with self.assertRaises(ValueError): inspect_run(self.run)

    def test_bad_files(self):
        for raw in (b'{"x":1,"x":2}', b'['*100+b']'*100, b'x'*1048577):
            (self.run / "evidence.json").write_bytes(raw)
            with self.assertRaises(ValueError): inspect_run(self.run)
        path = self.run / "evidence.json"
        path.unlink()
        path.symlink_to(FIXTURE / "evidence.json")
        with self.assertRaises(ValueError): inspect_run(self.run)
        path.unlink()
        os.mkfifo(path)
        with self.assertRaises(ValueError): inspect_run(self.run)
        path.unlink()
        path.mkdir()
        with self.assertRaises(ValueError): inspect_run(self.run)

    def test_directory_symlink_and_missing(self):
        link = Path(self.tmp.name)/"link"
        link.symlink_to(self.run, target_is_directory=True)
        with self.assertRaises(ValueError): inspect_run(link)
        (self.run/"reviewed-evidence.json").unlink()
        with self.assertRaises(ValueError): inspect_run(self.run)

    def test_cli_no_write_and_generic_error(self):
        before = {str(p.relative_to(self.run)):p.read_bytes() for p in self.run.iterdir()}
        result = subprocess.run([sys.executable, "-m", "awrc.arms_adapter", str(self.run)], capture_output=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), inspect_run(self.run))
        self.assertEqual(before, {str(p.relative_to(self.run)):p.read_bytes() for p in self.run.iterdir()})
        (self.run/"evidence.json").unlink()
        result = subprocess.run([sys.executable, "-m", "awrc.arms_adapter", str(self.run)], capture_output=True, timeout=5)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b"")
        self.assertEqual(result.stderr, b"Unsupported or invalid ARMS offline bundle\n")
