"""Raw EV bridge acceptance; synthetic mutations are data, never executions."""
import base64
import copy
import hashlib
import http.client
import io
from types import SimpleNamespace
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

from awrc.arms_profile import loads_evidence
from awrc.arms_adapter import inspect_run
from awrc.reporting import report, comparison_report
from awrc.store import EvidenceStore

ROOT = Path(__file__).resolve().parents[1]


def encode(source):
    return json.dumps(source, ensure_ascii=False, allow_nan=False, indent=2).encode()


def envelope(name='evidence.json'):
    return json.loads((ROOT / 'fixtures/arms-native' / name).read_bytes())


def sparse(state):
    source = envelope()
    source['outcome'].update(execution=state, verification='unverified', task_success=False,
                             reason_code='incomplete' if state == 'pending' else state)
    source['source'].update(head_sha=None, tree_sha=None)
    source['commands'] = []; source['artifacts'] = []; source['events'] = []
    source['metrics'] = dict(duration_seconds=None, human_minutes=None, cost_amount=None, cost_currency=None)
    return source


class EnvelopeImportTests(unittest.TestCase):
    def accepted(self, store, raw):
        loads_evidence(raw)  # New bridge must consume producer-valid specimens.
        try:
            return store.import_bytes(raw)
        except ValueError as exc:
            self.fail(f'Producer-valid raw ev.v0.1 intake is missing: {exc}')

    def test_all_source_states_preserved_separately_and_always_unverified(self):
        sources = [envelope(), envelope('reviewed-evidence.json')]
        sources += [sparse(state) for state in ['completed', 'failed', 'denied', 'unverified', 'pending']]
        with EvidenceStore(':memory:') as store:
            for source in sources:
                with self.subTest(outcome=source['outcome']):
                    record = self.accepted(store, encode(source))
                    bundle = record['bundle']
                    self.assertEqual(record['format'], 'ev.v0.1')
                    self.assertEqual(record['source_evidence'], source)
                    self.assertNotIn('source_inspection', record)
                    self.assertEqual(bundle['workflow_id'], 'arms-native-envelope')
                    self.assertEqual(bundle['outcome']['execution_status'], source['outcome']['execution'])
                    self.assertIs(bundle['outcome']['task_success'], source['outcome']['task_success'])
                    self.assertEqual(bundle['outcome']['claimed_verification'], source['outcome']['verification'])
                    self.assertEqual(bundle['outcome']['reason_code'], source['outcome']['reason_code'])
                    self.assertIsNone(bundle['outcome']['policy_outcome'])
                    self.assertEqual(record['assessment']['evidence_status'], 'unverified')
                    self.assertIs(record['assessment']['independently_verified'], False)
                    self.assertIsNone(bundle['source']['synthetic'])
                    self.assertEqual(bundle['checks'], [])
                    self.assertEqual(bundle['artifacts'], [])
                    self.assertTrue(all(command['artifact_ids'] == [] for command in bundle['commands']))
                    self.assertEqual(bundle['cost'], {'kind':'unknown'})
                    self.assertNotIn('model', bundle)
                    self.assertIn('projection', record['assessment']['notice'])

    def test_exact_bytes_durable_idempotent_revisions_immutable_and_exports(self):
        source = envelope('reviewed-evidence.json'); raw = b' \n' + encode(source) + b'\n '
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'evidence.sqlite'
            with EvidenceStore(db) as store:
                record = self.accepted(store, raw)
                self.assertEqual(store.import_bytes(raw), record)
                self.assertEqual(store.import_bytes(raw + b' ')['revision'], 2)
                row = store._connection.execute('SELECT raw_bytes FROM native_runs WHERE raw_sha256=?', (record['raw_sha256'],)).fetchone()
                self.assertEqual(row[0], raw)
                for sql in ['DELETE FROM native_runs', 'UPDATE native_runs SET raw_bytes=x\'00\'']:
                    with self.assertRaises(sqlite3.IntegrityError): store._connection.execute(sql)
            with EvidenceStore(db) as store:
                restored = store.get(record['raw_sha256'])
                self.assertEqual(restored, record)
                self.assertIn(record, store.list_runs())
                self.assertEqual(restored['source_bytes'], dict(base64=base64.b64encode(raw).decode(),
                    sha256=hashlib.sha256(raw).hexdigest(), size_bytes=len(raw)))
                self.assertEqual(json.loads(report(restored, 'json')), restored)
                markdown = report(restored, 'markdown')
                self.assertIn('source&#95;evidence', markdown)
                self.assertIn('source&#95;bytes', markdown)
                self.assertIn(base64.b64encode(raw).decode(), markdown)

    def test_raw_comparisons_always_refuse_even_identical_and_export_complete_records(self):
        with EvidenceStore(':memory:') as store:
            raw = encode(envelope()); a = self.accepted(store, raw)
            b = self.accepted(store, encode(sparse('denied')))
            fixture = store.import_bytes((ROOT / 'fixtures/success.json').read_bytes())
            native = store.import_bytes(encode(inspect_run(ROOT / 'fixtures/arms-native')))
            for left, right in [(a,a),(a,b),(a,fixture),(fixture,a),(a,native),(native,a)]:
                with self.subTest(formats=(left.get('format'), right.get('format'))):
                    result = store.compare(left['raw_sha256'], right['raw_sha256'])
                    self.assertIs(result['compatible'], False)
                    self.assertNotIn('counts', result); self.assertNotIn('cases', result)
                    self.assertNotIn('improvement', result)
                    self.assertIn('supporting', result['reason'])
                    exported = json.loads(comparison_report(store, left['raw_sha256'], right['raw_sha256'], 'json'))
                    self.assertEqual(exported['records'], {'a':left, 'b':right})
                    self.assertEqual(exported['comparison'], result)
                    self.assertIn('source&#95;evidence', comparison_report(store, left['raw_sha256'], right['raw_sha256'], 'markdown'))

    def test_all_invalid_inputs_reject_without_rows_or_external_effects(self):
        valid = envelope(); invalid = []
        mutations = [lambda s:s.update(schema_version='ev.v0.0'), lambda s:s.update(schema_version='ev.v0.2'),
            lambda s:s.update(product='other'), lambda s:s.update(extra='unknown'),
            lambda s:s['source'].update(synthetic=False), lambda s:s['configuration'].update(extra=1),
            lambda s:s['outcome'].update(task_success=1), lambda s:s['commands'][0].update(exit_code=True),
            lambda s:s['configuration']['limits'].update(max_attempts=True),
            lambda s:s['metrics'].update(human_minutes=True), lambda s:s['artifacts'][0].update(size_bytes=False),
            lambda s:s['artifacts'][0].update(id='../secret'), lambda s:s['commands'][0].update(id='/bin/sh'),
            lambda s:s['commands'][0].update(artifact_id='missing'),
            lambda s:s['provenance'].update(reviewer='forged'),
            lambda s:s['outcome'].update(task_success=True)]
        for mutate in mutations:
            source = copy.deepcopy(valid); mutate(source); invalid.append(encode(source))
        for state in ['needs_approval', 'incomplete', 'unknown']:
            source = sparse('pending'); source['outcome']['execution'] = state; invalid.append(encode(source))
        raw = encode(valid)
        numeric_raw = encode(sparse('failed'))
        invalid += [numeric_raw.replace(b'"human_minutes": null', b'"human_minutes": ' + value)
                    for value in [b'NaN', b'Infinity', b'1e999']]
        invalid += [raw.replace(b'"max_attempts": 1', b'"max_attempts": 1, "max_attempts": 1'),
            raw.replace(b'"duration_seconds":', b'"duration_seconds": NaN, "discard":'),
            raw.replace(b'"duration_seconds":', b'"duration_seconds": Infinity, "discard":'),
            raw.replace(b'"duration_seconds":', b'"duration_seconds": 1e999, "discard":'),
            raw + b' ' * (256 * 1024), b'[' * 17 + b'0' + b']' * 17, b'\xff',
            b'{"status":"needs_approval","performed":false}', b'{}']
        with EvidenceStore(':memory:') as store, patch('socket.socket', side_effect=AssertionError('unexpected network')), \
                patch('subprocess.Popen', side_effect=AssertionError('unexpected execution')):
            for index, raw in enumerate(invalid):
                with self.subTest(vector=index):
                    with self.assertRaises(ValueError): store.import_bytes(raw)
                    self.assertEqual(store.list_runs(), [])
                    for table in ['runs', 'native_runs']:
                        self.assertEqual(store._connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0], 0)

    def test_accepted_malicious_text_inert_and_original_metrics_are_only_source_claims(self):
        source = sparse('failed')
        malicious = '<script>owned()</script>[link](https://evil.invalid) `$(touch owned)`'
        source['task']['repository'] = malicious
        source['limitations'] = [malicious]
        source['metrics'].update(human_minutes=9, cost_amount=12, cost_currency='USD')
        with EvidenceStore(':memory:') as store, patch('socket.socket', side_effect=AssertionError('unexpected network')), \
                patch('subprocess.Popen', side_effect=AssertionError('unexpected execution')):
            record = self.accepted(store, encode(source))
            self.assertEqual(record['source_evidence'], source)
            md = report(record, 'markdown')
            self.assertNotIn('<script>', md); self.assertNotIn('https://', md); self.assertNotIn('[link]', md)
            self.assertNotIn('`', md)
            self.assertEqual(record['bundle']['cost'], {'kind':'unknown'})
            self.assertEqual(len(store.list_runs()), 1)

    def test_cli_import_show_list_exports_and_reject_before_database_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp).resolve(); db = folder / 'runs.sqlite'; path = folder / 'raw.json'
            raw = encode(sparse('denied')); path.write_bytes(raw)
            def cli(*args):
                result = subprocess.run([sys.executable, '-m', 'awrc', '--db', str(db), *args], capture_output=True)
                self.assertEqual(result.returncode, 0, result.stderr)
                return json.loads(result.stdout)
            record = cli('import', str(path)); digest = record['raw_sha256']
            self.assertEqual(cli('show', digest), record)
            self.assertEqual(cli('list'), [record])
            self.assertEqual(cli('export', digest, '--format', 'json'), record)
            comparison = cli('export-comparison', digest, digest, '--format', 'json')
            self.assertFalse(comparison['comparison']['compatible'])
            self.assertEqual(comparison['records'], {'a':record, 'b':record})
            bad = folder / 'bad.json'; bad.write_bytes(encode({**sparse('denied'), 'extra':1}))
            absent = folder / 'absent.sqlite'
            result = subprocess.run([sys.executable, '-m', 'awrc', '--db', str(absent), 'import', str(bad)], capture_output=True)
            self.assertEqual(result.returncode, 1); self.assertFalse(absent.exists())

    def test_stored_envelope_tamper_is_detected(self):
        with EvidenceStore(':memory:') as store:
            record = self.accepted(store, encode(sparse('failed')))
            store._connection.execute('DROP TRIGGER native_no_update')
            store._connection.execute('UPDATE native_runs SET raw_bytes=?', (b'{}',))
            with self.assertRaisesRegex(ValueError, 'integrity'): store.get(record['raw_sha256'])


class EnvelopeHTTPTests(unittest.TestCase):
    def test_existing_routes_import_get_list_export_comparison_and_negative_no_rows(self):
        from awrc.web import create_server
        with tempfile.TemporaryDirectory() as tmp:
            server = create_server(Path(tmp) / 'runs.sqlite', 0)
            worker = threading.Thread(target=server.serve_forever, daemon=True); worker.start()
            origin = f'http://127.0.0.1:{server.server_port}'
            def request(method, path, raw=None, headers=None):
                conn = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=3)
                try:
                    conn.request(method, path, body=raw, headers=headers or {})
                    response = conn.getresponse(); return response.status, dict(response.getheaders()), response.read()
                finally: conn.close()
            try:
                token = json.loads(request('GET', '/api/bootstrap')[2])['csrf_token']
                headers = {'Origin':origin, 'X-AWRC-CSRF':token, 'Content-Type':'application/json'}
                invalid = encode({**sparse('denied'), 'unknown':True})
                self.assertEqual(request('POST', '/api/import', invalid, headers)[0], 400)
                self.assertEqual(json.loads(request('GET', '/api/runs')[2]), [])
                raw = b'\n' + encode(envelope('reviewed-evidence.json'))
                status, _, body = request('POST', '/api/import', raw, headers)
                self.assertEqual(status, 200, body)
                record = json.loads(body); digest = record['raw_sha256']
                self.assertEqual(base64.b64decode(record['source_bytes']['base64']), raw)
                self.assertEqual(json.loads(request('GET', '/api/runs')[2]), [record])
                self.assertEqual(json.loads(request('GET', f'/api/runs/{digest}')[2]), record)
                for format in ['json', 'markdown']:
                    for url in [f'/api/export/{digest}?format={format}',
                                f'/api/export-comparison?a={digest}&b={digest}&format={format}']:
                        status, response_headers, body = request('GET', url)
                        self.assertEqual(status, 200); self.assertIn('attachment;', response_headers['Content-Disposition'])
                        self.assertIn(b'source_evidence' if format == 'json' else b'source&#95;evidence', body)
                        self.assertIn(b'source_bytes' if format == 'json' else b'source&#95;bytes', body)
            finally:
                server.shutdown(); server.server_close(); worker.join(2)


class EnvelopeSocketFreeHandlerTests(unittest.TestCase):
    def test_real_handler_routes_with_memory_transport_not_a_live_http_acceptance(self):
        from awrc.web import Handler

        class MemoryTransport:
            def __init__(self, request):
                self.input = io.BytesIO(request); self.output = bytearray()
            def makefile(self, *args): return self.input
            def sendall(self, data): self.output.extend(data)
            def settimeout(self, timeout): pass

        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'handler.sqlite'
            server = SimpleNamespace(server_port=8765, origin='http://127.0.0.1:8765',
                                     csrf='socket-free-test-token', db_path=db)
            def request(method, path, body=b''):
                lines = [f'{method} {path} HTTP/1.1', 'Host: 127.0.0.1:8765',
                         'Origin: ' + server.origin, 'X-AWRC-CSRF: ' + server.csrf,
                         'Content-Type: application/json', f'Content-Length: {len(body)}']
                transport = MemoryTransport(('\r\n'.join(lines) + '\r\n\r\n').encode() + body)
                Handler(transport, ('127.0.0.1', 1234), server)
                head, _, data = bytes(transport.output).partition(b'\r\n\r\n')
                return int(head.split()[1]), head, data

            with patch('socket.socket', side_effect=AssertionError('unexpected socket')), \
                    patch('subprocess.Popen', side_effect=AssertionError('unexpected execution')):
                invalid = encode({**sparse('denied'), 'extra':True})
                self.assertEqual(request('POST', '/api/import', invalid)[0], 400)
                self.assertFalse(db.exists())
                raw = b'\n' + encode(envelope('reviewed-evidence.json')) + b' '
                status, _, body = request('POST', '/api/import', raw)
                self.assertEqual(status, 200)
                record = json.loads(body); digest = record['raw_sha256']
                self.assertEqual(record['source_evidence'], json.loads(raw))
                self.assertEqual(base64.b64decode(record['source_bytes']['base64']), raw)
                self.assertEqual(json.loads(request('GET', '/api/runs')[2]), [record])
                self.assertEqual(json.loads(request('GET', f'/api/runs/{digest}')[2]), record)
                before = db.read_bytes()
                self.assertEqual(request('POST', '/api/import', invalid)[0], 400)
                self.assertEqual(db.read_bytes(), before)
                compared = json.loads(request('GET', f'/api/compare?a={digest}&b={digest}')[2])
                self.assertFalse(compared['compatible']); self.assertNotIn('counts', compared)
                for format in ['json', 'markdown']:
                    for url in [f'/api/export/{digest}?format={format}',
                                f'/api/export-comparison?a={digest}&b={digest}&format={format}']:
                        status, headers, body = request('GET', url)
                        self.assertEqual(status, 200)
                        self.assertIn(b'Content-Disposition: attachment;', headers)
                        self.assertIn(b'X-Content-Type-Options: nosniff', headers)
                        self.assertIn(b'source_evidence' if format == 'json' else b'source&#95;evidence', body)
                        self.assertIn(b'source_bytes' if format == 'json' else b'source&#95;bytes', body)
                        if format == 'json':
                            exported = json.loads(body)
                            self.assertEqual(exported['records'] if 'records' in exported else exported,
                                             {'a':record, 'b':record} if 'records' in exported else record)
                self.assertEqual(db.read_bytes(), before)
