"""Exact native chronology at public validation and import boundaries."""
import base64
import copy
import json
from pathlib import Path
import unittest

from awrc import arms_profile as profile
from awrc.arms_adapter import FILES, inspect_files
from awrc.reporting import report
from awrc.store import EvidenceStore


FIXTURES = Path(__file__).resolve().parents[1] / 'fixtures/arms-native'


def envelope(start, end, events=()):
    source = json.loads((FIXTURES / 'evidence.json').read_bytes())
    source['timestamps'] = {'started_at': start, 'ended_at': end}
    source['events'] = [dict(stage=f'stage-{index}', status='observed', at=at)
                        for index, at in enumerate(events)]
    return source


def encode(source):
    return json.dumps(source, indent=2).encode('utf-8')


def reviewed_files(source):
    """Bind the changed claim coherently so stale hashes cannot cause rejection."""
    files = {name: (FIXTURES / name).read_bytes() for name in FILES}
    receipt = json.loads(files['review-receipt.json'])
    receipt['evidence_sha256'] = profile.digest(source)
    files['evidence.json'] = profile.canonical_bytes(source)
    files['review-receipt.json'] = profile.canonical_bytes(receipt)
    reviewed = copy.deepcopy(source)
    reviewed['provenance'].update(
        reviewer=receipt['reviewer'], reviewed_head=receipt['head_sha'],
        review_state=receipt['decision'], review_receipt_sha256=profile.digest(receipt))
    reviewed['outcome'].update(task_success=True, reason_code='reviewed_synthetic_fix')
    files['reviewed-evidence.json'] = profile.canonical_bytes(reviewed)
    return files


class NativeChronologyTests(unittest.TestCase):
    def test_reverse_submicrosecond_run_bounds_reject(self):
        # Literal pairs differ only below microsecond precision; all end earlier.
        pairs = [
            ('2026-10-21T03:45:55.0000009Z', '2026-10-21T03:45:55.0000008Z'),
            ('2026-10-21T03:45:55.00000009Z', '2026-10-21T03:45:55.00000008Z'),
            ('2026-10-21T03:45:55.000000009Z', '2026-10-21T03:45:55.000000008Z'),
            ('2026-10-21T04:45:55.000000009+01:00', '2026-10-21T03:45:55.000000008Z'),
            ('2026-10-21T00:00:00.000000009Z', '2026-10-20T23:00:00.000000008-01:00'),
        ]
        for start, end in pairs:
            with self.subTest(start=start, end=end):
                with self.assertRaisesRegex(ValueError, 'end precedes start'):
                    profile.loads_evidence(encode(envelope(start, end)))

    def test_reverse_submicrosecond_events_reject(self):
        pairs = [
            ('2026-10-21T03:45:55.000000009Z', '2026-10-21T03:45:55.000000008Z'),
            ('2026-10-21T03:45:55.00000001Z', '2026-10-21T03:45:55.000000009Z'),
            ('2026-10-21T04:45:55.000000009+01:00', '2026-10-21T03:45:55.000000008Z'),
        ]
        for earlier_in_list, later_in_list in pairs:
            with self.subTest(events=(earlier_in_list, later_in_list)):
                source = envelope('2026-10-21T03:45:55Z', '2026-10-21T03:45:56Z',
                                  [earlier_in_list, later_in_list])
                with self.assertRaisesRegex(ValueError, 'chronologically ordered'):
                    profile.loads_evidence(encode(source))

    def test_equal_increasing_offset_and_calendar_boundary_instants_accept(self):
        pairs = [
            ('2026-10-21T03:45:55Z', '2026-10-21T03:45:55.000000000+00:00'),
            ('2026-10-21T03:45:55.1Z', '2026-10-21T03:45:55.100000000Z'),
            ('2026-10-21T03:45:55.0000008Z', '2026-10-21T03:45:55.000000800Z'),
            ('2026-10-21T03:45:55.000000008Z', '2026-10-21T03:45:55.000000009Z'),
            ('2026-10-21T04:45:55.000000009+01:00', '2026-10-21T03:45:55.000000009Z'),
            ('2026-10-20T23:00:00.000000009-01:00', '2026-10-21T00:00:00.000000009Z'),
            ('2026-12-31T23:59:59.999999999-00:01', '2027-01-01T00:01:00Z'),
            ('2024-02-29T23:59:59.999999999Z', '2024-03-01T00:00:00Z'),
            ('0001-01-01T00:00:00.000000008+23:59', '0001-01-01T00:00:00.000000009+23:59'),
            ('9999-12-31T23:59:59.999999998-23:59', '9999-12-31T23:59:59.999999999-23:59'),
        ]
        for start, end in pairs:
            with self.subTest(start=start, end=end):
                source = envelope(start, end, [start, end])
                self.assertEqual(profile.loads_evidence(encode(source)), source)

    def test_invalid_calendar_and_unsupported_timestamp_grammar_still_reject(self):
        invalid = [
            '2026-10-21T03:45:55.0000000001Z',
            '2026-02-29T03:45:55Z',
            '2026-10-21T03:45:60Z',
            '2026-10-21 03:45:55Z',
            '2026-10-21T03:45:55',
            '2026-10-21T03:45:55+24:00',
            '2026-10-21T03:45:55+00:00:01',
        ]
        for timestamp in invalid:
            with self.subTest(timestamp=timestamp):
                with self.assertRaises(ValueError):
                    profile.loads_evidence(encode(envelope(timestamp, timestamp)))

    def test_reversed_native_envelopes_leave_existing_store_unchanged(self):
        late = '2026-10-21T03:45:55.000000009Z'
        early = '2026-10-21T03:45:55.000000008Z'
        invalid = [envelope(late, early),
                   envelope(early, late, [late, early])]
        for source in invalid:
            with self.subTest(source=source['timestamps'], events=source['events']):
                with EvidenceStore(':memory:') as store:
                    store.import_bytes((FIXTURES / 'evidence.json').read_bytes())
                    before = store.list_runs()
                    with self.assertRaises(ValueError):
                        store.import_bytes(encode(source))
                    self.assertEqual(store.list_runs(), before)

    def test_valid_native_roundtrip_preserves_nanosecond_bytes_and_trust(self):
        source = envelope('2026-10-21T04:45:55.000000008+01:00',
                          '2026-10-21T03:45:55.000000009Z')
        raw = b' \n' + encode(source) + b'\n'
        with EvidenceStore(':memory:') as store:
            record = store.import_bytes(raw)
            restored = store.get(record['raw_sha256'])
            self.assertEqual(restored['source_evidence'], source)
            self.assertEqual(base64.b64decode(restored['source_bytes']['base64']), raw)
            self.assertFalse(restored['assessment']['independently_verified'])
            self.assertEqual(restored['assessment']['evidence_status'], 'unverified')
            exported = json.loads(report(restored, 'json'))
            self.assertEqual(exported['source_evidence']['timestamps'], source['timestamps'])

    def test_reviewed_inspection_rejects_coherently_bound_reverse_chronology(self):
        late = '2026-10-21T03:45:55.000000009Z'
        early = '2026-10-21T03:45:55.000000008Z'
        valid = inspect_files(reviewed_files(envelope(early, late, [early, late])))
        self.assertFalse(valid['independently_verified'])
        for source, reason in [(envelope(late, early), 'end precedes start'),
                               (envelope(early, late, [late, early]), 'chronologically ordered')]:
            with self.subTest(reason=reason):
                with self.assertRaisesRegex(ValueError, reason):
                    inspect_files(reviewed_files(source))
