"""Real loopback probes: boundary rejection must not mutate evidence."""
import hashlib
import http.client
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest

FIXTURES = Path(__file__).resolve().parents[1] / 'fixtures'


class WebTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec('awrc.web'), 'Browser server must exist')
        from awrc.web import create_server
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.server = create_server(Path(self.temp.name) / 'runs.sqlite', 0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.stop)
        self.port = self.server.server_port
        self.origin = f'http://127.0.0.1:{self.port}'
        status, _, body = self.request('GET', '/api/bootstrap')
        self.assertEqual(status, 200)
        self.token = json.loads(body)['csrf_token']

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=3)
        try:
            conn.request(method, path, body=body, headers=headers or {})
            response = conn.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            conn.close()

    def post(self, raw, path='/api/import', headers=None):
        auth = {'Origin': self.origin, 'X-AWRC-CSRF': self.token, 'Content-Type': 'application/json'}
        auth.update(headers or {})
        return self.request('POST', path, raw, auth)

    def rows(self):
        status, _, body = self.request('GET', '/api/runs')
        self.assertEqual(status, 200)
        return json.loads(body)

    def test_native_http_import_exports_and_tamper_rejection(self):
        from awrc.arms_adapter import inspect_run
        native = inspect_run(FIXTURES / 'arms-native')
        raw = json.dumps(native).encode()
        status, _, body = self.post(raw)
        self.assertEqual(status, 200)
        record = json.loads(body)
        digest = record['raw_sha256']
        self.assertEqual(record['source_inspection'], native)
        self.assertIsNone(record['bundle']['outcome']['policy_outcome'])
        native['candidate']['passed_count'] = 0
        self.assertEqual(self.post(json.dumps(native).encode())[0], 400)
        self.assertEqual(len(self.rows()), 1)
        for format in ['json','markdown']:
            status, _, body = self.request('GET', f'/api/export/{digest}?format={format}')
            self.assertEqual(status, 200)
            self.assertIn(b'independently_verified', body)
        self.assertEqual(self.post(raw, headers={'Origin':'https://outside.invalid'})[0],403)

    def test_empty_import_duplicate_revision_detail_export_and_persistence(self):
        self.assertEqual(self.rows(), [])
        raw = (FIXTURES / 'success.json').read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        status, _, body = self.post(raw)
        self.assertEqual(status, 200)
        record = json.loads(body)
        self.assertEqual(record['raw_sha256'], digest)
        self.assertEqual(record['revision'], 1)
        self.assertFalse(record['assessment']['independently_verified'])
        self.assertEqual(self.post(raw)[0], 200)
        status, _, body = self.post(raw + b'\n')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)['revision'], 2)
        self.assertEqual(len(self.rows()), 2)
        self.assertEqual(json.loads(self.request('GET', f'/api/runs/{digest}')[2]), record)
        status, headers, body = self.request('GET', f'/api/export/{digest}?format=json')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), record)
        self.assertIn('attachment;', headers['Content-Disposition'])
        status, _, body = self.request('GET', f'/api/export/{digest}?format=markdown')
        self.assertEqual(status, 200)
        self.assertIn(b'independently_verified: false', body)
        from awrc import EvidenceStore
        with EvidenceStore(Path(self.temp.name) / 'runs.sqlite') as store:
            self.assertEqual(len(store.list_runs()), 2)

    def test_real_comparisons_show_cases_counts_and_incompatible_reason(self):
        raw = (FIXTURES / 'success.json').read_bytes()
        a = json.loads(self.post(raw)[2])['raw_sha256']
        value = json.loads(raw)
        value['checks'][0]['outcome'] = 'failed'
        b = json.loads(self.post(json.dumps(value).encode())[2])['raw_sha256']
        result = json.loads(self.request('GET', f'/api/compare?a={a}&b={b}')[2])
        self.assertTrue(result['compatible'])
        self.assertEqual(len(result['cases']), 2)
        self.assertEqual(result['counts']['b']['task'], {'passed': 0, 'failed': 1, 'unknown': 0, 'total': 1})
        value['scope_revision'] = 'different'
        c = json.loads(self.post(json.dumps(value).encode())[2])['raw_sha256']
        result = json.loads(self.request('GET', f'/api/compare?a={a}&b={c}')[2])
        self.assertFalse(result['compatible'])
        self.assertEqual(result['reason'], 'Different scope_revision')
        self.assertNotIn('counts', result)

    def test_bad_bodies_and_protocol_leave_rows_unchanged(self):
        for body, extra, status in [(b'{bad', {}, 400), (b'', {'Content-Length': '1048577'}, 413),
                                    (b'{}', {'Content-Type': 'text/plain'}, 415),
                                    (b'{}', {'Content-Encoding': 'gzip'}, 415),
                                    (b'{}', {'Transfer-Encoding': 'chunked'}, 400)]:
            with self.subTest(extra=extra, length=len(body)):
                self.assertEqual(self.post(body, headers=extra)[0], status)
        self.assertEqual(self.rows(), [])

    def test_comparison_downloads_have_exact_records_security_headers_and_no_database_mutation(self):
        from awrc import EvidenceStore
        a = json.loads(self.post((FIXTURES / 'success.json').read_bytes())[2])
        b = json.loads(self.post((FIXTURES / 'pending-approval.json').read_bytes())[2])
        path = Path(self.temp.name) / 'runs.sqlite'
        with EvidenceStore(path) as store:
            expected = store.compare(a['raw_sha256'], b['raw_sha256'])
        before = path.read_bytes()
        for format, extension, media in [('json', 'json', 'application/json'), ('markdown', 'md', 'text/markdown')]:
            url = f'/api/export-comparison?a={a["raw_sha256"]}&b={b["raw_sha256"]}&format={format}'
            status, headers, body = self.request('GET', url)
            self.assertEqual(status, 200)
            self.assertEqual(headers['Content-Type'], media + '; charset=utf-8')
            self.assertEqual(headers['Content-Disposition'], f'attachment; filename="awrc-comparison-{a["raw_sha256"]}-{b["raw_sha256"]}.{extension}"')
            self.assertEqual(int(headers['Content-Length']), len(body))
            self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')
            self.assertEqual(headers['Cache-Control'], 'no-store')
            self.assertEqual(headers['Referrer-Policy'], 'no-referrer')
            self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'])
            self.assertNotIn('Access-Control-Allow-Origin', headers)
            self.assertEqual(self.request('GET', url)[2], body)
            if format == 'json':
                report = json.loads(body)
                self.assertEqual(report['comparison'], expected)
                self.assertEqual(report['records'], {'a': a, 'b': b})
            else:
                self.assertIn(b'independently_verified: false', body)
            for headers in [{'Origin': 'https://outside.invalid'}, {'Host': 'evil.invalid'}]:
                self.assertEqual(self.request('GET', url, headers=headers)[0], 403)
            self.assertEqual(self.request('POST', url, b'{}', {'Origin': self.origin, 'X-AWRC-CSRF': self.token})[0], 404)
        self.assertEqual(path.read_bytes(), before)

    def test_comparison_export_rejects_extra_repeated_blank_invalid_and_missing_parameters(self):
        a = json.loads(self.post((FIXTURES / 'success.json').read_bytes())[2])['raw_sha256']
        valid = f'a={a}&b={a}&format=json'
        before = (Path(self.temp.name) / 'runs.sqlite').read_bytes()
        for query in ['', f'a={a}&b={a}', valid + '&extra=x', valid + '&extra=',
                      valid + f'&a={a}', valid + '&a=', valid + '&format=json',
                      f'a=&b={a}&format=json', f'a={a}&b=&format=json',
                      f'a={a}&b={a}&format=', f'a={a}&b={a}&format=html',
                      f'a=invalid&b={a}&format=json', valid + '&', valid + '&bare',
                      f'a={a}%0d%0aInjected&b={a}&format=json']:
            with self.subTest(query=query):
                status, headers, body = self.request('GET', '/api/export-comparison?' + query)
                self.assertEqual(status, 400)
                self.assertNotIn('Content-Disposition', headers)
                self.assertNotIn(b'Injected', body)
        self.assertEqual(self.request('GET', f'/api/export-comparison?a={a}&b={"f"*64}&format=json')[0], 404)
        self.assertEqual((Path(self.temp.name) / 'runs.sqlite').read_bytes(), before)

    def test_incompatible_comparison_download_keeps_reason_and_both_source_records(self):
        raw = (FIXTURES / 'success.json').read_bytes()
        a = json.loads(self.post(raw)[2])
        changed = json.loads(raw)
        changed['scope_revision'] = 'different-scope'
        b = json.loads(self.post(json.dumps(changed).encode())[2])
        path = Path(self.temp.name) / 'runs.sqlite'
        before = path.read_bytes()
        status, _, body = self.request('GET', f'/api/export-comparison?a={a["raw_sha256"]}&b={b["raw_sha256"]}&format=json')
        self.assertEqual(status, 200)
        result = json.loads(body)
        self.assertEqual(result['comparison'], {'a': a['raw_sha256'], 'b': b['raw_sha256'],
                                              'independently_verified': False, 'compatible': False, 'reason': 'Different scope_revision'})
        self.assertEqual(result['records'], {'a': a, 'b': b})
        self.assertNotIn('counts', result['comparison'])
        self.assertNotIn('cases', result['comparison'])
        self.assertEqual(path.read_bytes(), before)

    def test_comparison_export_rejects_tampered_evidence_on_either_side(self):
        from awrc import EvidenceStore
        a = json.loads(self.post((FIXTURES / 'success.json').read_bytes())[2])['raw_sha256']
        b = json.loads(self.post((FIXTURES / 'safe-denial.json').read_bytes())[2])['raw_sha256']
        path = Path(self.temp.name) / 'runs.sqlite'
        with EvidenceStore(path) as store:
            trigger = store._connection.execute("SELECT sql FROM sqlite_master WHERE name='runs_no_update'").fetchone()[0]
            store._connection.execute('DROP TRIGGER runs_no_update')
            store._connection.execute('UPDATE runs SET raw_bytes=? WHERE raw_sha256=?', (b'{}', b))
            # Preserve the normal schema; constructor setup otherwise recreates a
            # missing trigger and changes database bytes independently of export.
            store._connection.execute(trigger)
        before = path.read_bytes()
        for left, right in [(a, b), (b, a)]:
            for format in ['json', 'markdown']:
                status, headers, body = self.request('GET', f'/api/export-comparison?a={left}&b={right}&format={format}')
                self.assertEqual(status, 400)
                self.assertNotIn('Content-Disposition', headers)
                self.assertNotIn(b'raw_bytes', body)
        self.assertEqual(path.read_bytes(), before)

    def test_duplicate_and_malformed_length_headers_are_rejected_before_body(self):
        cases = [([('Content-Length', '-1')], 400),
                 ([('Content-Length', '1'), ('Content-Length', '1')], 400),
                 ([('Content-Length', '9' * 5000)], 413)]
        for extra, expected in cases:
            with self.subTest(extra=extra[:1]):
                conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=3)
                try:
                    conn.putrequest('POST', '/api/import')
                    for key, val in [('Origin', self.origin), ('X-AWRC-CSRF', self.token),
                                     ('Content-Type', 'application/json')] + extra:
                        conn.putheader(key, val)
                    conn.endheaders()
                    response = conn.getresponse()
                    self.assertEqual(response.status, expected)
                    response.read()
                finally:
                    conn.close()
        self.assertEqual(self.rows(), [])

    def test_host_origin_and_csrf_fail_closed_on_read_and_write(self):
        raw = (FIXTURES / 'success.json').read_bytes()
        for headers in [{'Host': 'localhost:' + str(self.port)}, {'Host': 'evil.invalid'},
                        {'Origin': 'https://evil.invalid'}, {'Origin': 'null'},
                        {'X-AWRC-CSRF': 'wrong'}, {'X-AWRC-CSRF': '\u00e9'}, {'X-AWRC-CSRF': ''}, {'Origin': ''}]:
            with self.subTest(headers=headers):
                self.assertEqual(self.post(raw, headers=headers)[0], 403)
        self.assertEqual(self.request('POST', '/api/import', raw, {'Content-Type':'application/json'})[0], 403)
        self.assertEqual(self.request('GET', '/api/runs', headers={'Origin':'https://evil.invalid'})[0], 403)
        self.assertEqual(self.request('GET', '/api/bootstrap', headers={'Host':'evil.invalid'})[0], 403)
        self.assertEqual(self.rows(), [])

    def test_static_allowlist_methods_and_security_headers(self):
        for path in ['/', '/static/app.js', '/static/view.js', '/static/api.js', '/static/style.css', '/static/model.mjs', '/static/icons.js',
                     '/static/radix.css', '/static/InterVariable.woff2']:
            status, headers, _ = self.request('GET', path)
            self.assertEqual(status, 200, path)
            self.assertEqual(headers['X-Content-Type-Options'], 'nosniff')
            self.assertEqual(headers['Cache-Control'], 'no-store')
            self.assertEqual(headers['Referrer-Policy'], 'no-referrer')
            self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'])
            self.assertNotIn('Access-Control-Allow-Origin', headers)
        for path in ['/../awrc/store.py', '/static/../awrc/store.py', '/static/%2e%2e/awrc/store.py',
                     '/fixtures/success.json', '/api/runs?file=/etc/passwd', '/api/bootstrap?token=1']:
            self.assertEqual(self.request('GET', path)[0], 404, path)
        for method in ['PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD']:
            self.assertEqual(self.request(method, '/api/runs')[0], 405)
        self.assertEqual(self.post(b'{}', '/api/runs')[0], 405)
        self.assertEqual(self.request('GET', '/api/import')[0], 405)
        self.assertEqual(self.request('GET', '/api/runs/' + 'f'*64)[0], 404)

    def test_explicit_fixture_import_is_idempotent_and_preserves_all_outcomes(self):
        self.assertEqual(self.rows(), [])
        self.assertEqual(self.post(b'{}', '/api/fixtures')[0], 200)
        self.assertEqual(self.post(b'{}', '/api/fixtures')[0], 200)
        rows = self.rows()
        self.assertEqual(len(rows), 4)
        self.assertTrue(all(row['bundle']['source']['synthetic'] for row in rows))
        self.assertTrue(all(row['assessment']['independently_verified'] is False for row in rows))
        self.assertEqual({r['bundle']['run_id'] for r in rows}, {'success', 'safe-denial', 'pending-approval', 'incomplete-success'})

    def test_artifact_html_is_inert_json_and_never_executes(self):
        raw = json.loads((FIXTURES / 'success.json').read_bytes())
        text = '<script>document.body.textContent="owned"</script>\n[link](https://evil.invalid)'
        raw['artifacts'][0]['text'] = text
        raw['artifacts'][0]['sha256'] = hashlib.sha256(text.encode()).hexdigest()
        record = json.loads(self.post(json.dumps(raw).encode())[2])
        digest = record['raw_sha256']
        status, headers, body = self.request('GET', f'/api/runs/{digest}')
        self.assertEqual(status, 200)
        self.assertIn('application/json', headers['Content-Type'])
        self.assertEqual(json.loads(body)['bundle']['artifacts'][0]['text'], text)
        md = self.request('GET', f'/api/export/{digest}?format=markdown')[2]
        self.assertNotIn(b'<script>', md)


if __name__ == '__main__':
    unittest.main()
