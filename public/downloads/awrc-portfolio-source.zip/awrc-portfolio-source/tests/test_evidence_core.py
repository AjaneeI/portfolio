"""Black-box contracts: data validation, durable SQLite, and operator subprocesses."""
import copy
from contextlib import closing
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parents[1]


def bundle():
    # Independent synthetic input; expectations below never call production helpers.
    text = "synthetic command completed\n"
    return {
        "schema_version": "awrc.fixture.v0.1", "workflow_id": "workflow-1",
        "run_id": "run-1", "task_id": "task-1", "scope_revision": "scope-1",
        "source": {"repository": "synthetic/example", "base_sha": "a" * 40,
                   "head_sha": "b" * 40, "tree_sha": "c" * 40, "synthetic": True},
        "configuration": {"digest": "1" * 64, "suite_digest": "2" * 64,
                          "fixture_digest": "3" * 64, "evaluation_rules_digest": "4" * 64,
                          "verifier_version": "synthetic-verifier-v1"},
        "outcome": {"execution_status": "completed", "task_success": True,
                    "policy_outcome": "allow", "claimed_verification": "verified"},
        "commands": [{"id": "cmd-1", "exit_code": 0, "artifact_ids": ["log-1"]}],
        "checks": [{"id": "case-1", "kind": "task", "outcome": "passed", "command_id": "cmd-1"},
                   {"id": "safe-1", "kind": "safety", "outcome": "passed", "command_id": "cmd-1"}],
        "artifacts": [{"id": "log-1", "sha256": hashlib.sha256(text.encode()).hexdigest(), "text": text}],
        "timing": None, "cost": {"kind": "unknown", "value": None, "currency": None},
    }


# Unsupported forms must never be silently normalized into a different instant.
INVALID_TIMESTAMPS = (
    "2026-10-21\x0017:00:00Z", "2026-10-21X17:00:00Z", "2026-10-21 17:00:00Z",
    "2026-10-21\t17:00:00Z", "2026-10-21\n17:00:00Z", "2026-10-21T17:00:00Z\n",
    "20261021T17:00:00Z", "2026-10-21T17Z", "2026-10-21T17:00Z",
    "2026-10-21T17.5Z", "2026-10-21T17:00.5Z", "2026-10-21T17:00:00,5Z",
    "2026-10-21T17:00:00+01:60", "2026-10-21T17:00:00+24:00",
    "2026-10-21T17:00:00+0100", "2026-10-21T17:00:00+01",
    "2026-10-21T17:00:00+01:00:30", "2026-10-21T17:00:00+01:00.5",
    "2026-10-21T17:00:00+01:00:00.5", "2026-10-21T17:00:00.0000001Z",
    "2026-10-21T17:00:00.1234560Z", "2026-10-21T17:00:00.Z",
    "2026-10-21T17:00:00", "2026-10-21t17:00:00z",
    "2026-02-29T17:00:00Z", "2026-10-21T24:00:00Z", "2026-10-21T17:00:60Z",
)


def raw(data=None):
    return json.dumps(bundle() if data is None else data, ensure_ascii=False).encode("utf-8")


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec("awrc"), "Evidence core package not implemented")
        from awrc import EvidenceStore, report, validate_bundle
        self.Store, self.report, self.validate = EvidenceStore, report, validate_bundle
        self.temp = tempfile.TemporaryDirectory(dir="/private/tmp")
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / "evidence.sqlite"

    def rejected(self, value):
        with self.assertRaises(ValueError):
            self.validate(value if isinstance(value, bytes) else raw(value))

    def test_valid_success_retains_values_without_independent_verification(self):
        self.assertEqual(self.validate(raw()), bundle())
        with self.Store(self.db) as store:
            record = store.import_bytes(raw())
            self.assertEqual(record["bundle"], bundle())
            self.assertEqual(record["raw_sha256"], hashlib.sha256(raw()).hexdigest())
            self.assertEqual(record["revision"], 1)
            self.assertEqual(record["assessment"]["evidence_status"], "source_reported")
            self.assertIs(record["assessment"]["independently_verified"], False)

    def test_safe_denial_and_pending_approval_are_separate_outcomes(self):
        for status, success, policy in [("failed", False, "denied"), ("pending", None, "needs_approval")]:
            with self.subTest(policy=policy), self.Store(self.db) as store:
                data = bundle()
                data["outcome"].update(execution_status=status, task_success=success, policy_outcome=policy)
                result = store.import_bytes(raw(data))
                self.assertEqual(result["bundle"]["outcome"], data["outcome"])
                self.assertFalse(result["assessment"]["independently_verified"])

    def test_wrong_schema_unknown_and_missing_fields_rejected(self):
        for mutate in [lambda d: d.update(schema_version="ev.v1"), lambda d: d.update(extra="x"),
                       lambda d: d.pop("cost"), lambda d: d["source"].update(extra=True),
                       lambda d: d["cost"].pop("value")]:
            data = bundle(); mutate(data); self.rejected(data)

    def test_duplicate_keys_rejected_at_every_depth(self):
        original = raw()
        for damaged in [b'{"schema_version":"x",' + original[1:],
                        original.replace(b'"repository":', b'"repository":"synthetic/other","repository":', 1)]:
            self.rejected(damaged)

    def test_malformed_utf8_nonfinite_and_nonbytes_rejected(self):
        for value in [b"", b"\xff", b"[]", b"null", b'{"x":',
                      raw().replace(b'"value": null', b'"value": NaN'),
                      raw().replace(b'"value": null', b'"value": Infinity'),
                      raw().replace(b'"value": null', b'"value": -Infinity')]:
            self.rejected(value)
        for value in ["{}", bytearray(raw()), None]:
            with self.assertRaises(ValueError): self.validate(value)

    def test_numeric_confusion_and_finite_overflow_rejected(self):
        for mutate in [lambda d: d["commands"][0].update(exit_code=True),
                       lambda d: d["commands"][0].update(exit_code=0.0),
                       lambda d: d["cost"].update(kind="actual", value=True, currency="USD"),
                       lambda d: d["cost"].update(kind="actual", value=-1, currency="USD")]:
            data = bundle(); mutate(data); self.rejected(data)
        self.rejected(raw().replace(b'"kind": "unknown", "value": null', b'"kind": "actual", "value": 1e999'))

    def test_ids_hashes_repository_and_types_rejected(self):
        for invalid in ["../x", "a..b", "/tmp/x", "https://example.org", "", "a" * 65, "x/y", "x\\y", "💥"]:
            data = bundle(); data["artifacts"][0]["id"] = invalid; self.rejected(data)
        for mutate in [lambda d: d["source"].update(repository="owner/../repo"),
                       lambda d: d["source"].update(repository="owner..x/repo"),
                       lambda d: d["source"].update(head_sha="B" * 40),
                       lambda d: d["configuration"].update(digest="1" * 63),
                       lambda d: d["configuration"].update(verifier_version=""),
                       lambda d: d["source"].update(synthetic=1),
                       lambda d: d["outcome"].update(task_success=1),
                       lambda d: d["outcome"].update(execution_status="ok"),
                       lambda d: d["outcome"].update(policy_outcome="approved"),
                       lambda d: d["outcome"].update(claimed_verification="independent"),
                       lambda d: d["checks"][0].update(kind="other"),
                       lambda d: d["checks"][0].update(outcome="success"),
                       lambda d: d.update(commands={}), lambda d: d.update(timing="unknown")]:
            data = bundle(); mutate(data); self.rejected(data)

    def test_wrong_artifact_hash_and_invalid_unicode_rejected(self):
        data = bundle(); data["artifacts"][0]["sha256"] = "0" * 64; self.rejected(data)
        data = bundle(); data["artifacts"][0]["text"] = "é"; self.rejected(data)
        self.rejected(raw().replace(b"synthetic-verifier-v1", b"\\ud800"))

    def test_size_depth_and_bounded_counts_rejected(self):
        self.rejected(b" " * 1048577)
        self.rejected(b"[" * 17 + b"0" + b"]" * 17)
        for name, count in [("commands", 65), ("checks", 65), ("artifacts", 17)]:
            data = bundle()
            template = data[name][0]
            data[name] = [{**template, "id": f"item-{i}"} for i in range(count)]
            # Keep references valid so only the count boundary causes rejection.
            if name == "artifacts":
                data["commands"][0]["artifact_ids"] = ["item-0"]
            if name == "commands":
                for check in data["checks"]:
                    check["command_id"] = "item-0"
            self.rejected(data)
        data = bundle(); data["artifacts"][0]["text"] = "é" * 32769
        data["artifacts"][0]["sha256"] = hashlib.sha256(data["artifacts"][0]["text"].encode()).hexdigest()
        self.rejected(data)

    def test_upper_bounds_allow_valid_artifacts_commands_and_checks(self):
        data = bundle()
        data["artifacts"] = [{"id": f"a-{i}", "text": "é" * 32768 if i == 0 else "",
                              "sha256": hashlib.sha256(("é" * 32768 if i == 0 else "").encode()).hexdigest()} for i in range(16)]
        data["commands"] = [{"id": f"c-{i}", "exit_code": 0, "artifact_ids": ["a-0"]} for i in range(64)]
        data["checks"] = [{"id": f"check-{i}", "kind": "task", "outcome": "passed", "command_id": f"c-{i}"} for i in range(64)]
        self.assertEqual(self.validate(raw(data)), data)

    def test_byte_and_verifier_text_boundaries(self):
        valid = raw()
        self.assertEqual(self.validate(valid + b" " * (1048576 - len(valid))), bundle())
        self.rejected(valid + b" " * (1048577 - len(valid)))
        data = bundle(); data["configuration"]["verifier_version"] = "é" * 128
        self.assertEqual(self.validate(raw(data)), data)
        data["configuration"]["verifier_version"] += "x"; self.rejected(data)

    def test_checked_in_fixtures_are_synthetic_and_never_independent(self):
        expected = {"success.json": ("completed", True, "allow", "source_reported"),
                    "safe-denial.json": ("failed", False, "denied", "source_reported"),
                    "pending-approval.json": ("pending", None, "needs_approval", "unverified"),
                    "incomplete-success.json": ("completed", True, "allow", "unverified")}
        self.assertTrue(all((ROOT / "fixtures" / filename).is_file() for filename in expected),
                        "Documented synthetic fixtures missing")
        with self.Store(self.db) as store:
            for filename, (status, success, policy, trust) in expected.items():
                with self.subTest(filename=filename):
                    fixture = ROOT / "fixtures" / filename
                    self.assertTrue(fixture.is_file(), "Documented synthetic fixture missing")
                    record = store.import_bytes(fixture.read_bytes())
                    self.assertTrue(record["bundle"]["source"]["synthetic"])
                    outcome = record["bundle"]["outcome"]
                    self.assertEqual((outcome["execution_status"], outcome["task_success"], outcome["policy_outcome"]),
                                     (status, success, policy))
                    self.assertEqual(record["assessment"]["evidence_status"], trust)
                    self.assertFalse(record["assessment"]["independently_verified"])
            success_record = store.import_bytes((ROOT / "fixtures" / "success.json").read_bytes())
            denial = store.import_bytes((ROOT / "fixtures" / "safe-denial.json").read_bytes())
            comparison = store.compare(success_record["raw_sha256"], denial["raw_sha256"])
            self.assertTrue(comparison["compatible"])
            self.assertEqual(comparison["counts"]["b"]["task"], {"passed": 0, "failed": 1, "unknown": 0, "total": 1})
            self.assertEqual(comparison["counts"]["b"]["safety"], {"passed": 1, "failed": 0, "unknown": 0, "total": 1})

    def test_unique_ids_and_references_enforced(self):
        for name in ["commands", "checks", "artifacts"]:
            data = bundle(); data[name].append(copy.deepcopy(data[name][0])); self.rejected(data)
        for mutate in [lambda d: d["commands"][0].update(artifact_ids=["missing"]),
                       lambda d: d["commands"][0].update(artifact_ids=["log-1", "log-1"]),
                       lambda d: d["checks"][0].update(command_id="missing")]:
            data = bundle(); mutate(data); self.rejected(data)

    def test_incomplete_or_failed_support_never_upgrades_forged_success(self):
        for mutate in [lambda d: d["commands"][0].update(exit_code=None),
                       lambda d: d["commands"][0].update(exit_code=1),
                       lambda d: d["commands"][0].update(artifact_ids=[]),
                       lambda d: d.update(commands=[], checks=[])]:
            data = bundle(); mutate(data)
            with self.Store(self.db) as store:
                record = store.import_bytes(raw(data))
                self.assertEqual(record["assessment"]["evidence_status"], "unverified")
                self.assertFalse(record["assessment"]["independently_verified"])
                self.assertTrue(record["bundle"]["outcome"]["task_success"])
                self.assertEqual(record["bundle"]["outcome"]["claimed_verification"], "verified")

    def test_timing_unknown_cost_and_timezone_rules(self):
        for timing in [None, {"started_at": "2026-10-21T13:00:00-04:00", "ended_at": "2026-10-21T17:00:00+00:00"}]:
            data = bundle(); data["timing"] = timing
            self.assertEqual(self.validate(raw(data))["timing"], timing)
        for timing in [{"started_at": "2026-10-21T18:00:00Z", "ended_at": "2026-10-21T17:00:00Z"},
                       {"started_at": "2026-10-21T17:00:00", "ended_at": "2026-10-21T17:00:00Z"},
                       {"started_at": "yesterday", "ended_at": "today"}]:
            data = bundle(); data["timing"] = timing; self.rejected(data)
        for cost in [{"kind": "unknown", "value": 0, "currency": "USD"},
                     {"kind": "actual", "value": None, "currency": "USD"},
                     {"kind": "estimated", "value": 1, "currency": "usd"}]:
            data = bundle(); data["cost"] = cost; self.rejected(data)
        for kind in ["actual", "estimated"]:
            data = bundle(); data["cost"] = {"kind": kind, "value": 0, "currency": "USD"}
            self.assertEqual(self.validate(raw(data))["cost"], data["cost"])

    def test_timestamp_dialect_rejects_unsupported_forms_before_persistence(self):
        for stamp in INVALID_TIMESTAMPS:
            with self.subTest(stamp=repr(stamp)):
                data = bundle(); data["timing"] = {"started_at": stamp, "ended_at": stamp}
                self.rejected(data)
                with self.Store(":memory:") as store:
                    with self.assertRaises(ValueError): store.import_bytes(raw(data))
                    self.assertEqual(store.list_runs(), [])

    def test_extended_timestamps_preserve_supported_precision_and_offset_instants(self):
        examples = [
            ("2026-10-21T17:00:00Z", "2026-10-21T17:00:00+00:00"),
            ("2026-10-21T17:00:00.1Z", "2026-10-21T13:00:00.100000-04:00"),
            ("2026-10-21T17:00:00.123456Z", "2026-10-21T18:00:00.123456+01:00"),
            ("2026-10-21T00:00:00+23:59", "2026-10-21T00:00:00-23:59"),
            ("2026-10-21T17:00:00.000000Z", "2026-10-21T17:00:00.000001Z"),
        ]
        for started, ended in examples:
            with self.subTest(started=started, ended=ended):
                data = bundle(); data["timing"] = {"started_at": started, "ended_at": ended}
                self.assertEqual(self.validate(raw(data))["timing"], data["timing"])
                with self.Store(":memory:") as store:
                    record = store.import_bytes(raw(data))
                    self.assertEqual(store.get(record["raw_sha256"])["bundle"]["timing"], data["timing"])
        data = bundle()
        data["timing"] = {"started_at": "2026-10-21T17:00:00.000001Z",
                          "ended_at": "2026-10-21T17:00:00.000000Z"}
        self.rejected(data)
        data["timing"] = {"started_at": "2026-10-21T17:00:00.1+00:00",
                          "ended_at": "2026-10-21T17:00:00.1+01:00"}
        self.rejected(data)

    def test_raw_idempotency_revisions_and_reopen(self):
        first = raw(); changed = first + b"\n"
        with self.Store(self.db) as store:
            a = store.import_bytes(first); again = store.import_bytes(first); b = store.import_bytes(changed)
            self.assertEqual(a, again)
            self.assertEqual(b["revision"], 2)
            self.assertNotEqual(a["raw_sha256"], b["raw_sha256"])
            a["bundle"]["outcome"]["task_success"] = False
            self.assertTrue(store.get(again["raw_sha256"])["bundle"]["outcome"]["task_success"])
        with self.Store(self.db) as store:
            self.assertEqual([r["revision"] for r in store.list_runs()], [1, 2])
            self.assertEqual(store.get(b["raw_sha256"]), b)
            with self.assertRaises(ValueError): store.get("../file")
            with self.assertRaises(KeyError): store.get("0" * 64)
        # Inspect actual SQLite persistence, rather than a mocked repository.
        with closing(sqlite3.connect(self.db)) as connection:
            rows = connection.execute("SELECT raw_bytes FROM runs ORDER BY revision").fetchall()
            self.assertEqual(rows, [(first,), (changed,)])
            with self.assertRaises(sqlite3.IntegrityError):
                connection.execute("UPDATE runs SET raw_bytes = ? WHERE revision = 1", (changed,))
            with self.assertRaises(sqlite3.IntegrityError): connection.execute("DELETE FROM runs")

    def test_concurrent_imports_are_transactional(self):
        with self.Store(self.db): pass
        values = [raw(), raw(), raw() + b"\n", raw() + b"\n\n"] * 3
        def insert(value):
            with self.Store(self.db) as store: return store.import_bytes(value)
        with ThreadPoolExecutor(max_workers=4) as pool: results = list(pool.map(insert, values))
        with self.Store(self.db) as store:
            rows = store.list_runs()
            self.assertEqual(len(rows), 3)
            self.assertEqual(sorted(r["revision"] for r in rows), [1, 2, 3])
            for value in set(values):
                matching = [r for r in results if r["raw_sha256"] == hashlib.sha256(value).hexdigest()]
                self.assertTrue(all(r == matching[0] for r in matching))

    def test_invalid_import_has_no_rows_or_revisions(self):
        with self.Store(self.db) as store:
            with self.assertRaises(ValueError): store.import_bytes(b'{"secret":"DO_NOT_ECHO"}')
            self.assertEqual(store.list_runs(), [])
            self.assertEqual(store.import_bytes(raw())["revision"], 1)

    def test_compatible_comparison_retains_every_case_and_kind_counts(self):
        a = bundle(); b = bundle()
        a["checks"].append({"id": "case-2", "kind": "task", "outcome": "failed", "command_id": "cmd-1"})
        b["checks"].append({"id": "case-2", "kind": "task", "outcome": "unknown", "command_id": "cmd-1"})
        b["checks"][0]["outcome"] = "failed"
        b["checks"].reverse(); b["source"]["head_sha"] = "d" * 40
        b["outcome"].update(task_success=False, policy_outcome="denied")
        with self.Store(self.db) as store:
            ra = store.import_bytes(raw(a)); rb = store.import_bytes(raw(b))
            comparison = store.compare(ra["raw_sha256"], rb["raw_sha256"])
        self.assertTrue(comparison["compatible"])
        self.assertEqual(comparison["counts"]["a"]["task"], {"passed": 1, "failed": 1, "unknown": 0, "total": 2})
        self.assertEqual(comparison["counts"]["b"]["task"], {"passed": 0, "failed": 1, "unknown": 1, "total": 2})
        self.assertEqual(comparison["counts"]["a"]["safety"], {"passed": 1, "failed": 0, "unknown": 0, "total": 1})
        self.assertEqual({(c["id"], c["kind"], c["a"], c["b"]) for c in comparison["cases"]},
                         {("case-1", "task", "passed", "failed"), ("case-2", "task", "failed", "unknown"), ("safe-1", "safety", "passed", "passed")})
        self.assertEqual(comparison["outcomes"]["b"]["policy_outcome"], "denied")
        self.assertNotIn("score", comparison)

    def test_incompatible_comparison_returns_reason_without_improvement(self):
        mutations = [lambda d: d.update(workflow_id="other"), lambda d: d.update(task_id="other"),
                     lambda d: d.update(scope_revision="other"), lambda d: d["configuration"].update(digest="9" * 64),
                     lambda d: d["configuration"].update(suite_digest="9" * 64),
                     lambda d: d["configuration"].update(fixture_digest="9" * 64),
                     lambda d: d["configuration"].update(evaluation_rules_digest="9" * 64),
                     lambda d: d["configuration"].update(verifier_version="other"),
                     lambda d: d["checks"].pop(), lambda d: d["checks"][0].update(kind="safety")]
        with self.Store(self.db) as store:
            a = store.import_bytes(raw())
            for mutate in mutations:
                data = bundle(); mutate(data); b = store.import_bytes(raw(data))
                result = store.compare(a["raw_sha256"], b["raw_sha256"])
                self.assertFalse(result["compatible"])
                self.assertTrue(result["reason"])
                self.assertNotIn("counts", result)
                self.assertNotIn("cases", result)
                self.assertNotIn("improvement", result)

    def test_json_export_equals_inspection_and_unknowns_remain_unknown(self):
        with self.Store(self.db) as store:
            record = store.import_bytes(raw())
            exported = json.loads(self.report(record, "json"))
            self.assertEqual(exported, store.get(record["raw_sha256"]))
            self.assertIsNone(exported["bundle"]["timing"])
            self.assertIsNone(exported["bundle"]["cost"]["value"])
            self.assertIsNone(exported["bundle"]["cost"]["currency"])
            with self.assertRaises(ValueError): self.report(record, "html")

    def test_markdown_export_neutralizes_imported_html_and_markdown(self):
        hostile = '<script>alert(1)</script> [go](https://evil.example) <https://evil.example> ![x](file:///x) `code`\n# title | cell'
        data = bundle(); data["configuration"]["verifier_version"] = hostile
        data["artifacts"][0].update(text=hostile, sha256=hashlib.sha256(hostile.encode()).hexdigest())
        with self.Store(self.db) as store:
            record = store.import_bytes(raw(data)); rendered = self.report(record, "markdown")
        for active in ["<script>", "[go](https://", "<https://", "![x](file://", "`code`", "\n# title"]:
            self.assertNotIn(active, rendered)
        self.assertIn("independently_verified", rendered)
        self.assertIn("false", rendered)
        self.assertIn("unknown", rendered)
        self.assertEqual(json.loads(self.report(record, "json"))["bundle"]["artifacts"][0]["text"], hostile)


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir="/private/tmp")
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.db = self.directory / "evidence.sqlite"
        self.input = self.directory / "fixture.json"; self.input.write_bytes(raw())

    def cli(self, *arguments):
        return subprocess.run([sys.executable, "-m", "awrc", "--db", str(self.db), *map(str, arguments)],
                              cwd=ROOT, capture_output=True, text=True, timeout=5)

    def test_fresh_process_import_list_show_compare_export_lifecycle(self):
        imported = self.cli("import", self.input)
        self.assertEqual(imported.returncode, 0, imported.stderr)
        record = json.loads(imported.stdout); digest = record["raw_sha256"]
        self.assertEqual(json.loads(self.cli("list").stdout), [record])
        shown = self.cli("show", digest); self.assertEqual(shown.returncode, 0, shown.stderr)
        self.assertEqual(json.loads(shown.stdout), record)
        exported = self.cli("export", digest, "--format", "json")
        self.assertEqual(exported.returncode, 0, exported.stderr)
        self.assertEqual(json.loads(exported.stdout), record)
        md = self.cli("export", digest, "--format", "markdown")
        self.assertEqual(md.returncode, 0, md.stderr)
        self.assertIn("independently_verified", md.stdout)
        compared = self.cli("compare", digest, digest)
        self.assertEqual(compared.returncode, 0, compared.stderr)
        self.assertTrue(json.loads(compared.stdout)["compatible"])

    def test_invalid_import_creates_no_database_and_does_not_echo_payload(self):
        self.input.write_bytes(b'{"secret":"DO_NOT_ECHO"}')
        result = self.cli("import", self.input)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("DO_NOT_ECHO", result.stdout + result.stderr)
        self.assertNotIn("Traceback", result.stderr)
        self.assertFalse(self.db.exists())

    def test_invalid_timestamp_import_creates_no_database_file(self):
        for index, stamp in enumerate(INVALID_TIMESTAMPS):
            with self.subTest(stamp=repr(stamp)):
                self.db = self.directory / f"bad-timestamp-{index}.sqlite"
                data = bundle(); data["timing"] = {"started_at": stamp, "ended_at": stamp}
                self.input.write_bytes(raw(data))
                result = self.cli("import", self.input)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn("Traceback", result.stderr)
                self.assertFalse(self.db.exists())

    def test_invalid_import_does_not_change_existing_database(self):
        first = self.cli("import", self.input); self.assertEqual(first.returncode, 0, first.stderr)
        before = self.db.read_bytes()
        self.input.write_bytes(b'{}')
        result = self.cli("import", self.input)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(len(json.loads(self.cli("list").stdout)), 1)

    def test_file_and_parent_symlinks_and_nonregular_inputs_rejected(self):
        link = self.directory / "linked.json"; link.symlink_to(self.input)
        parent = self.directory / "linked-parent"; parent.symlink_to(self.directory, target_is_directory=True)
        fifo = self.directory / "pipe"; os.mkfifo(fifo)
        for filename in [link, parent / self.input.name, parent / ".." / self.directory.name / self.input.name, self.directory, fifo, Path("/dev/null")]:
            with self.subTest(filename=filename.name):
                result = self.cli("import", filename)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn("Traceback", result.stderr)
                self.assertFalse(self.db.exists())

    def test_unknown_digest_and_oversized_file_have_concise_errors(self):
        result = self.cli("show", "0" * 64)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("Traceback", result.stderr)
        self.input.write_bytes(b" " * 1048577)
        result = self.cli("import", self.input)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
