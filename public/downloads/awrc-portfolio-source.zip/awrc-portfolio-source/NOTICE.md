# Project notice

AWRC is a local evidence inspection application. No project-wide application license has been selected in this package, and preparation of this archive does not add a new license grant. Existing third-party asset notices apply to their named assets and remain included in full. The original application and included fixture evidence bytes are unchanged; README/provenance material describes this curated export.
