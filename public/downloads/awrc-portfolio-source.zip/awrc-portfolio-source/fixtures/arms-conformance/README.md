# Preserved conformance data

The current manifest contains 44 finite synthetic reader/import cases. Historical manifest revisions 1 and 2, all golden files, the oracle, and original expected vector labels are retained unchanged. Current revision 3 pins the consumer chronology derivative and its provenance receipt. The tests interpret mutation recipes as data; they do not execute ARMS or arbitrary expressions. A passing corpus does not establish general interoperability or authenticate imported evidence.

Run `python3 -m unittest discover -s tests -p test_arms_conformance.py -v` from the archive root. Runtime and full-suite platform qualifications are in the root README and public verification summary.
