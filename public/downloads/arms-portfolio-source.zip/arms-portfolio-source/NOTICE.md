# Project notice

ARMS is a supervised offline maintenance prototype. The original source snapshot supplied no project-wide license file; this archive does not change licensing or add a new license grant. No third-party Python packages are bundled. Python and Git are separately installed prerequisites. Included historical review aliases are provenance strings, not filesystem paths or authenticated identities. The fixture@example.invalid address in synthetic Git objects is deliberately non-routable test data.
