# Autonomous Repository Maintenance System (ARMS)

**Supervised offline maintenance workbench — source snapshot, October 28, 2026.**

ARMS admits one bounded synthetic repair task, verifies the proposed change against protected checks, preserves refusal and failure outcomes, and records review separately from passing tests. The demonstration repairs a retry-delay function that doubles one attempt too early.

## Run locally

Use existing Python 3.12+ and Git installations. No dependencies, credentials, model download or network service are needed. Extract into a physical local directory and run:

```sh
mkdir -p physical-temp
TMPDIR="$PWD/physical-temp" python3 -m unittest discover -s tests -v
python3 -m arms demo --workspace ./fresh-demo
python3 -m arms run --workspace ./fresh-native --task examples/native-task.json --candidate examples/native-candidate.json
```

Use fresh output directories. On macOS, a temporary path traversing a symlink can be refused; the physical temporary directory above makes that setup choice explicit. The included JSON candidate was supplied by a separate coding worker during the historical supervised build. Replaying it does not launch a new model.

Use the run ID printed by the last command:

```sh
python3 -m arms inspect --workspace ./fresh-native --run-id RUN_ID
```

A fresh successful verification deliberately remains `task_success=false` and `awaiting_independent_review`. The historical review cannot approve a new run.

## What was observed

Fresh October 28 validation passed **101 tests** and exercised **11 demonstration scenarios**. The single retry-delay defect had **6/18 passing baseline cases**, followed by **18/18 passing candidate cases**. These are finite cases for one defect, not 18 repaired bugs or a general coding benchmark. The demonstrations include eligible repair, no-op, failed repair with rollback, hostile source, forbidden path, forged approval, untrusted instructions, missing candidate, duplicate delivery, wrong repository and base drift.

The exact original reviewed run is preserved under `verification/historical-reviewed-run`. The new October 28 supplied-proposal replay is under `verification/fresh-unreviewed-replay` and remains pending review. Raw evidence has not been rewritten. The archive omits Git metadata; historical files can be inspected as data, while a new demo creates the synthetic Git objects needed for live local inspection.

## Boundaries and known limitation

Only the fixed synthetic repository and one restricted arithmetic function are supported. Candidate Python is parsed and interpreted as permitted arithmetic; it is never executed as arbitrary Python. The system does not provide an OS sandbox, general repository scanner, autonomous model launcher, live PR publisher or unattended maintenance service. Its deadline is checked between stages, not a hard process-kill guarantee. Human effort and model cost are unmeasured.

Generated timestamps have six fractional digits. The unchanged broader imported-evidence validator accepts up to nine digits but compares at microsecond precision; a submicrosecond reversal can pass. The current work sample is scoped to its producer-generated microsecond records. The separate AWRC consumer repair does not silently change this original producer snapshot.

See `verification/arms-verification.json`, `PROVENANCE.json`, and `PUBLICATION-MANIFEST.json` for exact source identity, recorded checks and raw-file hashes. This source snapshot contains unchanged product code and included evidence, with documentation prepared for this exported layout. Its validation covers the supervised offline fixture; it does not establish a live repository pilot or deployed maintenance service. No project-wide license grant is added; see `NOTICE.md`.
