"""ARMS offline workbench: bounded repairs with inspectable evidence."""

__version__ = "0.1.0"
