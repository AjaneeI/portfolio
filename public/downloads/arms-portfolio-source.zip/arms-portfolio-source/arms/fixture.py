"""Protected reference checks for a deliberately narrow synthetic Python fixture.

Candidate source is data: it is parsed with ``ast.parse`` and never executed,
imported, compiled into runnable code, or passed to ``eval``. Only one pure
arithmetic function is supported. This interpreter is a fixture boundary, not
an operating-system sandbox or a verifier for arbitrary Python repositories.

The fixture's domain is zero-based retry attempts 0 through 5 with non-negative
base delays. Passing these finite examples does not prove correctness outside
the declared domain, nor prove the quality of a general coding agent.
"""

from __future__ import annotations

import ast
import hashlib
import json
import math


FIXTURE_ID = "retry-backoff-v1"
SOURCE_PATH = "retry.py"
VERIFIER_VERSION = "arms-restricted-python/0.1"

BROKEN_SOURCE = (
    "def retry_delay(attempt, base_delay):\n"
    "    return base_delay * (2 ** (attempt + 1))\n"
)
FIXED_SOURCE = (
    "def retry_delay(attempt, base_delay):\n"
    "    return base_delay * (2 ** attempt)\n"
)

MAX_SOURCE_BYTES = 4096
MAX_AST_NODES = 128
MAX_AST_DEPTH = 24
MAX_LITERAL_MAGNITUDE = 1_000_000
MAX_INTERMEDIATE_MAGNITUDE = 1_000_000_000_000
MAX_EXPONENT = 32
_NAMES = frozenset({"attempt", "base_delay"})
_CASES = tuple(
    (f"retry-a{attempt}-{label}", attempt, base_delay, base_delay * (2 ** attempt))
    for attempt in (0, 1, 2, 3, 4, 5)
    for label, base_delay in (("zero", 0), ("half", 0.5), ("two", 2))
)
_SUITE_DEFINITION = {
    "fixture_id": FIXTURE_ID,
    "verifier_version": VERIFIER_VERSION,
    "meaning": "attempt is zero-based; delay = base_delay * (2 ** attempt)",
    "cases": _CASES,
    "comparison": "exact numeric equality",
    "limits": {
        "source_bytes": MAX_SOURCE_BYTES,
        "ast_nodes": MAX_AST_NODES,
        "ast_depth": MAX_AST_DEPTH,
        "literal_magnitude": MAX_LITERAL_MAGNITUDE,
        "intermediate_magnitude": MAX_INTERMEDIATE_MAGNITUDE,
        "max_integer_exponent": MAX_EXPONENT,
    },
}
SUITE_DIGEST = hashlib.sha256(
    json.dumps(
        _SUITE_DEFINITION, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
).hexdigest()


class UnsafeSource(ValueError):
    """A stable reason identifies source outside the permitted fixture language."""


def _number(value: object, *, literal: bool = False) -> int | float:
    # bool is deliberately excluded despite being an int subclass.
    if type(value) not in (int, float):
        raise UnsafeSource("numeric_type")
    limit = MAX_LITERAL_MAGNITUDE if literal else MAX_INTERMEDIATE_MAGNITUDE
    if abs(value) > limit or (type(value) is float and not math.isfinite(value)):
        raise UnsafeSource("literal_budget" if literal else "arithmetic_budget")
    return value


def _validate_source(source: str) -> ast.expr:
    if type(source) is not str:
        raise UnsafeSource("source_type")
    # Every Unicode code point needs at least one UTF-8 byte. Reject a large
    # string before allocating a second, encoded copy of it.
    if len(source) > MAX_SOURCE_BYTES:
        raise UnsafeSource("source_budget")
    try:
        source_bytes = source.encode("utf-8")
    except UnicodeError as exc:
        raise UnsafeSource("source_encoding") from exc
    if len(source_bytes) > MAX_SOURCE_BYTES:
        raise UnsafeSource("source_budget")
    try:
        tree = ast.parse(source, mode="exec", type_comments=True)
    except (SyntaxError, ValueError, RecursionError) as exc:
        raise UnsafeSource("source_syntax") from exc

    if len(tree.body) != 1 or type(tree.body[0]) is not ast.FunctionDef:
        raise UnsafeSource("module_shape")
    function = tree.body[0]
    if (
        function.name != "retry_delay"
        or function.decorator_list
        or function.returns is not None
        or function.type_comment is not None
        or getattr(function, "type_params", [])
        or tree.type_ignores
    ):
        raise UnsafeSource("function_shape")
    arguments = function.args
    if (
        arguments.posonlyargs
        or [arg.arg for arg in arguments.args] != ["attempt", "base_delay"]
        or arguments.vararg is not None
        or arguments.kwarg is not None
        or arguments.kwonlyargs
        or arguments.kw_defaults
        or arguments.defaults
        or any(arg.annotation is not None or arg.type_comment is not None
               for arg in arguments.args)
    ):
        raise UnsafeSource("argument_shape")
    if (
        len(function.body) != 1
        or type(function.body[0]) is not ast.Return
        or function.body[0].value is None
    ):
        raise UnsafeSource("body_shape")

    # Validate the *entire* parsed tree before the first protected case runs.
    # Iterative traversal avoids a validator stack overflow on nested input.
    allowed = {
        ast.Module, ast.FunctionDef, ast.arguments, ast.arg, ast.Return,
        ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow,
        ast.UnaryOp, ast.UAdd, ast.USub, ast.Name, ast.Load, ast.Constant,
    }
    stack = [(tree, 1)]
    count = 0
    while stack:
        node, depth = stack.pop()
        count += 1
        if count > MAX_AST_NODES:
            raise UnsafeSource("ast_node_budget")
        if depth > MAX_AST_DEPTH:
            raise UnsafeSource("ast_depth_budget")
        if type(node) not in allowed:
            raise UnsafeSource("unsupported_syntax")
        if type(node) is ast.Name and node.id not in _NAMES:
            raise UnsafeSource("unknown_name")
        if type(node) is ast.Constant:
            _number(node.value, literal=True)
        stack.extend((child, depth + 1) for child in ast.iter_child_nodes(node))
    return function.body[0].value


def _interpret(expression: ast.expr, values: dict[str, int | float]) -> int | float:
    if type(expression) is ast.Constant:
        return _number(expression.value, literal=True)
    if type(expression) is ast.Name:
        return values[expression.id]
    if type(expression) is ast.UnaryOp:
        operand = _interpret(expression.operand, values)
        return _number(operand if type(expression.op) is ast.UAdd else -operand)

    # _validate_source has already checked every node and operator.
    if type(expression) is not ast.BinOp:
        raise UnsafeSource("unsupported_syntax")
    left = _interpret(expression.left, values)
    right = _interpret(expression.right, values)
    operation = type(expression.op)
    if operation is ast.Add:
        result = left + right
    elif operation is ast.Sub:
        result = left - right
    elif operation is ast.Mult:
        result = left * right
    elif operation is ast.Div:
        result = left / right
    elif operation is ast.Pow:
        # Check before exponentiation, including nested and computed exponents.
        if not (0 <= right <= MAX_EXPONENT) or int(right) != right:
            raise UnsafeSource("exponent_budget")
        # Bounded operands/exponents keep even rejected intermediate work small.
        result = left ** int(right)
    else:
        raise UnsafeSource("unsupported_syntax")
    return _number(result)


def verify_source(source: str) -> dict:
    """Return finite protected-case observations, or refuse unsupported source.

    Arithmetic domain errors such as division by zero are failed observations.
    Language/complexity budget violations raise ``UnsafeSource`` and cannot be
    treated as a successful verification. No candidate-derived text is logged.
    """
    expression = _validate_source(source)
    checks = []
    for case_id, attempt, base_delay, expected in _CASES:
        try:
            actual = _interpret(
                expression, {"attempt": attempt, "base_delay": base_delay}
            )
            passed = actual == expected
        except ZeroDivisionError:
            actual = {"error": "division_by_zero"}
            passed = False
        except OverflowError:
            actual = {"error": "arithmetic_overflow"}
            passed = False
        checks.append({
            "id": case_id, "passed": passed, "expected": expected, "actual": actual
        })
    return {
        "passed": all(check["passed"] for check in checks),
        "checks": checks,
        "verifier_version": VERIFIER_VERSION,
        "suite_digest": SUITE_DIGEST,
    }


def make_fixture_candidate(source: str) -> str:
    """Deterministic demo baseline, not a general or model-backed coding worker."""
    if type(source) is not str or source != BROKEN_SOURCE:
        raise ValueError("fixture_source_not_recognized")
    return FIXED_SOURCE
