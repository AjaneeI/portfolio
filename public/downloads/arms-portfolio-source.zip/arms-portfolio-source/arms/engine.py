"""One admitted synthetic repair, bounded data intake, and immutable run evidence.

No model, network request, user-provided command, or submitted Python is run.
Only the trusted, fixed Git read-tree command is invoked on a newly created
fixture repository. This module does not operate on arbitrary checkouts.
"""

from __future__ import annotations

from datetime import datetime, timezone
import difflib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid
import zlib

from . import contracts
from .contracts import (BASE_SHA, BUILDER, LIMITS, MAX_CHANGED_LINES, POLICY_DIGEST,
                        PolicyError, canonical, candidate_for, default_task, git_hash,
                        sha256, source_identity, task_key, validate_candidate, validate_task)
from .evidence import artifact_record, loads_evidence, validate_evidence, verify_artifacts
from .fixture import (BROKEN_SOURCE, FIXTURE_ID, SOURCE_PATH, SUITE_DIGEST,
                      VERIFIER_VERSION, UnsafeSource, make_fixture_candidate, verify_source)
from .storage import atomic_write, ensure_root, finish, no_symlinks, regular_bytes, reserve

ARTIFACT_FILES = {
    "baseline_checks": "baseline-checks.json",
    "candidate_checks": "candidate-checks.json",
    "patch": "repair.patch",
    "journal": "journal.json",
    "source_hashes": "source-hashes.json",
}
LIMITATIONS = [
    "Synthetic retry fixture only; no private repository repair or pull request was performed.",
    "Submitted Python is interpreted as a restricted arithmetic AST, never executed as Python.",
    "No OS sandbox or defense against an attacker controlling the host account is claimed.",
    "The 30-second deadline is checked between bounded stages, not a hard process kill guarantee.",
    "Task identity deduplication is local to this state directory; there is no distributed exactly-once guarantee.",
    "Content hashes establish consistency, not trusted authorship or cryptographic reviewer identity.",
    "Model cost and human hands-on time were not measured; null values are unknown.",
]


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def host_digest() -> str:
    directory = Path(__file__).parent
    return sha256(canonical({name: sha256(regular_bytes(directory / name)) for name in
                            ("contracts.py", "engine.py", "evidence.py", "fixture.py", "storage.py")}))


def _object(repo: Path, kind: str, payload: bytes) -> str:
    object_id = git_hash(kind, payload)
    destination = repo / ".git" / "objects" / object_id[:2] / object_id[2:]
    destination.parent.mkdir(exist_ok=True)
    data = zlib.compress(f"{kind} {len(payload)}\0".encode("ascii") + payload)
    if destination.exists():
        if regular_bytes(destination) != data:
            raise PolicyError("git_object_drift")
    else:
        atomic_write(destination, data)
    return object_id


def _record_commit(repo: Path, source: str, parent: str | None = None) -> tuple[str, str]:
    expected, tree, blob, commit_payload = source_identity(source, parent)
    _object(repo, "blob", source.encode("utf-8"))
    _object(repo, "tree", f"100644 {SOURCE_PATH}\0".encode("ascii") + bytes.fromhex(blob))
    actual = _object(repo, "commit", commit_payload)
    if actual != expected:
        raise PolicyError("git_identity_mismatch")
    atomic_write(repo / ".git" / "refs" / "heads" / "fixture", (actual + "\n").encode("ascii"))
    git_executable = shutil.which("git")
    if git_executable is None:
        raise RuntimeError("git_not_available")
    environment = {"PATH": os.environ.get("PATH", os.defpath), "GIT_CONFIG_NOSYSTEM": "1",
                   "GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_SYSTEM": os.devnull,
                   "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"}
    result = subprocess.run(
        [git_executable, "-c", "core.hooksPath=" + os.devnull, "-c", "core.fsmonitor=false",
         "read-tree", "--reset", "HEAD"], cwd=repo, env=environment,
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=5, check=False,
    )
    if result.returncode:
        raise RuntimeError("git_index_failed")
    return actual, tree


def _create_repo(repo: Path) -> tuple[str, str]:
    no_symlinks(repo)
    repo.mkdir(exist_ok=False)
    for directory in (".git/objects", ".git/refs/heads"):
        (repo / directory).mkdir(parents=True)
    atomic_write(repo / ".git" / "HEAD", b"ref: refs/heads/fixture\n")
    atomic_write(repo / ".git" / "config", b"[core]\n\trepositoryformatversion = 0\n\tbare = false\n\tfilemode = true\n\tlogallrefupdates = false\n")
    atomic_write(repo / SOURCE_PATH, BROKEN_SOURCE.encode())
    return _record_commit(repo, BROKEN_SOURCE)


def _deadline(started: float) -> None:
    if time.monotonic() - started > LIMITS["timeout_seconds"]:
        raise TimeoutError("deadline_exceeded")


def _lf_lines(source: str) -> list[str]:
    # Git's unified diff counts LF bytes. str.splitlines() also recognizes
    # Unicode separators inside Python comments and can produce corrupt hunks.
    return [line + "\n" for line in source.split("\n")[:-1]]


def _restore_if_unchanged(target: Path, expected: bytes, original: bytes) -> bool:
    try:
        if regular_bytes(target, 8192) != expected:
            return False
        atomic_write(target, original)
        return regular_bytes(target, 8192) == original
    except (OSError, PolicyError):
        return False


def _run_paths(root: Path, run_id: str) -> tuple[Path, Path]:
    try:
        if str(uuid.UUID(run_id)) != run_id:
            raise ValueError
    except (ValueError, AttributeError, TypeError) as exc:
        raise PolicyError("invalid_run_id") from exc
    run_dir, repo = root / "runs" / run_id, root / "workspaces" / run_id
    no_symlinks(run_dir)
    no_symlinks(repo)
    return run_dir, repo


def inspect_run(root: Path, run_id: str) -> dict:
    """Validate evidence, artifacts, current source and recorded Git objects."""
    root = ensure_root(root)
    run_dir, repo = _run_paths(root, run_id)
    bundle = loads_evidence(regular_bytes(run_dir / "evidence.json"))
    if bundle["run_id"] != run_id:
        raise PolicyError("run_identity_mismatch")
    reconstructed_task = {**bundle["task"], "base_sha": bundle["source"]["base_sha"], "instruction": ""}
    if task_key(reconstructed_task) != bundle["task_key"]:
        raise PolicyError("task_identity_mismatch")
    if (bundle["configuration"]["digest"] != POLICY_DIGEST
            or bundle["configuration"]["suite_digest"] != SUITE_DIGEST
            or bundle["configuration"]["verifier_version"] != VERIFIER_VERSION):
        raise PolicyError("configuration_drift")
    artifacts = {}
    for item in bundle["artifacts"]:
        if item["id"] not in ARTIFACT_FILES:
            raise PolicyError("unknown_artifact")
        artifacts[item["id"]] = regular_bytes(run_dir / ARTIFACT_FILES[item["id"]])
    verify_artifacts(bundle, artifacts)
    if bundle["source"]["head_sha"] is not None:
        source = regular_bytes(repo / SOURCE_PATH, 8192).decode("utf-8")
        head = bundle["source"]["head_sha"]
        parent = None if head == BASE_SHA else BASE_SHA
        actual_head, actual_tree, actual_blob, commit_payload = source_identity(source, parent)
        if (head, bundle["source"]["tree_sha"]) != (actual_head, actual_tree):
            raise PolicyError("source_drift")
        ref = regular_bytes(repo / ".git" / "refs" / "heads" / "fixture").decode("ascii").strip()
        if ref != head:
            raise PolicyError("head_drift")
        base_commit, base_tree, base_blob, base_payload = source_identity(BROKEN_SOURCE)
        expected_objects = {
            base_commit: ("commit", base_payload),
            base_tree: ("tree", f"100644 {SOURCE_PATH}\0".encode("ascii") + bytes.fromhex(base_blob)),
            base_blob: ("blob", BROKEN_SOURCE.encode()),
            head: ("commit", commit_payload),
            actual_tree: ("tree", f"100644 {SOURCE_PATH}\0".encode("ascii") + bytes.fromhex(actual_blob)),
            actual_blob: ("blob", source.encode()),
        }
        for object_id, (kind, payload) in expected_objects.items():
            expected_object = f"{kind} {len(payload)}\0".encode("ascii") + payload
            try:
                compressed = regular_bytes(repo / ".git" / "objects" / object_id[:2] / object_id[2:])
                decoder = zlib.decompressobj()
                raw = decoder.decompress(compressed, len(expected_object) + 1)
            except (zlib.error, OSError) as exc:
                raise PolicyError("git_object_corrupt") from exc
            if raw != expected_object or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
                raise PolicyError("git_object_corrupt")
        if bundle["outcome"]["verification"] == "verified":
            checked = verify_source(source)
            if not checked["passed"] or head == BASE_SHA or canonical(checked) != artifacts.get("candidate_checks"):
                raise PolicyError("verification_proof_mismatch")
    return bundle


def run_task(root: Path, task: dict, candidate: dict | None = None, *, adapter: str = "fixture-baseline") -> dict:
    """Run one attempt. A duplicate never starts another repair attempt."""
    validate_task(task)
    if adapter not in ("fixture-baseline", "native-json"):
        raise PolicyError("unsupported_adapter")
    if adapter == "fixture-baseline" and candidate is not None:
        raise PolicyError("baseline_cannot_accept_external_candidate")
    root = ensure_root(root)
    key = task_key(task)
    run_id = str(uuid.uuid4())
    existing = reserve(root, key, run_id)
    if existing:
        try:
            bundle = inspect_run(root, existing["run_id"])
            if bundle["task_key"] != key:
                raise PolicyError("ledger_task_mismatch")
            return {"duplicate": True, "run_id": existing["run_id"], "evidence": bundle}
        except (OSError, ValueError, UnicodeError, KeyError):
            return {"duplicate": True, "run_id": existing["run_id"], "state": "unverified",
                    "reason_code": "existing_run_needs_reconciliation"}

    started_clock, started_at = time.monotonic(), timestamp()
    run_dir, repo = _run_paths(root, run_id)
    run_dir.mkdir(exist_ok=False)
    artifacts: dict[str, bytes] = {}
    events: list[dict] = []
    commands: list[dict] = []
    head = tree = None
    applied = False
    original = BROKEN_SOURCE.encode()
    replacement = b""
    execution, verification, reason = "unverified", "unverified", "incomplete"
    initial_host = host_digest()

    def event(stage: str, status: str):
        events.append({"stage": stage, "status": status, "at": timestamp()})

    def observe(name: str, result: dict):
        artifacts[name] = canonical(result)
        commands.append({"id": name,
                         "exit_code": 0 if result["passed"] else 1, "artifact_id": name})

    def journal(phase: str):
        artifacts["journal"] = canonical({"phase": phase, "before_sha256": sha256(original),
                                         "candidate_sha256": sha256(replacement) if replacement else None,
                                         "host_sha256": initial_host})
        atomic_write(run_dir / ARTIFACT_FILES["journal"], artifacts["journal"])

    try:
        event("admission", "accepted")
        _deadline(started_clock)
        head, tree = _create_repo(repo)
        if head != task["base_sha"] or regular_bytes(repo / SOURCE_PATH) != original:
            raise PolicyError("base_drift")
        event("snapshot", "pinned")
        baseline = verify_source(original.decode())
        observe("baseline_checks", baseline)
        if baseline["passed"] or not any(not item["passed"] for item in baseline["checks"]):
            raise PolicyError("missing_regression_proof")
        event("baseline", "expected_failure")
        _deadline(started_clock)
        if adapter == "fixture-baseline":
            candidate = candidate_for(task, make_fixture_candidate(original.decode()))
        if candidate is None:
            raise PolicyError("missing_candidate")
        source = validate_candidate(candidate, task)
        replacement = source.encode("utf-8")
        if replacement == original:
            execution, verification, reason = "completed", "failed", "no_change"
            event("candidate", "no_change")
        else:
            diff = "".join(difflib.unified_diff(_lf_lines(original.decode()),
                                              _lf_lines(source),
                                              fromfile="a/" + SOURCE_PATH, tofile="b/" + SOURCE_PATH))
            # Only the first two emitted lines are file headers. Hunk content
            # may itself start +++ or --- and still consumes the edit budget.
            changed = sum(line[:1] in ("+", "-") for line in diff.split("\n")[2:])
            if changed > MAX_CHANGED_LINES:
                raise PolicyError("diff_budget")
            artifacts["patch"] = diff.encode("utf-8")
            # This validates every syntax node without executing any Python.
            verify_source(source)
            event("candidate", "eligible")
            _deadline(started_clock)
            if regular_bytes(repo / SOURCE_PATH) != original or host_digest() != initial_host:
                raise PolicyError("pre_apply_drift")
            journal("prepared")
            atomic_write(repo / SOURCE_PATH, replacement)
            applied = True
            journal("applied")
            event("apply", "applied")
            _deadline(started_clock)
            actual = regular_bytes(repo / SOURCE_PATH).decode("utf-8")
            if actual.encode() != replacement or host_digest() != initial_host:
                raise PolicyError("post_apply_drift")
            checked = verify_source(actual)
            observe("candidate_checks", checked)
            if not checked["passed"]:
                if _restore_if_unchanged(repo / SOURCE_PATH, replacement, original):
                    applied = False
                    execution, verification, reason = "completed", "failed", "verification_failed_rolled_back"
                    journal("restored")
                    event("verification", "failed_rolled_back")
                else:
                    execution, verification, reason = "unverified", "unverified", "recovery_required"
                    head = tree = None
                    journal("recovery_required")
            else:
                _deadline(started_clock)
                head, tree = _record_commit(repo, actual, BASE_SHA)
                _deadline(started_clock)
                if regular_bytes(repo / SOURCE_PATH) != replacement or host_digest() != initial_host:
                    raise PolicyError("final_drift")
                execution, verification, reason = "completed", "verified", "awaiting_independent_review"
                journal("verified")
                event("verification", "verified")
    except (PolicyError, UnsafeSource) as exc:
        execution, verification, reason = "denied", "denied", str(exc)
        event("policy", "denied")
        if applied:
            if _restore_if_unchanged(repo / SOURCE_PATH, replacement, original):
                head, tree = _record_commit(repo, BROKEN_SOURCE)
                journal("restored_after_denial")
            else:
                execution, verification, reason = "unverified", "unverified", "recovery_required"
                head = tree = None
                journal("recovery_required")
    except (TimeoutError, subprocess.TimeoutExpired):
        execution, verification, reason = "unverified", "unverified", "timeout"
        event("execution", "timeout")
        if applied and _restore_if_unchanged(repo / SOURCE_PATH, replacement, original):
            head, tree = _record_commit(repo, BROKEN_SOURCE)
            journal("restored_after_timeout")
        elif applied:
            reason = "recovery_required"
            head = tree = None
            journal("recovery_required")
    except (OSError, RuntimeError, UnicodeError) as exc:
        execution, verification, reason = "failed", "unverified", "host_operation_failed"
        event("execution", "failed")
        if applied:
            restored = _restore_if_unchanged(repo / SOURCE_PATH, replacement, original)
            head = tree = None
            reason = "host_failed_restored_unverified" if restored else "recovery_required"
            journal(reason)

    if head is not None:
        try:
            current = regular_bytes(repo / SOURCE_PATH)
            expected_current = original if head == BASE_SHA else replacement
            if current != expected_current:
                execution, verification, reason = "unverified", "unverified", "final_source_drift"
                head = tree = None
                journal("final_source_drift")
            artifacts["source_hashes"] = canonical({"before_sha256": sha256(original), "after_sha256": sha256(current)})
        except (OSError, PolicyError):
            execution, verification, reason = "unverified", "unverified", "source_unreadable"
            head = tree = None
    if verification == "verified" and time.monotonic() - started_clock > LIMITS["timeout_seconds"]:
        execution, verification, reason = "unverified", "unverified", "timeout_during_finalization"
        journal("timeout_during_finalization")
    event("evidence", "recorded")
    ended_at = timestamp()
    bundle = {
        "schema_version": "ev.v0.1", "product": "arms", "run_id": run_id, "task_key": key,
        "task": {field: task[field] for field in ("repository", "task_id", "scope_revision", "fixture_id")},
        "source": {"base_sha": BASE_SHA, "head_sha": head, "tree_sha": tree},
        "configuration": {"digest": POLICY_DIGEST, "suite_digest": SUITE_DIGEST,
                          "verifier_version": VERIFIER_VERSION, "limits": dict(LIMITS)},
        "timestamps": {"started_at": started_at, "ended_at": ended_at},
        "outcome": {"execution": execution, "verification": verification,
                    "task_success": False, "reason_code": reason},
        "events": events, "commands": commands,
        "artifacts": [artifact_record(name, data, "text/x-diff" if name == "patch" else "application/json")
                      for name, data in artifacts.items()],
        "provenance": {"builder": BUILDER, "adapter": adapter, "reviewer": None,
                       "reviewed_head": None, "review_state": "pending", "review_receipt_sha256": None},
        "metrics": {"duration_seconds": round(time.monotonic() - started_clock, 6),
                    "human_minutes": None, "cost_amount": None, "cost_currency": None},
        "limitations": list(LIMITATIONS),
    }
    validate_evidence(bundle)
    for name, data in artifacts.items():
        atomic_write(run_dir / ARTIFACT_FILES[name], data)
    atomic_write(run_dir / "evidence.json", canonical(bundle))
    finish(root, key, execution + ":" + verification)
    return {"duplicate": False, "run_id": run_id, "evidence": bundle}


def record_review(root: Path, run_id: str, receipt: dict) -> dict:
    """Accept an explicit local reviewer attestation, never from candidate data.

    This is an operator action, not identity authentication. Receipt bytes and
    reviewed evidence are preserved separately; original run evidence is immutable.
    """
    root = ensure_root(root)
    bundle = inspect_run(root, run_id)
    if bundle["outcome"]["verification"] != "verified":
        raise PolicyError("only_verified_patch_can_be_reviewed")
    required = {"run_id", "head_sha", "evidence_sha256", "reviewer", "decision", "blocking_findings", "notes"}
    if not isinstance(receipt, dict) or set(receipt) != required:
        raise PolicyError("invalid_review_fields")
    if len(canonical(receipt)) > 8192:
        raise PolicyError("review_too_large")
    if receipt["run_id"] != run_id or receipt["head_sha"] != bundle["source"]["head_sha"]:
        raise PolicyError("review_target_mismatch")
    if receipt["evidence_sha256"] != sha256(canonical(bundle)):
        raise PolicyError("review_evidence_mismatch")
    reviewer = receipt["reviewer"]
    if (not isinstance(reviewer, str) or not 1 <= len(reviewer) <= 128
            or reviewer.strip().casefold() == BUILDER.strip().casefold()):
        raise PolicyError("independent_reviewer_required")
    if receipt["decision"] not in ("approved", "changes_requested"):
        raise PolicyError("invalid_review_decision")
    if type(receipt["blocking_findings"]) is not int or receipt["blocking_findings"] < 0:
        raise PolicyError("invalid_finding_count")
    if receipt["decision"] == "approved" and receipt["blocking_findings"] != 0:
        raise PolicyError("unresolved_review_findings")
    if not isinstance(receipt["notes"], str) or len(receipt["notes"]) > 4096:
        raise PolicyError("invalid_review_notes")
    run_dir, _ = _run_paths(root, run_id)
    reviewed = json.loads(canonical(bundle))
    reviewed["provenance"].update({"reviewer": reviewer, "reviewed_head": receipt["head_sha"],
                                  "review_state": receipt["decision"], "review_receipt_sha256": sha256(canonical(receipt))})
    if receipt["decision"] == "approved":
        reviewed["outcome"].update({"task_success": True, "reason_code": "reviewed_synthetic_fix"})
    else:
        reviewed["outcome"].update({"task_success": False, "reason_code": "review_changes_requested"})
    validate_evidence(reviewed)
    # Validation precedes any write: invalid reviewer metadata must not poison
    # a run. Exclusive creation prevents competing reviews from overwriting.
    receipt_path = run_dir / "review-receipt.json"
    try:
        with receipt_path.open("xb") as stream:
            stream.write(canonical(receipt))
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        if regular_bytes(receipt_path) != canonical(receipt):
            raise PolicyError("review_already_recorded")
    atomic_write(run_dir / "reviewed-evidence.json", canonical(reviewed))
    return reviewed


def publication_status(bundle: dict) -> dict:
    """No provider adapter exists. An imported approval cannot enable one."""
    validate_evidence(bundle)
    return {"status": "needs_approval", "performed": False,
            "reason_code": "private_pilot_not_implemented_or_authorized",
            "head_sha": bundle["source"]["head_sha"]}
