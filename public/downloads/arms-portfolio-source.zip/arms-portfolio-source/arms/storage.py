"""Trusted local state, exact artifact writes, and atomic task reservation."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
import stat
import uuid

from .contracts import POLICY_DIGEST, PolicyError, canonical

MARKER = {"format": "arms-workbench-v0.1", "policy_digest": POLICY_DIGEST}


def no_symlinks(path: Path) -> None:
    path = path.absolute()
    for item in (path, *path.parents):
        if item.is_symlink():
            raise PolicyError("symlink_path")


def regular_bytes(path: Path, limit: int = 262144) -> bytes:
    no_symlinks(path)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise PolicyError("nonregular_or_linked_file")
        if info.st_size > limit:
            raise PolicyError("file_too_large")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            result = stream.read(limit + 1)
        if len(result) > limit:
            raise PolicyError("file_too_large")
        return result
    finally:
        os.close(fd)


def atomic_write(path: Path, data: bytes) -> None:
    no_symlinks(path)
    if path.exists() and not path.is_file():
        raise PolicyError("nonregular_output")
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temp.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def ensure_root(root: Path) -> Path:
    root = root.absolute()
    no_symlinks(root)
    if root.exists():
        if not root.is_dir():
            raise PolicyError("workspace_is_not_directory")
        marker = root / "workbench.json"
        if not marker.exists() or regular_bytes(marker) != canonical(MARKER):
            raise PolicyError("workspace_not_owned_or_policy_changed")
    else:
        # Refuse to claim an existing unmarked directory or overwrite user files.
        root.mkdir(parents=True, exist_ok=False)
        atomic_write(root / "workbench.json", canonical(MARKER))
    for name in ("runs", "workspaces"):
        directory = root / name
        no_symlinks(directory)
        directory.mkdir(exist_ok=True)
    return root


def open_ledger(root: Path) -> sqlite3.Connection:
    db = root / "ledger.sqlite3"
    no_symlinks(db)
    if db.exists():
        info = db.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise PolicyError("invalid_ledger")
    for suffix in ("-journal", "-wal", "-shm"):
        no_symlinks(Path(str(db) + suffix))
    connection = sqlite3.connect(db, timeout=5, isolation_level=None)
    connection.execute("PRAGMA synchronous=FULL")
    connection.execute("CREATE TABLE IF NOT EXISTS tasks (task_key TEXT PRIMARY KEY, run_id TEXT UNIQUE NOT NULL, state TEXT NOT NULL)")
    return connection


def reserve(root: Path, key: str, run_id: str) -> dict | None:
    with open_ledger(root) as db:
        db.execute("BEGIN IMMEDIATE")
        existing = db.execute("SELECT run_id, state FROM tasks WHERE task_key = ?", (key,)).fetchone()
        if existing:
            db.execute("COMMIT")
            try:
                uuid.UUID(existing[0])
            except (ValueError, TypeError) as exc:
                raise PolicyError("invalid_ledger_run") from exc
            return {"run_id": existing[0], "state": existing[1]}
        db.execute("INSERT INTO tasks VALUES (?, ?, 'in_progress')", (key, run_id))
        db.execute("COMMIT")
        return None


def finish(root: Path, key: str, state: str) -> None:
    with open_ledger(root) as db:
        db.execute("UPDATE tasks SET state = ? WHERE task_key = ?", (state, key))
