"""Host-owned policy. Task and candidate JSON are data, never authority."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from .fixture import BROKEN_SOURCE, FIXTURE_ID, SOURCE_PATH, SUITE_DIGEST, VERIFIER_VERSION

REPOSITORY = "fixture://arms/retry-backoff-v1"
SCOPE = "ARMS-v0.1-offline.1"
BUILDER = "arms-host-v0.1"
LIMITS = {"max_attempts": 1, "max_candidate_bytes": 8192, "max_changed_files": 1, "timeout_seconds": 30}
MAX_CHANGED_LINES = 12
POLICY = {
    "repository": REPOSITORY,
    "scope_revision": SCOPE,
    "fixture_id": FIXTURE_ID,
    "allowed_paths": [SOURCE_PATH],
    "limits": LIMITS,
    "max_changed_lines": MAX_CHANGED_LINES,
    "verifier_version": VERIFIER_VERSION,
    "suite_digest": SUITE_DIGEST,
    "execution": "restricted-ast-interpreter; no candidate Python execution",
    "publication": "disabled",
}


class PolicyError(ValueError):
    """An input cannot satisfy the fixed offline contract."""


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


POLICY_DIGEST = sha256(canonical(POLICY))


def git_hash(kind: str, payload: bytes) -> str:
    return hashlib.sha1(f"{kind} {len(payload)}\0".encode("ascii") + payload).hexdigest()


def source_identity(source: str, parent: str | None = None) -> tuple[str, str, str, bytes]:
    """Compute real Git object IDs for a one-file synthetic repository."""
    blob = git_hash("blob", source.encode("utf-8"))
    tree_payload = f"100644 {SOURCE_PATH}\0".encode("ascii") + bytes.fromhex(blob)
    tree = git_hash("tree", tree_payload)
    message = "Repair retry backoff fixture" if parent else "Seed retry backoff fixture"
    body = f"tree {tree}\n"
    if parent:
        body += f"parent {parent}\n"
    body += "author ARMS Fixture <fixture@example.invalid> 946684800 +0000\n"
    body += "committer ARMS Fixture <fixture@example.invalid> 946684800 +0000\n\n"
    body += message + "\n"
    commit = body.encode("utf-8")
    return git_hash("commit", commit), tree, blob, commit


BASE_SHA = source_identity(BROKEN_SOURCE)[0]


def default_task(task_id: str = "ARMS-FIXTURE-001") -> dict:
    return {"repository": REPOSITORY, "task_id": task_id, "base_sha": BASE_SHA,
            "scope_revision": SCOPE, "fixture_id": FIXTURE_ID,
            "instruction": "Repair the retry delay so attempt zero returns the base delay and each later attempt doubles it."}


def validate_task(task: dict) -> None:
    fields = {"repository", "task_id", "base_sha", "scope_revision", "fixture_id", "instruction"}
    if not isinstance(task, dict) or set(task) != fields:
        raise PolicyError("invalid_task_fields")
    if task["repository"] != REPOSITORY:
        raise PolicyError("repository_not_allowlisted")
    if task["scope_revision"] != SCOPE or task["fixture_id"] != FIXTURE_ID:
        raise PolicyError("unsupported_scope")
    if task["base_sha"] != BASE_SHA:
        raise PolicyError("base_drift")
    if not isinstance(task["task_id"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", task["task_id"]):
        raise PolicyError("invalid_task_id")
    if not isinstance(task["instruction"], str) or len(task["instruction"].encode("utf-8")) > 4096:
        raise PolicyError("invalid_instruction")


def task_key(task: dict) -> str:
    validate_task(task)
    # Instruction text cannot alter policy or create a fresh repair budget.
    return sha256(canonical({k: task[k] for k in ("repository", "task_id", "base_sha", "scope_revision")}))


def candidate_for(task: dict, source: str) -> dict:
    return {"task_key": task_key(task), "expected_before_sha256": sha256(BROKEN_SOURCE.encode()),
            "replacement_source": source}


def validate_candidate(candidate: dict, task: dict) -> str:
    fields = {"task_key", "expected_before_sha256", "replacement_source"}
    if not isinstance(candidate, dict) or set(candidate) != fields:
        raise PolicyError("invalid_candidate_fields")
    try:
        size = len(canonical(candidate))
    except (TypeError, ValueError, UnicodeError) as exc:
        raise PolicyError("invalid_candidate_json") from exc
    if size > LIMITS["max_candidate_bytes"]:
        raise PolicyError("candidate_too_large")
    if candidate["task_key"] != task_key(task):
        raise PolicyError("wrong_task")
    if candidate["expected_before_sha256"] != sha256(BROKEN_SOURCE.encode()):
        raise PolicyError("stale_candidate")
    source = candidate["replacement_source"]
    if not isinstance(source, str):
        raise PolicyError("replacement_must_be_text")
    if not source.endswith("\n") or "\r" in source:
        raise PolicyError("replacement_requires_lf_final_newline")
    try:
        source.encode("utf-8")
    except UnicodeError as exc:
        raise PolicyError("invalid_utf8") from exc
    return source


def read_json(path: Path, limit: int = 8192) -> dict:
    """Bound before decoding; reject duplicate keys and non-finite JSON."""
    if path.is_symlink() or not path.is_file():
        raise PolicyError("input_must_be_regular_file")
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise PolicyError("input_too_large")

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise PolicyError("duplicate_json_key")
            result[key] = value
        return result

    try:
        obj = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _: (_ for _ in ()).throw(PolicyError("nonfinite_json")))
        if not isinstance(obj, dict):
            raise PolicyError("json_object_required")
        return obj
    except (json.JSONDecodeError, UnicodeError, RecursionError) as exc:
        raise PolicyError("invalid_json") from exc
