"""Strict, data-only ARMS evidence envelopes (EV v0.1).

This module never resolves artifact IDs as paths, fetches URLs, imports submitted
code, or executes report content. Hashes establish byte consistency, not trusted
authorship. A reviewer field is an attestation whose origin must be established
by the host; it is not an authentication mechanism.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime
from uuid import UUID


MAX_EVIDENCE_BYTES = 256 * 1024
_HEX256 = re.compile(r"[0-9a-f]{64}\Z")
_HEX160 = re.compile(r"[0-9a-f]{40}\Z")
_ARTIFACT_ID = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
_TIMESTAMP = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
    r"(?:\.[0-9]{1,9})?(?:Z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])\Z"
)
_MEDIA_TYPE = re.compile(r"[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+\Z")
_STATES = {"completed", "failed", "denied", "unverified", "pending"}
_VERIFICATION_STATES = {"verified", "failed", "denied", "unverified", "pending"}
_LIMITS = {
    "max_attempts": 1,
    "max_candidate_bytes": 8192,
    "max_changed_files": 1,
    "timeout_seconds": 30,
}


class EvidenceError(ValueError):
    """An evidence envelope or its associated bytes violate the contract."""


def _fail(where: str, message: str) -> None:
    raise EvidenceError(f"{where}: {message}")


def _json_safe(value: object, depth: int = 0, count: list[int] | None = None) -> None:
    """Reject Python-only types, nonfinite numbers, and excessive nesting."""
    if count is None:
        count = [0]
    count[0] += 1
    if depth > 64 or count[0] > 20000:
        _fail("json", "document exceeds structural limits")
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float:
        if not math.isfinite(value):
            _fail("json", "numbers must be finite")
        return
    if type(value) is list:
        for item in value:
            _json_safe(item, depth + 1, count)
        return
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                _fail("json", "object keys must be strings")
            _json_safe(item, depth + 1, count)
        return
    _fail("json", "only JSON data types are permitted")


def canonical_bytes(obj: object) -> bytes:
    """Return deterministic UTF-8 JSON without nonfinite or Python-only values."""
    _json_safe(obj)
    try:
        return json.dumps(
            obj, sort_keys=True, ensure_ascii=False, allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError, OverflowError, UnicodeError, RecursionError) as exc:
        raise EvidenceError("json: cannot encode canonical JSON") from exc


def digest(obj: object) -> str:
    """SHA-256 of canonical JSON; not a signature or proof of authenticity."""
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()


def _object(value: object, keys: set[str], where: str) -> dict:
    if type(value) is not dict:
        _fail(where, "expected object")
    if set(value) != keys:
        missing = sorted(keys - set(value))
        extra = sorted(set(value) - keys)
        _fail(where, f"wrong fields (missing={missing}, extra={extra})")
    return value


def _text(value: object, where: str, maximum: int = 1024) -> str:
    if type(value) is not str or not value or not value.strip():
        _fail(where, "expected nonempty string")
    if len(value) > maximum or any(ord(char) < 32 or ord(char) == 127 for char in value):
        _fail(where, "string exceeds bounds or contains control characters")
    try:
        value.encode("utf-8")
    except UnicodeError as exc:
        raise EvidenceError(f"{where}: invalid Unicode") from exc
    return value


def _hash(value: object, where: str, *, git: bool = False, nullable: bool = False) -> None:
    if nullable and value is None:
        return
    pattern = _HEX160 if git else _HEX256
    if type(value) is not str or not pattern.fullmatch(value):
        _fail(where, "expected lowercase hexadecimal digest")


def _logical_id(value: object, where: str) -> None:
    if type(value) is not str or not _ARTIFACT_ID.fullmatch(value):
        _fail(where, "expected safe logical identifier")


def _integer(value: object, where: str, minimum: int, maximum: int) -> None:
    if type(value) is not int or not minimum <= value <= maximum:
        _fail(where, "expected bounded integer")


def _number(value: object, where: str) -> None:
    if value is None:
        return
    if type(value) not in (int, float):
        _fail(where, "expected nonnegative finite number or null")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or value < 0:
        _fail(where, "expected nonnegative finite number or null")


def _sequence(value: object, where: str, maximum: int = 256) -> list:
    if type(value) is not list or len(value) > maximum:
        _fail(where, "expected bounded array")
    return value


def _timestamp(value: object, where: str) -> datetime:
    if type(value) is not str or not _TIMESTAMP.fullmatch(value):
        _fail(where, "expected RFC3339 timestamp with timezone")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise EvidenceError(f"{where}: invalid timestamp") from exc
    if parsed.tzinfo is None:
        _fail(where, "timestamp must include timezone")
    return parsed


def _artifact(value: object, where: str) -> dict:
    obj = _object(value, {"id", "sha256", "size_bytes", "media_type"}, where)
    _logical_id(obj["id"], f"{where}.id")
    _hash(obj["sha256"], f"{where}.sha256")
    _integer(obj["size_bytes"], f"{where}.size_bytes", 0, 2**63 - 1)
    media = _text(obj["media_type"], f"{where}.media_type", 128)
    if not _MEDIA_TYPE.fullmatch(media):
        _fail(f"{where}.media_type", "expected media type without parameters")
    return obj


def artifact_record(id: str, data: bytes, media_type: str) -> dict:
    """Describe bytes using a logical ID, never a filesystem path."""
    if type(data) is not bytes:
        _fail("artifact.data", "expected bytes")
    result = {
        "id": id,
        "sha256": hashlib.sha256(data).hexdigest(),
        "size_bytes": len(data),
        "media_type": media_type,
    }
    _artifact(result, "artifact")
    return result


def validate_evidence(bundle: dict) -> None:
    """Validate the complete EV v0.1 shape and success/review invariants."""
    serialized = canonical_bytes(bundle)
    if len(serialized) > MAX_EVIDENCE_BYTES:
        _fail("evidence", "document exceeds 256 KiB")
    root = _object(bundle, {
        "schema_version", "product", "run_id", "task_key", "task", "source",
        "configuration", "timestamps", "outcome", "events", "commands",
        "artifacts", "provenance", "metrics", "limitations",
    }, "evidence")
    if root["schema_version"] != "ev.v0.1" or root["product"] != "arms":
        _fail("evidence", "unsupported schema version or product")
    run_id = _text(root["run_id"], "run_id", 36)
    try:
        if str(UUID(run_id)) != run_id:
            _fail("run_id", "expected canonical UUID")
    except ValueError as exc:
        raise EvidenceError("run_id: expected canonical UUID") from exc
    _hash(root["task_key"], "task_key")

    task = _object(root["task"], {"repository", "task_id", "scope_revision", "fixture_id"}, "task")
    for key, value in task.items():
        _text(value, f"task.{key}", 1024 if key == "repository" else 128)

    source = _object(root["source"], {"base_sha", "head_sha", "tree_sha"}, "source")
    _hash(source["base_sha"], "source.base_sha", git=True)
    _hash(source["head_sha"], "source.head_sha", git=True, nullable=True)
    _hash(source["tree_sha"], "source.tree_sha", git=True, nullable=True)

    config = _object(root["configuration"], {
        "digest", "suite_digest", "verifier_version", "limits",
    }, "configuration")
    _hash(config["digest"], "configuration.digest")
    _hash(config["suite_digest"], "configuration.suite_digest")
    _text(config["verifier_version"], "configuration.verifier_version", 128)
    limits = _object(config["limits"], set(_LIMITS), "configuration.limits")
    for key, expected in _LIMITS.items():
        if type(limits[key]) is not int or limits[key] != expected:
            _fail(f"configuration.limits.{key}", "does not match frozen EV v0.1 profile")

    timestamps = _object(root["timestamps"], {"started_at", "ended_at"}, "timestamps")
    started = _timestamp(timestamps["started_at"], "timestamps.started_at")
    ended = _timestamp(timestamps["ended_at"], "timestamps.ended_at")
    if ended < started:
        _fail("timestamps", "end precedes start")

    outcome = _object(root["outcome"], {
        "execution", "verification", "task_success", "reason_code",
    }, "outcome")
    if type(outcome["execution"]) is not str or outcome["execution"] not in _STATES:
        _fail("outcome.execution", "unknown execution state")
    if type(outcome["verification"]) is not str or outcome["verification"] not in _VERIFICATION_STATES:
        _fail("outcome.verification", "unknown verification state")
    if type(outcome["task_success"]) is not bool:
        _fail("outcome.task_success", "expected boolean")
    _text(outcome["reason_code"], "outcome.reason_code", 128)

    previous = None
    for index, event in enumerate(_sequence(root["events"], "events")):
        where = f"events[{index}]"
        row = _object(event, {"stage", "status", "at"}, where)
        _text(row["stage"], f"{where}.stage", 128)
        _text(row["status"], f"{where}.status", 128)
        at = _timestamp(row["at"], f"{where}.at")
        if previous is not None and at < previous:
            _fail("events", "events must be chronologically ordered")
        previous = at

    artifact_ids = set()
    for index, item in enumerate(_sequence(root["artifacts"], "artifacts")):
        row = _artifact(item, f"artifacts[{index}]")
        if row["id"] in artifact_ids:
            _fail("artifacts", "duplicate logical identifier")
        artifact_ids.add(row["id"])

    command_ids = set()
    commands_by_id = {}
    for index, command in enumerate(_sequence(root["commands"], "commands")):
        where = f"commands[{index}]"
        row = _object(command, {"id", "exit_code", "artifact_id"}, where)
        _logical_id(row["id"], f"{where}.id")
        if row["id"] in command_ids:
            _fail("commands", "duplicate command identifier")
        command_ids.add(row["id"])
        commands_by_id[row["id"]] = row
        if row["exit_code"] is not None:
            _integer(row["exit_code"], f"{where}.exit_code", -(2**31), 2**31 - 1)
        if row["artifact_id"] is not None:
            _logical_id(row["artifact_id"], f"{where}.artifact_id")
            if row["artifact_id"] not in artifact_ids:
                _fail(f"{where}.artifact_id", "references unknown artifact")

    # This version's verified outcome is specifically the protected seeded
    # regression workflow: observe the failure, then verify a bounded repair.
    # Denial/failure envelopes can remain sparse, but neither a success flag nor
    # a review attestation may substitute for the required verification proof.
    if outcome["verification"] == "verified":
        required_artifacts = {"baseline_checks", "candidate_checks", "patch", "source_hashes"}
        if not required_artifacts <= artifact_ids:
            _fail("outcome.verification", "verified requires baseline, candidate, patch, and source proof artifacts")
        for command_id, expected_exit in (("baseline_checks", 1), ("candidate_checks", 0)):
            command = commands_by_id.get(command_id)
            if command is None or command["exit_code"] != expected_exit or command["artifact_id"] != command_id:
                _fail("outcome.verification", "verified requires failed baseline and successful candidate commands bound to proof artifacts")

    provenance = _object(root["provenance"], {
        "builder", "adapter", "reviewer", "reviewed_head", "review_state",
        "review_receipt_sha256",
    }, "provenance")
    _text(provenance["builder"], "provenance.builder", 256)
    if provenance["adapter"] not in ("fixture-baseline", "native-json"):
        _fail("provenance.adapter", "unknown adapter")
    if provenance["review_state"] not in ("pending", "approved", "changes_requested"):
        _fail("provenance.review_state", "unknown review state")
    if provenance["review_state"] == "pending":
        if any(provenance[key] is not None for key in (
            "reviewer", "reviewed_head", "review_receipt_sha256",
        )):
            _fail("provenance", "pending review must not assert a reviewer or receipt")
    else:
        reviewer = _text(provenance["reviewer"], "provenance.reviewer", 256)
        if reviewer.strip().casefold() == provenance["builder"].strip().casefold():
            _fail("provenance.reviewer", "reviewer must be distinct from builder")
        _hash(provenance["reviewed_head"], "provenance.reviewed_head", git=True)
        _hash(provenance["review_receipt_sha256"], "provenance.review_receipt_sha256")
        if source["head_sha"] is None or provenance["reviewed_head"] != source["head_sha"]:
            _fail("provenance.reviewed_head", "review must bind the recorded head")

    if outcome["task_success"] and not (
        outcome["execution"] == "completed"
        and outcome["verification"] == "verified"
        and provenance["review_state"] == "approved"
        and source["head_sha"] is not None
        and source["tree_sha"] is not None
    ):
        _fail("outcome.task_success", "success requires verified execution and independent review")

    metrics = _object(root["metrics"], {
        "duration_seconds", "human_minutes", "cost_amount", "cost_currency",
    }, "metrics")
    for key in ("duration_seconds", "human_minutes", "cost_amount"):
        _number(metrics[key], f"metrics.{key}")
    currency = metrics["cost_currency"]
    if currency is not None and (type(currency) is not str or not re.fullmatch(r"[A-Z]{3}", currency)):
        _fail("metrics.cost_currency", "expected three-letter uppercase currency or null")
    if (metrics["cost_amount"] is None) != (currency is None):
        _fail("metrics", "cost amount and currency must be known together")
    for index, limitation in enumerate(_sequence(root["limitations"], "limitations", 64)):
        _text(limitation, f"limitations[{index}]", 2048)


def loads_evidence(data: bytes) -> dict:
    """Load bounded JSON, rejecting duplicate keys and nonstandard constants."""
    if type(data) is not bytes:
        _fail("evidence", "expected UTF-8 bytes")
    if len(data) > MAX_EVIDENCE_BYTES:
        _fail("evidence", "document exceeds 256 KiB")

    def pairs(items: list[tuple[str, object]]) -> dict:
        result = {}
        for key, value in items:
            if key in result:
                _fail("json", "duplicate object key")
            result[key] = value
        return result

    def reject_constant(value: str) -> None:
        _fail("json", "nonstandard numeric constant")

    try:
        obj = json.loads(data.decode("utf-8"), object_pairs_hook=pairs, parse_constant=reject_constant)
    except EvidenceError:
        raise
    except (UnicodeError, ValueError, TypeError, OverflowError, RecursionError) as exc:
        raise EvidenceError("json: invalid JSON document") from exc
    validate_evidence(obj)
    return obj


def verify_artifacts(bundle: dict, artifacts: dict[str, bytes]) -> None:
    """Compare explicitly supplied bytes; never open paths from the envelope."""
    validate_evidence(bundle)
    if type(artifacts) is not dict:
        _fail("artifacts", "expected map of logical identifiers to bytes")
    expected = {record["id"]: record for record in bundle["artifacts"]}
    if set(artifacts) != set(expected):
        _fail("artifacts", "supplied artifact set does not match envelope")
    for logical_id, record in expected.items():
        data = artifacts[logical_id]
        if type(data) is not bytes:
            _fail(f"artifacts.{logical_id}", "expected bytes")
        if len(data) != record["size_bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
            _fail(f"artifacts.{logical_id}", "artifact hash or size mismatch")


def comparable(a: dict, b: dict) -> bool:
    """Whether explicit task/suite/configuration rules allow comparison.

    Run IDs, task keys, and timestamps identify observations, not compatibility.
    Compatible does not mean equally trustworthy, successful, or representative.
    """
    validate_evidence(a)
    validate_evidence(b)

    def signature(bundle: dict) -> tuple:
        task = bundle["task"]
        config = bundle["configuration"]
        return (
            task["fixture_id"], task["scope_revision"], config["suite_digest"],
            config["digest"], config["verifier_version"],
        )

    return signature(a) == signature(b)
