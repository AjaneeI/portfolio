"""Contract tests for data-only ARMS evidence and artifact integrity."""

from copy import deepcopy
import hashlib
import json
import unittest

from arms.evidence import (
    EvidenceError, MAX_EVIDENCE_BYTES, artifact_record, canonical_bytes,
    comparable, digest, loads_evidence, validate_evidence, verify_artifacts,
)


def verification_artifacts() -> dict[str, bytes]:
    return {
        "baseline_checks": b'{"passed":false}',
        "candidate_checks": b'{"passed":true}',
        "patch": b"--- a/retry.py\n+++ b/retry.py\n",
        "source_hashes": b'{"before":"synthetic","after":"synthetic"}',
    }


def valid_bundle() -> dict:
    """A complete verified fixture result awaiting independent review."""
    proofs = verification_artifacts()
    return {
        "schema_version": "ev.v0.1",
        "product": "arms",
        "run_id": "601bc203-4658-48e6-9ada-42d0478cc459",
        "task_key": "a" * 64,
        "task": {
            "repository": "fixture://retry-backoff-v1",
            "task_id": "seeded-off-by-one",
            "scope_revision": "arms.v0.1",
            "fixture_id": "retry-backoff-v1",
        },
        "source": {"base_sha": "b" * 40, "head_sha": "c" * 40, "tree_sha": "d" * 40},
        "configuration": {
            "digest": "e" * 64,
            "suite_digest": "f" * 64,
            "verifier_version": "restricted-ast-v1",
            "limits": {
                "max_attempts": 1,
                "max_candidate_bytes": 8192,
                "max_changed_files": 1,
                "timeout_seconds": 30,
            },
        },
        "timestamps": {"started_at": "2026-10-21T03:40:00Z", "ended_at": "2026-10-21T03:40:01Z"},
        "outcome": {
            "execution": "completed", "verification": "verified",
            "task_success": False, "reason_code": "awaiting_independent_review",
        },
        "events": [
            {"stage": "admission", "status": "accepted", "at": "2026-10-21T03:40:00Z"},
            {"stage": "verification", "status": "verified", "at": "2026-10-21T03:40:01Z"},
        ],
        "commands": [
            {"id": "baseline_checks", "exit_code": 1, "artifact_id": "baseline_checks"},
            {"id": "candidate_checks", "exit_code": 0, "artifact_id": "candidate_checks"},
        ],
        "artifacts": [
            artifact_record(key, data, "text/x-diff" if key == "patch" else "application/json")
            for key, data in proofs.items()
        ],
        "provenance": {
            "builder": "builder-1", "adapter": "fixture-baseline",
            "reviewer": None, "reviewed_head": None, "review_state": "pending",
            "review_receipt_sha256": None,
        },
        "metrics": {"duration_seconds": 1.0, "human_minutes": None, "cost_amount": None, "cost_currency": None},
        "limitations": ["Synthetic fixture; no live repository write or unattended runtime demonstrated."],
    }


def approved_bundle() -> dict:
    result = valid_bundle()
    result["provenance"].update({
        "review_state": "approved", "reviewer": "reviewer-2",
        "reviewed_head": result["source"]["head_sha"],
        "review_receipt_sha256": "1" * 64,
    })
    result["outcome"].update({"task_success": True, "reason_code": "reviewed_fixture_fix"})
    return result


class CanonicalJSONTests(unittest.TestCase):
    def test_canonical_encoding_is_sorted_utf8_and_repeatable(self):
        obj = {"z": 3, "a": {"emoji": "✓", "value": 2}}
        expected = '{"a":{"emoji":"✓","value":2},"z":3}'.encode("utf-8")
        self.assertEqual(canonical_bytes(obj), expected)
        self.assertEqual(digest(obj), hashlib.sha256(expected).hexdigest())
        self.assertEqual(digest({"a": obj["a"], "z": 3}), digest(obj))

    def test_non_data_types_and_nonfinite_numbers_are_refused(self):
        for obj in ({1: "value"}, (1, 2), {"v": b"bytes"}, {"v": float("nan")}, {"v": float("inf")}, {"v": object()}):
            with self.subTest(obj=repr(obj)), self.assertRaises(EvidenceError):
                canonical_bytes(obj)

    def test_cycles_and_excessive_structure_are_refused(self):
        cycle = []
        cycle.append(cycle)
        with self.assertRaises(EvidenceError):
            canonical_bytes(cycle)
        with self.assertRaises(EvidenceError):
            canonical_bytes([None] * 20001)

    def test_invalid_unicode_is_refused(self):
        with self.assertRaises(EvidenceError):
            canonical_bytes({"v": "\ud800"})


class EnvelopeTests(unittest.TestCase):
    def test_pending_review_is_valid_without_success(self):
        bundle = valid_bundle()
        validate_evidence(bundle)
        self.assertEqual(loads_evidence(canonical_bytes(bundle)), bundle)

    def test_approved_review_can_support_success(self):
        validate_evidence(approved_bundle())

    def test_failure_denial_unknown_and_pending_remain_distinct(self):
        for execution, verification in (
            ("failed", "failed"), ("denied", "denied"),
            ("unverified", "unverified"), ("pending", "pending"),
        ):
            bundle = valid_bundle()
            bundle["outcome"].update({"execution": execution, "verification": verification})
            bundle["source"].update({"head_sha": None, "tree_sha": None})
            bundle["commands"][0]["exit_code"] = None
            with self.subTest(state=execution):
                validate_evidence(bundle)
                self.assertFalse(loads_evidence(canonical_bytes(bundle))["outcome"]["task_success"])

    def test_unknown_and_missing_fields_rejected_at_every_level(self):
        paths = [(), ("task",), ("source",), ("configuration",), ("configuration", "limits"),
                 ("timestamps",), ("outcome",), ("provenance",), ("metrics",),
                 ("events", 0), ("commands", 0), ("artifacts", 0)]
        for path in paths:
            for mutation in ("extra", "missing"):
                bundle = valid_bundle()
                target = bundle
                for key in path:
                    target = target[key]
                if mutation == "extra":
                    target["surprise"] = "execute-me"
                else:
                    del target[next(iter(target))]
                with self.subTest(path=path, mutation=mutation), self.assertRaises(EvidenceError):
                    validate_evidence(bundle)

    def test_duplicate_json_keys_rejected_even_if_values_match(self):
        raw = canonical_bytes(valid_bundle())
        duplicate = raw.replace(b'"product":"arms"', b'"product":"arms","product":"arms"')
        with self.assertRaisesRegex(EvidenceError, "duplicate"):
            loads_evidence(duplicate)
        nested = raw.replace(b'"max_attempts":1', b'"max_attempts":1,"max_attempts":1')
        with self.assertRaisesRegex(EvidenceError, "duplicate"):
            loads_evidence(nested)

    def test_bad_json_nonstandard_numbers_and_invalid_utf8_rejected(self):
        for raw in (b"{", b"null", b"[]", b"{} trailing", b'\xff', b'{"x":NaN}', b'{"x":Infinity}', b'{"x":1e9999}'):
            with self.subTest(raw=raw), self.assertRaises(EvidenceError):
                loads_evidence(raw)

    def test_size_limit_applies_before_parsing_and_to_direct_validation(self):
        with self.assertRaisesRegex(EvidenceError, "256 KiB"):
            loads_evidence(b" " * (MAX_EVIDENCE_BYTES + 1))
        bundle = valid_bundle()
        bundle["limitations"] = ["x" * MAX_EVIDENCE_BYTES]
        with self.assertRaisesRegex(EvidenceError, "256 KiB"):
            validate_evidence(bundle)

    def test_version_product_uuid_and_digest_constraints(self):
        for field, value in (("schema_version", "ev.v2"), ("product", "console"),
                             ("run_id", "not-a-uuid"), ("task_key", "A" * 64)):
            bundle = valid_bundle()
            bundle[field] = value
            with self.subTest(field=field), self.assertRaises(EvidenceError):
                validate_evidence(bundle)

    def test_fixed_limits_cannot_be_broadened(self):
        for key in valid_bundle()["configuration"]["limits"]:
            for value in (True, 999999, "1"):
                bundle = valid_bundle()
                bundle["configuration"]["limits"][key] = value
                with self.subTest(key=key, value=value), self.assertRaises(EvidenceError):
                    validate_evidence(bundle)

    def test_bad_timestamps_and_reverse_time_rejected(self):
        for value in ("2026-10-21", "2026-10-21T03:40:01", "2026-02-31T03:40:01Z", "2026-10-21T03:39:59Z", "2026-10-21T03:40:01+00:60"):
            bundle = valid_bundle()
            bundle["timestamps"]["ended_at"] = value
            with self.subTest(value=value), self.assertRaises(EvidenceError):
                validate_evidence(bundle)

    def test_offset_timestamps_are_compared_as_instants(self):
        bundle = valid_bundle()
        bundle["timestamps"]["started_at"] = "2026-10-20T23:40:00-04:00"
        validate_evidence(bundle)

    def test_out_of_order_events_rejected(self):
        bundle = valid_bundle()
        bundle["events"].reverse()
        with self.assertRaisesRegex(EvidenceError, "chronologically"):
            validate_evidence(bundle)

    def test_success_cannot_precede_review_or_survive_failure(self):
        bundle = valid_bundle()
        bundle["outcome"]["task_success"] = True
        with self.assertRaisesRegex(EvidenceError, "success requires"):
            validate_evidence(bundle)
        for execution, verification in (("failed", "verified"), ("completed", "failed"), ("unverified", "unverified"), ("denied", "denied")):
            bundle = approved_bundle()
            bundle["outcome"].update({"execution": execution, "verification": verification})
            with self.subTest(execution=execution, verification=verification), self.assertRaises(EvidenceError):
                validate_evidence(bundle)

    def test_verified_pending_review_still_requires_every_proof_artifact(self):
        for missing_id in verification_artifacts():
            bundle = valid_bundle()
            bundle["artifacts"] = [record for record in bundle["artifacts"] if record["id"] != missing_id]
            # Clear a now-absent command reference to isolate missing proof from
            # the independent dangling-reference check.
            for command in bundle["commands"]:
                if command["artifact_id"] == missing_id:
                    command["artifact_id"] = None
            with self.subTest(missing_id=missing_id), self.assertRaisesRegex(EvidenceError, "proof artifacts"):
                validate_evidence(bundle)

    def test_verified_requires_baseline_failure_and_candidate_success_proof(self):
        for command_id, wrong_exit in (("baseline_checks", 0), ("candidate_checks", 1), ("candidate_checks", None)):
            bundle = valid_bundle()
            next(command for command in bundle["commands"] if command["id"] == command_id)["exit_code"] = wrong_exit
            with self.subTest(command_id=command_id, wrong_exit=wrong_exit), self.assertRaisesRegex(EvidenceError, "failed baseline"):
                validate_evidence(bundle)
        for missing_id in ("baseline_checks", "candidate_checks"):
            bundle = valid_bundle()
            bundle["commands"] = [command for command in bundle["commands"] if command["id"] != missing_id]
            with self.subTest(missing_id=missing_id), self.assertRaises(EvidenceError):
                validate_evidence(bundle)

    def test_verified_commands_cannot_point_to_unrelated_artifacts(self):
        bundle = valid_bundle()
        bundle["commands"][1]["artifact_id"] = "patch"
        with self.assertRaisesRegex(EvidenceError, "bound to proof artifacts"):
            validate_evidence(bundle)

    def test_sparse_denied_and_unverified_envelopes_remain_valid(self):
        for state in ("denied", "unverified", "failed"):
            bundle = valid_bundle()
            bundle["outcome"].update({"execution": state, "verification": state})
            bundle["commands"] = []
            bundle["artifacts"] = []
            with self.subTest(state=state):
                validate_evidence(bundle)

    def test_forged_or_unbound_review_metadata_is_rejected(self):
        for field, value in (("reviewer", "builder-1"), ("reviewer", " BUILDER-1 "),
                             ("reviewer", None), ("reviewed_head", "0" * 40),
                             ("review_receipt_sha256", None)):
            bundle = approved_bundle()
            bundle["provenance"][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(EvidenceError):
                validate_evidence(bundle)

    def test_pending_review_cannot_smuggle_a_reviewer(self):
        bundle = valid_bundle()
        bundle["provenance"]["reviewer"] = "untrusted-claim"
        with self.assertRaisesRegex(EvidenceError, "pending review"):
            validate_evidence(bundle)

    def test_changed_head_invalidates_approved_review(self):
        bundle = approved_bundle()
        bundle["source"]["head_sha"] = "2" * 40
        with self.assertRaisesRegex(EvidenceError, "bind"):
            validate_evidence(bundle)

    def test_boolean_or_nonfinite_numeric_metrics_rejected(self):
        for key in ("duration_seconds", "human_minutes", "cost_amount"):
            for value in (True, -1, float("nan"), float("inf"), "1"):
                bundle = valid_bundle()
                bundle["metrics"][key] = value
                if key == "cost_amount":
                    bundle["metrics"]["cost_currency"] = "USD"
                with self.subTest(key=key, value=value), self.assertRaises(EvidenceError):
                    validate_evidence(bundle)

    def test_huge_native_integer_metrics_raise_only_evidence_error(self):
        for key in ("duration_seconds", "human_minutes", "cost_amount"):
            for value in (10**1000, 10**5000):
                bundle = valid_bundle()
                bundle["metrics"][key] = value
                if key == "cost_amount":
                    bundle["metrics"]["cost_currency"] = "USD"
                with self.subTest(key=key, digits=1001 if value == 10**1000 else 5001), self.assertRaises(EvidenceError):
                    validate_evidence(bundle)

    def test_unknown_cost_is_null_not_zero(self):
        bundle = valid_bundle()
        validate_evidence(bundle)
        self.assertIsNone(bundle["metrics"]["cost_amount"])
        bundle["metrics"]["cost_amount"] = 0
        with self.assertRaises(EvidenceError):
            validate_evidence(bundle)
        bundle["metrics"]["cost_currency"] = "USD"
        validate_evidence(bundle)

    def test_command_types_refs_and_identifiers_are_checked(self):
        for field, value in (("exit_code", True), ("id", "../run"), ("artifact_id", "not-present")):
            bundle = valid_bundle()
            bundle["commands"][0][field] = value
            with self.subTest(field=field), self.assertRaises(EvidenceError):
                validate_evidence(bundle)
        bundle = valid_bundle()
        bundle["commands"].append(deepcopy(bundle["commands"][0]))
        with self.assertRaisesRegex(EvidenceError, "duplicate"):
            validate_evidence(bundle)

    def test_control_characters_and_oversized_field_lists_rejected(self):
        bundle = valid_bundle()
        bundle["task"]["task_id"] = "safe\nexecute"
        with self.assertRaises(EvidenceError):
            validate_evidence(bundle)
        bundle = valid_bundle()
        bundle["limitations"] = ["limit"] * 65
        with self.assertRaises(EvidenceError):
            validate_evidence(bundle)


class ArtifactTests(unittest.TestCase):
    def test_exact_bytes_match_without_file_access(self):
        verify_artifacts(valid_bundle(), verification_artifacts())

    def test_tamper_missing_extra_and_wrong_type_are_refused(self):
        for supplied in ({**verification_artifacts(), "candidate_checks": b'{"passed":false}'}, {},
                         {**verification_artifacts(), "extra": b"unlisted"},
                         {**verification_artifacts(), "candidate_checks": "a path is not bytes"}):
            with self.subTest(supplied=supplied), self.assertRaises(EvidenceError):
                verify_artifacts(valid_bundle(), supplied)

    def test_artifact_path_and_remote_ids_are_never_accepted(self):
        for identifier in ("../checks", "/tmp/checks", "C:\\checks", "https://example.com/log", "checks.json", "CHECKS", "checks\x00"):
            with self.subTest(identifier=identifier), self.assertRaises(EvidenceError):
                artifact_record(identifier, b"data", "text/plain")

    def test_duplicate_records_and_false_sizes_are_refused(self):
        bundle = valid_bundle()
        bundle["artifacts"].append(deepcopy(bundle["artifacts"][0]))
        with self.assertRaisesRegex(EvidenceError, "duplicate"):
            validate_evidence(bundle)
        bundle = valid_bundle()
        bundle["artifacts"][0]["size_bytes"] = True
        with self.assertRaises(EvidenceError):
            validate_evidence(bundle)

    def test_media_type_is_data_without_parameters(self):
        for media_type in ("../../text", "text/plain; charset=utf-8", "text/plain\r\nX: value"):
            with self.subTest(media_type=media_type), self.assertRaises(EvidenceError):
                artifact_record("log", b"data", media_type)


class ComparisonTests(unittest.TestCase):
    def test_run_identity_and_time_do_not_determine_comparability(self):
        a = valid_bundle()
        b = valid_bundle()
        b["run_id"] = "1407f230-659a-4ff1-b091-24fa58ca8477"
        b["task_key"] = "0" * 64
        b["task"]["task_id"] = "different-delivery-of-same-fixture"
        b["timestamps"]["ended_at"] = "2026-10-21T03:40:10Z"
        self.assertTrue(comparable(a, b))

    def test_every_compatibility_component_must_match(self):
        for group, field, value in (
            ("task", "fixture_id", "different-fixture"),
            ("task", "scope_revision", "arms.v0.2"),
            ("configuration", "suite_digest", "0" * 64),
            ("configuration", "digest", "1" * 64),
            ("configuration", "verifier_version", "different-rules"),
        ):
            b = valid_bundle()
            b[group][field] = value
            with self.subTest(field=field):
                self.assertFalse(comparable(valid_bundle(), b))

    def test_missing_compatibility_data_is_invalid_not_comparable(self):
        b = valid_bundle()
        del b["configuration"]["suite_digest"]
        with self.assertRaises(EvidenceError):
            comparable(valid_bundle(), b)


if __name__ == "__main__":
    unittest.main()
