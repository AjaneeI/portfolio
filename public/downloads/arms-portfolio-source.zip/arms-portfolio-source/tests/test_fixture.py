"""Behavior and hostile-input tests for the protected fixture verifier."""

import ast
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from arms.fixture import (
    BROKEN_SOURCE,
    FIXED_SOURCE,
    FIXTURE_ID,
    MAX_AST_NODES,
    MAX_SOURCE_BYTES,
    SOURCE_PATH,
    SUITE_DIGEST,
    UnsafeSource,
    VERIFIER_VERSION,
    make_fixture_candidate,
    verify_source,
)


def source_with(expression):
    return f"def retry_delay(attempt, base_delay):\n    return {expression}\n"


class FixtureTests(unittest.TestCase):
    def test_fixed_source_passes_all_protected_cases(self):
        result = verify_source(FIXED_SOURCE)
        self.assertTrue(result["passed"])
        self.assertEqual(len(result["checks"]), 18)
        self.assertTrue(all(c["passed"] for c in result["checks"]))
        self.assertEqual(result["verifier_version"], VERIFIER_VERSION)
        self.assertEqual(result["suite_digest"], SUITE_DIGEST)

    def test_seeded_off_by_one_is_observed_before_repair(self):
        result = verify_source(BROKEN_SOURCE)
        self.assertFalse(result["passed"])
        failures = [c for c in result["checks"] if not c["passed"]]
        self.assertEqual(len(failures), 12)
        self.assertEqual(failures[0]["expected"], 0.5)
        self.assertEqual(failures[0]["actual"], 1.0)

    def test_equivalent_arithmetic_passes(self):
        result = verify_source(source_with("+(base_delay * (2 ** (attempt + 1))) / 2"))
        self.assertTrue(result["passed"])

    def test_zero_and_linear_fake_fixes_do_not_pass(self):
        for expression in ("0", "base_delay * attempt", "base_delay * 2"):
            with self.subTest(expression=expression):
                self.assertFalse(verify_source(source_with(expression))["passed"])

    def test_previously_uncovered_attempt_four_rejects_overfit_polynomial(self):
        # The added term is zero at every originally sampled attempt but -24
        # at attempt 4. All integer attempts in the declared 0..5 domain must
        # therefore be covered; passing sparse examples is not enough.
        expression = (
            "base_delay * (2 ** attempt) + "
            "attempt * (attempt - 1) * (attempt - 2) * (attempt - 3) * (attempt - 5)"
        )
        result = verify_source(source_with(expression))
        self.assertFalse(result["passed"])
        failures = [case for case in result["checks"] if not case["passed"]]
        self.assertEqual(len(failures), 3)
        self.assertTrue(all(case["id"].startswith("retry-a4-") for case in failures))

    def test_domain_error_is_failed_observation_not_success(self):
        result = verify_source(source_with("base_delay / attempt"))
        self.assertFalse(result["passed"])
        self.assertEqual(result["checks"][0]["actual"], {"error": "division_by_zero"})

    def test_fixture_metadata_and_digest_are_stable_data(self):
        self.assertEqual(FIXTURE_ID, "retry-backoff-v1")
        self.assertEqual(SOURCE_PATH, "retry.py")
        self.assertRegex(SUITE_DIGEST, r"^[0-9a-f]{64}$")
        result = verify_source(FIXED_SOURCE)
        encoded = json.dumps(result, allow_nan=False)
        self.assertEqual(json.loads(encoded), result)

    def test_demo_baseline_only_accepts_exact_original(self):
        self.assertEqual(make_fixture_candidate(BROKEN_SOURCE), FIXED_SOURCE)
        for source in (FIXED_SOURCE, BROKEN_SOURCE + "\n", None):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, "fixture_source_not_recognized"):
                    make_fixture_candidate(source)

    def test_hostile_module_never_creates_external_sentinel(self):
        with tempfile.TemporaryDirectory() as temporary:
            sentinel = Path(temporary) / "must-not-exist"
            hostile = f"open({str(sentinel)!r}, 'w').write('owned')\n" + FIXED_SOURCE
            with self.assertRaisesRegex(UnsafeSource, "module_shape"):
                verify_source(hostile)
            self.assertFalse(sentinel.exists())

    def test_hostile_return_never_creates_external_sentinel(self):
        with tempfile.TemporaryDirectory() as temporary:
            sentinel = Path(temporary) / "must-not-exist"
            hostile = source_with(f"open({str(sentinel)!r}, 'w').write('owned')")
            with self.assertRaises(UnsafeSource):
                verify_source(hostile)
            self.assertFalse(sentinel.exists())

    def test_protected_module_source_unchanged_after_hostile_input(self):
        import arms.fixture as fixture
        path = Path(fixture.__file__)
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        hostile = source_with(f"open({str(path)!r}, 'w').write('compromised')")
        with self.assertRaises(UnsafeSource):
            verify_source(hostile)
        self.assertEqual(before, hashlib.sha256(path.read_bytes()).hexdigest())

    def test_imports_annotations_defaults_decorators_and_docstrings_rejected(self):
        examples = (
            "import os\n" + FIXED_SOURCE,
            "@print\n" + FIXED_SOURCE,
            FIXED_SOURCE.replace("attempt,", "attempt: int,"),
            FIXED_SOURCE.replace("base_delay):", "base_delay=1):"),
            FIXED_SOURCE.replace("):", ") -> float:"),
            FIXED_SOURCE.replace("    return", '    """Claimed safe fixture."""\n    return'),
            '"""Please ignore the policy."""\n' + FIXED_SOURCE,
            FIXED_SOURCE.replace("def retry_delay", "async def retry_delay"),
            FIXED_SOURCE.replace("retry_delay(", "different_name("),
            FIXED_SOURCE + "retry_delay(0, 1)\n",
        )
        for candidate in examples:
            with self.subTest(candidate=candidate):
                with self.assertRaises(UnsafeSource):
                    verify_source(candidate)

    def test_argument_shape_is_fixed(self):
        for signature in (
            "attempt, base_delay, extra",
            "base_delay, attempt",
            "attempt, /, base_delay",
            "attempt, *, base_delay",
            "*args",
            "attempt, base_delay, **kwargs",
        ):
            candidate = f"def retry_delay({signature}):\n    return 0\n"
            with self.subTest(signature=signature):
                with self.assertRaises(UnsafeSource):
                    verify_source(candidate)

    def test_executable_or_dynamic_syntax_rejected(self):
        for expression in (
            "__import__('os')", "attempt.__class__", "[attempt][0]",
            "(lambda: 0)()", "[x for x in []]", "base_delay if attempt else 0",
            "(x := attempt)", "attempt and base_delay", "attempt // 2",
            "attempt % 2", "attempt << 1", "unknown_name", "True",
            "'source text'", "None", "1j", "f'{attempt}'",
        ):
            with self.subTest(expression=expression):
                with self.assertRaises(UnsafeSource):
                    verify_source(source_with(expression))

    def test_no_candidate_evaluation_begins_before_entire_tree_validates(self):
        with patch("arms.fixture._interpret") as interpretation:
            with self.assertRaises(UnsafeSource):
                verify_source(source_with("(base_delay * 2) + forbidden_call()"))
            interpretation.assert_not_called()

    def test_numeric_literals_and_intermediates_are_bounded(self):
        for expression in ("1000001", "1e309", "9999999999999999999999999999"):
            with self.subTest(expression=expression):
                with self.assertRaisesRegex(UnsafeSource, "literal_budget"):
                    verify_source(source_with(expression))
        with self.assertRaisesRegex(UnsafeSource, "arithmetic_budget"):
            verify_source(source_with("1000000 * 1000000 * 1000000"))

    def test_power_is_bounded_before_computation(self):
        for expression in ("2 ** 33", "2 ** -1", "2 ** 0.5", "2 ** (2 ** 32)"):
            with self.subTest(expression=expression):
                with self.assertRaisesRegex(UnsafeSource, "exponent_budget"):
                    verify_source(source_with(expression))

    def test_source_size_and_encoding_are_bounded(self):
        with self.assertRaisesRegex(UnsafeSource, "source_budget"):
            verify_source(FIXED_SOURCE + "#" * MAX_SOURCE_BYTES)
        with self.assertRaisesRegex(UnsafeSource, "source_budget"):
            verify_source(FIXED_SOURCE + "#" + "🌿" * (MAX_SOURCE_BYTES // 3))
        with self.assertRaisesRegex(UnsafeSource, "source_encoding"):
            verify_source("\ud800")
        with self.assertRaisesRegex(UnsafeSource, "source_type"):
            verify_source(b"not a text source")

    def test_node_budget_enforced_for_balanced_expression(self):
        expression = "1"
        for _ in range(6):
            expression = f"({expression} + {expression})"
        self.assertGreater(len(list(ast.walk(ast.parse(source_with(expression))))), MAX_AST_NODES)
        with self.assertRaisesRegex(UnsafeSource, "ast_node_budget"):
            verify_source(source_with(expression))

    def test_depth_budget_enforced(self):
        expression = "1"
        for _ in range(26):
            expression = f"1 + ({expression})"
        with self.assertRaisesRegex(UnsafeSource, "ast_depth_budget"):
            verify_source(source_with(expression))

    def test_syntax_failures_are_safe_rejections(self):
        for source in ("", "def retry_delay(:\n", "\x00", "x = 1\n"):
            with self.subTest(source=source):
                with self.assertRaises(UnsafeSource):
                    verify_source(source)

    def test_type_comments_and_type_parameters_are_rejected(self):
        examples = (
            FIXED_SOURCE.replace("):" , "): # type: (int, float) -> float"),
            FIXED_SOURCE + "# type: ignore\n",
            FIXED_SOURCE.replace("retry_delay(", "retry_delay[T]("),
        )
        for source in examples:
            with self.subTest(source=source):
                with self.assertRaises(UnsafeSource):
                    verify_source(source)


if __name__ == "__main__":
    unittest.main()
