"""Exercise the actual user entry point, including failures and review readback."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from arms.__main__ import main, show_reviewed
from arms.contracts import PolicyError, candidate_for, canonical, default_task, sha256
from arms.engine import inspect_run, record_review, run_task
from arms.fixture import BROKEN_SOURCE, FIXED_SOURCE


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.workspace = self.folder / "workbench"

    def call(self, *arguments):
        output = io.StringIO()
        with redirect_stdout(output):
            status = main(list(arguments))
        return status, json.loads(output.getvalue())

    def test_module_entry_point_runs_without_installation(self):
        result = subprocess.run([sys.executable, "-m", "arms", "policy"], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["policy"]["publication"], "disabled")

    def test_native_cli_and_artifact_validation(self):
        task = default_task("cli-native")
        task_path, candidate_path = self.folder / "task.json", self.folder / "candidate.json"
        task_path.write_bytes(canonical(task))
        candidate_path.write_bytes(canonical(candidate_for(task, FIXED_SOURCE)))
        status, result = self.call("run", "--workspace", str(self.workspace), "--task", str(task_path), "--candidate", str(candidate_path))
        self.assertEqual(status, 0)
        self.assertEqual(result["evidence"]["provenance"]["adapter"], "native-json")
        directory = self.workspace / "runs" / result["run_id"]
        status, validated = self.call("validate-evidence", str(directory / "evidence.json"), "--artifacts", str(directory))
        self.assertEqual(status, 0)
        self.assertTrue(validated["artifacts_verified"])
        self.assertFalse(validated["authorship_authenticated"])

    def test_accepted_unicode_comment_patch_reconstructs_exact_source(self):
        source = FIXED_SOURCE + "# comment\u2028more\u0085text\x0bkept\x0cintact\n"
        task = default_task("unicode-comment")
        result = run_task(self.workspace, task, candidate_for(task, source), adapter="native-json")
        self.assertEqual(result["evidence"]["outcome"]["verification"], "verified")
        patch = self.workspace / "runs" / result["run_id"] / "repair.patch"
        pristine = self.folder / "pristine"
        pristine.mkdir()
        (pristine / "retry.py").write_bytes(BROKEN_SOURCE.encode())
        checked = subprocess.run(["git", "-C", str(pristine), "apply", "--check", str(patch)], capture_output=True, timeout=10)
        self.assertEqual(checked.returncode, 0, checked.stderr)
        applied = subprocess.run(["git", "-C", str(pristine), "apply", str(patch)], capture_output=True, timeout=10)
        self.assertEqual(applied.returncode, 0, applied.stderr)
        self.assertEqual((pristine / "retry.py").read_bytes(), source.encode())

    def test_hunk_content_resembling_file_headers_consumes_diff_budget(self):
        source = ("def retry_delay(attempt, base_delay):\n    return (\n"
                  "        base_delay * (2 ** attempt)\n" + "+++0\n" * 10 + "    )\n")
        task = default_task("diff-header-lookalike")
        result = run_task(self.workspace, task, candidate_for(task, source), adapter="native-json")
        self.assertEqual(result["evidence"]["outcome"]["verification"], "denied")
        self.assertEqual(result["evidence"]["outcome"]["reason_code"], "diff_budget")
        self.assertEqual((self.workspace / "workspaces" / result["run_id"] / "retry.py").read_bytes(), BROKEN_SOURCE.encode())

    def test_candidate_without_final_newline_is_denied_not_bad_patch(self):
        task = default_task()
        candidate = self.folder / "candidate.json"
        candidate.write_bytes(canonical(candidate_for(task, FIXED_SOURCE.rstrip("\n"))))
        status, result = self.call("run", "--workspace", str(self.workspace), "--candidate", str(candidate))
        self.assertEqual(status, 2)
        self.assertEqual(result["evidence"]["outcome"]["verification"], "denied")

    def test_duplicate_keys_rejected_before_any_workspace_effect(self):
        candidate = self.folder / "candidate.json"
        candidate.write_text('{"task_key":"a","task_key":"b"}')
        status, result = self.call("run", "--workspace", str(self.workspace), "--candidate", str(candidate))
        self.assertEqual(status, 2)
        self.assertFalse(self.workspace.exists())

    def test_demo_is_repeatable_without_additional_runs(self):
        status, summary = self.call("demo", "--workspace", str(self.workspace))
        self.assertEqual(status, 0)
        self.assertEqual(len(summary["cases"]), 11)
        runs = set((self.workspace / "runs").iterdir())
        status, repeated = self.call("demo", "--workspace", str(self.workspace))
        self.assertEqual(status, 0)
        self.assertEqual(set((self.workspace / "runs").iterdir()), runs)
        self.assertEqual(len(runs), 8)

    def test_reviewed_readback_rejects_tamper_and_preserves_original(self):
        run = run_task(self.workspace, default_task())
        bundle = run["evidence"]
        receipt = {"run_id": run["run_id"], "head_sha": bundle["source"]["head_sha"],
                   "evidence_sha256": sha256(canonical(bundle)), "reviewer": "separate-reviewer",
                   "decision": "approved", "blocking_findings": 0, "notes": "Synthetic test review."}
        reviewed = record_review(self.workspace, run["run_id"], receipt)
        self.assertEqual(show_reviewed(self.workspace, run["run_id"]), reviewed)
        self.assertFalse(inspect_run(self.workspace, run["run_id"])["outcome"]["task_success"])
        path = self.workspace / "runs" / run["run_id"] / "reviewed-evidence.json"
        reviewed["metrics"]["duration_seconds"] = 999
        path.write_bytes(canonical(reviewed))
        with self.assertRaises(PolicyError):
            show_reviewed(self.workspace, run["run_id"])


if __name__ == "__main__":
    unittest.main()
